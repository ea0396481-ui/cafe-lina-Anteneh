import {
  collection,
  doc,
  onSnapshot,
  setDoc,
  deleteDoc,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../firebase';

/**
 * Subscribe to a Firestore collection with real-time onSnapshot listeners.
 * Auto-seeds initial data into Firestore if the collection is empty.
 */
export function subscribeToCollection<T extends Record<string, any>>(
  collectionName: string,
  idField: string,
  initialData: T[],
  onData: (data: T[]) => void
): () => void {
  const colRef = collection(db, collectionName);

  const unsubscribe = onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty && initialData.length > 0) {
        // Seed initial data if Firestore collection is newly initialized
        try {
          const batch = writeBatch(db);
          initialData.forEach((item) => {
            const id = String(item[idField] || item.id || item.voucherId);
            const docRef = doc(db, collectionName, id);
            batch.set(docRef, item);
          });
          await batch.commit();
        } catch (err) {
          console.error(`Error seeding initial data for ${collectionName}:`, err);
        }
        return;
      }

      const items: T[] = [];
      snapshot.forEach((docSnap) => {
        items.push(docSnap.data() as T);
      });
      onData(items);
    },
    (error) => {
      console.error(`Firestore subscription error on ${collectionName}:`, error);
    }
  );

  return unsubscribe;
}

/**
 * Save (create or update) a document in Firestore
 */
export async function saveItem<T extends Record<string, any>>(
  collectionName: string,
  item: T,
  idField: string = 'id'
): Promise<void> {
  const id = String(item[idField] || item.id || item.voucherId);
  if (!id) {
    console.error(`Cannot save item to ${collectionName}: missing ID field (${idField})`, item);
    return;
  }
  const docRef = doc(db, collectionName, id);
  await setDoc(docRef, item, { merge: true });
}

/**
 * Delete a document from Firestore
 */
export async function deleteItem(collectionName: string, docId: string): Promise<void> {
  if (!docId) return;
  const docRef = doc(db, collectionName, docId);
  await deleteDoc(docRef);
}

/**
 * Reset a collection back to initial mock data
 */
export async function resetCollection<T extends Record<string, any>>(
  collectionName: string,
  initialData: T[],
  idField: string = 'id'
): Promise<void> {
  try {
    const colRef = collection(db, collectionName);
    const snapshot = await getDocs(colRef);
    const batch = writeBatch(db);

    snapshot.docs.forEach((docSnap) => {
      batch.delete(docSnap.ref);
    });

    initialData.forEach((item) => {
      const id = String(item[idField] || item.id || item.voucherId);
      const docRef = doc(db, collectionName, id);
      batch.set(docRef, item);
    });

    await batch.commit();
  } catch (err) {
    console.error(`Error resetting collection ${collectionName}:`, err);
  }
}
