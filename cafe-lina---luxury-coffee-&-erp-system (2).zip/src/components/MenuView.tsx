import React, { useState } from 'react';
import { MenuItem, Category } from '../types';
import { Search, ShoppingBag, Star, Info, Heart, Flame, Clock, CheckCircle2, X } from 'lucide-react';

interface MenuViewProps {
  menuItems: MenuItem[];
  onAddToCart: (item: MenuItem, customOptions?: string[], notes?: string) => void;
  wishlistIds: string[];
  toggleWishlist: (itemId: string) => void;
}

export const MenuView: React.FC<MenuViewProps> = ({
  menuItems,
  onAddToCart,
  wishlistIds,
  toggleWishlist,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [selectedMilk, setSelectedMilk] = useState<string>('Whole Organic Milk');
  const [extraShots, setExtraShots] = useState<number>(0);
  const [specialNotes, setSpecialNotes] = useState<string>('');

  const categories: (Category | 'All')[] = [
    'All',
    'Coffee',
    'Espresso',
    'Latte',
    'Cappuccino',
    'Mocha',
    'Macchiato',
    'Americano',
    'Tea',
    'Breakfast',
    'Bakery',
    'Cake',
    'Dessert',
    'Pizza',
    'Burger',
    'Sandwich',
    'Fresh Juice',
    'Soft Drink',
  ];

  const filteredItems = menuItems.filter((item) => {
    const matchesCategory =
      selectedCategory === 'All' ||
      item.category === selectedCategory ||
      item.subcategory === selectedCategory;

    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.ingredients.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  const handleCustomAdd = () => {
    if (!selectedItem) return;
    const options = [selectedMilk, extraShots > 0 ? `+${extraShots} Extra Espresso Shot` : null].filter(
      Boolean
    ) as string[];

    onAddToCart(selectedItem, options, specialNotes);
    setSelectedItem(null);
    setSpecialNotes('');
    setExtraShots(0);
  };

  return (
    <div className="py-10 bg-[#0f0f0f] min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Menu Title Header */}
        <div className="text-center mb-8">
          <span className="text-[#D4AF37] text-xs font-bold uppercase tracking-[0.2em]">
            Artisan Craftsmanship
          </span>
          <h1 className="text-4xl font-serif font-bold text-[#FDF5E6] mt-1 mb-2">
            Cafe Lina Full Menu
          </h1>
          <p className="text-sm text-[#A8A095] max-w-xl mx-auto">
            From single-origin specialty coffees to artisanal morning breakfasts and freshly baked Belgian desserts.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-8 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search coffee, bakery, ingredients..."
            className="w-full bg-[#181818] border border-[#D4AF37]/30 text-[#FDF5E6] placeholder-[#A8A095] rounded-full pl-11 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4AF37] shadow-lg"
          />
          <Search size={18} className="absolute left-4 top-3.5 text-[#D4AF37]" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-3.5 text-xs text-[#A8A095] hover:text-[#D4AF37]"
            >
              Clear
            </button>
          )}
        </div>

        {/* Category Filter Pills (Horizontal Scroll) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 no-scrollbar scroll-smooth">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`whitespace-nowrap px-4 py-2 rounded-full text-xs font-semibold transition-all ${
                selectedCategory === cat
                  ? 'bg-[#6B1D1D] text-white border border-[#D4AF37]/40 shadow-md'
                  : 'bg-[#181818] text-[#FDF5E6]/80 hover:bg-white/10 border border-[#D4AF37]/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="text-center py-16 bg-[#181818] rounded-2xl border border-[#D4AF37]/20 p-8">
            <p className="text-[#A8A095] font-medium">No items found matching "{searchQuery}"</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('All');
              }}
              className="mt-4 px-4 py-2 bg-[#6B1D1D] text-white border border-[#D4AF37]/30 rounded-xl text-xs font-bold"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => {
              const isWishlisted = wishlistIds.includes(item.id);

              return (
                <div
                  key={item.id}
                  className="bg-[#181818] rounded-2xl overflow-hidden border border-[#D4AF37]/20 hover:border-[#D4AF37]/60 shadow-lg transition-all duration-300 flex flex-col group"
                >
                  {/* Image */}
                  <div className="relative h-48 overflow-hidden bg-[#121212] cursor-pointer" onClick={() => setSelectedItem(item)}>
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <span className="bg-[#181818]/90 backdrop-blur-md text-[#D4AF37] border border-[#D4AF37]/40 text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1 shadow-md">
                        <Info size={12} /> Quick Customize
                      </span>
                    </div>

                    <span className="absolute top-3 left-3 bg-[#0f0f0f]/80 backdrop-blur-md text-[#D4AF37] border border-[#D4AF37]/20 text-[10px] font-medium px-2.5 py-0.5 rounded-full uppercase">
                      {item.category}
                    </span>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(item.id);
                      }}
                      className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-colors ${
                        isWishlisted
                          ? 'bg-[#6B1D1D] text-white border border-[#D4AF37]/50'
                          : 'bg-black/60 text-gray-300 hover:text-[#D4AF37]'
                      }`}
                    >
                      <Heart size={14} fill={isWishlisted ? 'currentColor' : 'none'} />
                    </button>
                  </div>

                  {/* Body */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <h3
                          onClick={() => setSelectedItem(item)}
                          className="font-serif font-bold text-base text-[#FDF5E6] hover:text-[#D4AF37] cursor-pointer"
                        >
                          {item.name}
                        </h3>
                        <div className="flex items-center gap-1 text-xs text-[#D4AF37] font-semibold">
                          <Star size={12} className="fill-[#D4AF37] text-[#D4AF37]" />
                          <span>{item.rating}</span>
                        </div>
                      </div>

                      <p className="text-xs text-[#A8A095] line-clamp-2 leading-relaxed mb-3">
                        {item.description}
                      </p>

                      {/* Micro info */}
                      <div className="flex items-center gap-3 text-[11px] text-[#A8A095]/80 mb-4">
                        <span className="flex items-center gap-1">
                          <Flame size={12} className="text-orange-400" />
                          {item.calories} kcal
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock size={12} className="text-blue-400" />
                          {item.prepTimeMinutes} min prep
                        </span>
                      </div>
                    </div>

                    {/* Price & Add */}
                    <div className="pt-3 border-t border-white/10 flex items-center justify-between">
                      <span className="text-base font-extrabold text-[#D4AF37]">
                        {item.price} {item.currency}
                      </span>

                      <button
                        onClick={() => onAddToCart(item)}
                        className="bg-[#6B1D1D] hover:bg-[#4A1212] text-white px-3.5 py-1.5 rounded-xl text-xs font-bold border border-[#D4AF37]/30 flex items-center gap-1 transition-colors active:scale-95"
                      >
                        <ShoppingBag size={13} />
                        <span>Add</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Item Detail & Customize Modal */}
        {selectedItem && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#181818] text-[#FDF5E6] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl relative border border-[#D4AF37]/30 max-h-[90vh] flex flex-col">
              <button
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-10 bg-black/60 hover:bg-black text-white p-2 rounded-full backdrop-blur-md transition-colors"
              >
                <X size={18} />
              </button>

              <div className="relative h-60 bg-[#121212]">
                <img src={selectedItem.image} alt={selectedItem.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#181818] via-transparent to-transparent" />
                <div className="absolute bottom-4 left-6 right-6 text-white">
                  <span className="text-[10px] uppercase font-bold tracking-widest bg-[#D4AF37] text-black px-2.5 py-0.5 rounded-full">
                    {selectedItem.category}
                  </span>
                  <h2 className="text-2xl font-serif font-bold text-[#FDF5E6] mt-1">{selectedItem.name}</h2>
                </div>
              </div>

              <div className="p-6 overflow-y-auto flex-1 space-y-5">
                <p className="text-sm text-[#A8A095] leading-relaxed">{selectedItem.description}</p>

                {/* Ingredients List */}
                <div>
                  <h4 className="text-xs font-bold uppercase text-[#D4AF37] mb-2 tracking-wider">
                    Ingredients & Allens
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedItem.ingredients.map((ing) => (
                      <span key={ing} className="bg-[#222222] text-[#FDF5E6] text-xs px-2.5 py-1 rounded-md border border-white/10">
                        {ing}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Milk Options for Coffee */}
                {['Coffee', 'Espresso', 'Latte', 'Cappuccino', 'Mocha', 'Macchiato'].includes(selectedItem.category) && (
                  <div>
                    <h4 className="text-xs font-bold uppercase text-[#D4AF37] mb-2 tracking-wider">
                      Select Milk Preference
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {['Whole Organic Milk', 'Oat Milk (+20 ETB)', 'Almond Milk (+25 ETB)', 'Skimmed Milk'].map((milk) => (
                        <button
                          key={milk}
                          onClick={() => setSelectedMilk(milk)}
                          className={`p-2 rounded-xl text-left border font-medium transition-colors ${
                            selectedMilk === milk
                              ? 'border-[#D4AF37] bg-[#6B1D1D]/40 text-[#D4AF37] font-bold'
                              : 'border-white/10 text-[#A8A095] hover:bg-white/5'
                          }`}
                        >
                          {milk}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Extra Shot counter */}
                {['Coffee', 'Espresso', 'Latte', 'Cappuccino'].includes(selectedItem.category) && (
                  <div className="flex items-center justify-between bg-[#222222] p-3 rounded-xl border border-white/5">
                    <span className="text-xs font-bold text-[#FDF5E6]">Extra Espresso Shot (+30 ETB)</span>
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => setExtraShots(Math.max(0, extraShots - 1))}
                        className="w-7 h-7 rounded-lg bg-white/10 text-white font-bold hover:bg-white/20"
                      >
                        -
                      </button>
                      <span className="text-sm font-bold text-[#D4AF37]">{extraShots}</span>
                      <button
                        onClick={() => setExtraShots(extraShots + 1)}
                        className="w-7 h-7 rounded-lg bg-[#6B1D1D] text-white font-bold hover:bg-[#4A1212]"
                      >
                        +
                      </button>
                    </div>
                  </div>
                )}

                {/* Special Instructions */}
                <div>
                  <h4 className="text-xs font-bold uppercase text-[#D4AF37] mb-1 tracking-wider">
                    Special Notes / Preparation Request
                  </h4>
                  <input
                    type="text"
                    value={specialNotes}
                    onChange={(e) => setSpecialNotes(e.target.value)}
                    placeholder="e.g. Extra hot, less sugar, packaging for gift..."
                    className="w-full bg-[#222222] border border-white/10 text-[#FDF5E6] rounded-xl p-2.5 text-xs focus:ring-2 focus:ring-[#D4AF37] placeholder-[#A8A095]"
                  />
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-[#121212] border-t border-white/10 flex items-center justify-between">
                <div>
                  <span className="text-xs text-[#A8A095] block">Total Item Price</span>
                  <span className="text-xl font-extrabold text-[#D4AF37]">
                    {selectedItem.price + (extraShots * 30)} {selectedItem.currency}
                  </span>
                </div>

                <button
                  onClick={handleCustomAdd}
                  className="bg-[#6B1D1D] hover:bg-[#4A1212] border border-[#D4AF37]/30 text-white px-6 py-3 rounded-xl font-bold text-xs uppercase flex items-center gap-2 shadow-lg"
                >
                  <CheckCircle2 size={16} />
                  <span>Confirm & Add To Cart</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
