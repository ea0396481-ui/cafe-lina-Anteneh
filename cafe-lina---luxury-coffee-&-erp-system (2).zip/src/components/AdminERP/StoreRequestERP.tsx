import React, { useState } from 'react';
import { InventoryItem, StoreRequestVoucher, StoreRequestItem, StoreRecord } from '../../types';
import {
  ClipboardList,
  Plus,
  Trash2,
  Eye,
  Edit,
  FileText,
  AlertTriangle,
  Printer,
  X,
  Search,
  Building2,
  ArrowRight,
  Send,
  Sparkles,
} from 'lucide-react';

interface StoreRequestERPProps {
  inventory: InventoryItem[];
  stores: StoreRecord[];
  requests: StoreRequestVoucher[];
  onAddRequest: (request: StoreRequestVoucher) => void;
  onUpdateRequest: (request: StoreRequestVoucher) => void;
  onDeleteRequest: (voucherId: string) => void;
}

export const StoreRequestERP: React.FC<StoreRequestERPProps> = ({
  inventory,
  stores,
  requests,
  onAddRequest,
  onUpdateRequest,
  onDeleteRequest,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVoucherForView, setSelectedVoucherForView] = useState<StoreRequestVoucher | null>(null);
  const [editingVoucher, setEditingVoucher] = useState<StoreRequestVoucher | null>(null);

  // Store selection
  const [currentRequestingStore, setCurrentRequestingStore] = useState(
    stores[0]?.name || 'Kitchen & Bakery Sub-Store'
  );
  const [targetIssuingStore, setTargetIssuingStore] = useState(
    stores[1]?.name || stores[0]?.name || 'Bole Main Central Warehouse'
  );

  // Multi-Item Request Form State
  const [requestedBy, setRequestedBy] = useState('Chef Biruk Tadesse');
  const [department, setDepartment] = useState('Kitchen & Bakery Bar');
  const [remark, setRemark] = useState('');

  // Selected ingredients with requested quantities: { [invId]: quantity }
  const [selectedItems, setSelectedItems] = useState<{ [invId: string]: number }>({});
  const [itemSearch, setItemSearch] = useState('');

  // Find Low Stock / Minimum Amount Items in Inventory
  const lowStockItems = inventory.filter(
    (item) => item.stockQty <= item.reorderLevel || item.stockQty === 0
  );

  const handleToggleItem = (inv: InventoryItem) => {
    setSelectedItems((prev) => {
      const copy = { ...prev };
      if (copy[inv.id] !== undefined) {
        delete copy[inv.id];
      } else {
        copy[inv.id] = Math.max(1, inv.reorderLevel - inv.stockQty > 0 ? inv.reorderLevel - inv.stockQty + 5 : 5);
      }
      return copy;
    });
  };

  const handleQtyChange = (invId: string, qty: number) => {
    if (qty <= 0) return;
    setSelectedItems((prev) => ({ ...prev, [invId]: qty }));
  };

  const handleQuickAddLowStock = (inv: InventoryItem) => {
    setIsModalOpen(true);
    const suggestedQty = Math.max(5, (inv.reorderLevel || 10) * 2 - inv.stockQty);
    setSelectedItems((prev) => ({
      ...prev,
      [inv.id]: suggestedQty,
    }));
  };

  const handleSubmitRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const itemIds = Object.keys(selectedItems);
    if (itemIds.length === 0) return;

    const reqItems: StoreRequestItem[] = itemIds.map((id) => {
      const inv = inventory.find((i) => i.id === id)!;
      return {
        inventoryId: inv.id,
        ingredientName: inv.name,
        sku: inv.sku,
        qtyRequested: selectedItems[id],
        unit: inv.unit,
        availableStock: inv.stockQty,
      };
    });

    const newVoucher: StoreRequestVoucher = {
      voucherId: `SRV-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      requestedBy,
      requestingStore: currentRequestingStore,
      targetStore: targetIssuingStore,
      department,
      status: 'Approved',
      createdTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      remark: remark || `Material Requisition from ${currentRequestingStore}`,
      items: reqItems,
    };

    onAddRequest(newVoucher);
    setIsModalOpen(false);
    setSelectedItems({});
    setRemark('');
  };

  const handlePrintVoucher = () => {
    window.print();
  };

  const filteredInventory = inventory.filter(
    (i) =>
      i.name.toLowerCase().includes(itemSearch.toLowerCase()) ||
      i.sku.toLowerCase().includes(itemSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-16">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Material Requisitions & Internal Store Request
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1.5 flex items-center gap-2.5">
            <ClipboardList className="text-[#D4AF37]" size={28} />
            Store Requisitions & Material Requests
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Request raw materials between stores, monitor minimum stock alerts, and generate official requisition vouchers.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-[16px] text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg min-h-[46px] cursor-pointer self-start lg:self-auto"
        >
          <Plus size={18} />
          <span>New Store Requisition Request</span>
        </button>
      </div>

      {/* Store Context Selector Card */}
      <div className="bg-[#243244] p-5 sm:p-6 rounded-[24px] border border-white/10 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div>
            <h2 className="text-sm font-bold text-[#F8FAFC] flex items-center gap-2">
              <Building2 size={16} className="text-[#D4AF37]" />
              Active Location & Requisition Route
            </h2>
            <p className="text-xs text-[#94A3B8]">Select your current store location and default central supplier store</p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Requesting Store */}
            <div className="flex items-center gap-2 bg-[#1E293B] p-2 px-3 rounded-xl border border-white/10">
              <span className="text-[10px] font-bold uppercase text-[#94A3B8]">My Location:</span>
              <select
                value={currentRequestingStore}
                onChange={(e) => setCurrentRequestingStore(e.target.value)}
                className="bg-transparent text-[#D4AF37] font-bold text-xs focus:outline-none cursor-pointer"
              >
                {stores.map((s) => (
                  <option key={s.id} value={s.name} className="bg-[#1E293B] text-[#F8FAFC]">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            <ArrowRight size={16} className="text-[#94A3B8] hidden sm:inline" />

            {/* Target Store */}
            <div className="flex items-center gap-2 bg-[#1E293B] p-2 px-3 rounded-xl border border-white/10">
              <span className="text-[10px] font-bold uppercase text-[#94A3B8]">Target Central Store:</span>
              <select
                value={targetIssuingStore}
                onChange={(e) => setTargetIssuingStore(e.target.value)}
                className="bg-transparent text-[#22C55E] font-bold text-xs focus:outline-none cursor-pointer"
              >
                {stores.map((s) => (
                  <option key={s.id} value={s.name} className="bg-[#1E293B] text-[#F8FAFC]">
                    {s.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Low Stock & Minimum Amount Warning Panel (Gbat Sialk Ena Minimum Amount Lay Siders) */}
        {lowStockItems.length > 0 && (
          <div className="bg-[#3B151A] border border-[#EF4444]/40 p-4 sm:p-5 rounded-[20px] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-[#EF4444]">
                <AlertTriangle size={20} className="animate-pulse" />
                <div>
                  <h3 className="font-extrabold text-sm text-[#FCA5A5]">
                    Minimum Stock Level & Depleted Raw Materials Alert ({lowStockItems.length} Items)
                  </h3>
                  <p className="text-[11px] text-[#F87171]">
                    The following ingredients are running out or below their minimum stock threshold. Click to request replenishment immediately!
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-1">
              {lowStockItems.map((inv) => (
                <div
                  key={inv.id}
                  className="bg-[#1E293B] p-3 rounded-xl border border-[#EF4444]/30 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <span className="font-bold text-[#F8FAFC] block truncate max-w-[150px]">{inv.name}</span>
                    <div className="flex items-center gap-2 text-[10px]">
                      <span className="text-red-400 font-extrabold">Stock: {inv.stockQty} {inv.unit}</span>
                      <span className="text-[#94A3B8]">Min: {inv.reorderLevel} {inv.unit}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleQuickAddLowStock(inv)}
                    className="bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] px-2.5 py-1.5 rounded-lg text-[10px] font-extrabold flex items-center gap-1 transition-all cursor-pointer min-h-[36px]"
                  >
                    <Send size={12} /> Quick Request
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Requisition Vouchers Table */}
      <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div>
            <h2 className="text-lg font-serif font-bold text-[#F8FAFC]">Store Requisition Vouchers Log</h2>
            <p className="text-xs text-[#94A3B8]">Track pending, approved, and issued material requests across all store locations</p>
          </div>
          <span className="bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30 text-xs font-bold px-3 py-1 rounded-full self-start sm:self-auto">
            {requests.length} Requests Filed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#CBD5E1]">
            <thead className="bg-[#1E293B] text-[#94A3B8] uppercase text-[10px] font-extrabold tracking-wider border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">Voucher ID</th>
                <th className="py-3.5 px-4">Requester & Location</th>
                <th className="py-3.5 px-4">Target Central Store</th>
                <th className="py-3.5 px-4">Items Count</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4 text-center">Actions / Receipt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {requests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-12 text-[#94A3B8]">
                    No material request vouchers created yet. Click "New Store Requisition Request" above to generate one.
                  </td>
                </tr>
              ) : (
                requests.map((r) => (
                  <tr key={r.voucherId} className="hover:bg-[#1E293B]/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#D4AF37]">{r.voucherId}</td>
                    <td className="py-3.5 px-4 space-y-0.5">
                      <span className="font-bold text-[#F8FAFC] block">{r.requestedBy}</span>
                      <span className="text-[10px] text-[#94A3B8] block">{r.requestingStore || r.department}</span>
                    </td>
                    <td className="py-3.5 px-4 font-medium text-[#22C55E]">{r.targetStore}</td>
                    <td className="py-3.5 px-4 font-bold text-[#D4AF37]">{r.items.length} Ingredients</td>
                    <td className="py-3.5 px-4">
                      <span>{r.date}</span> <span className="text-[10px] text-[#94A3B8]">{r.createdTime}</span>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30 text-[10px] font-bold px-2.5 py-1 rounded-full">
                        {r.status}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => setSelectedVoucherForView(r)}
                          className="p-2 bg-[#1E293B] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] rounded-lg transition-all min-h-[38px] min-w-[38px] inline-flex items-center justify-center cursor-pointer"
                          title="View Official Voucher Receipt"
                        >
                          <FileText size={16} />
                        </button>
                        <button
                          onClick={() => setEditingVoucher(r)}
                          className="p-2 bg-[#1E293B] text-[#3B82F6] hover:bg-[#3B82F6] hover:text-white rounded-lg transition-all min-h-[38px] min-w-[38px] inline-flex items-center justify-center cursor-pointer"
                          title="Edit Request"
                        >
                          <Edit size={16} />
                        </button>
                        <button
                          onClick={() => onDeleteRequest(r.voucherId)}
                          className="p-2 bg-[#1E293B] text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-all min-h-[38px] min-w-[38px] inline-flex items-center justify-center cursor-pointer"
                          title="Delete Request"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: Create Multi-Item Request Voucher */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={handleSubmitRequest}
            className="bg-[#1E293B] border border-white/10 rounded-[28px] max-w-2xl w-full p-6 sm:p-8 space-y-5 shadow-2xl text-[#F8FAFC] max-h-[92vh] overflow-y-auto"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-xl text-[#F8FAFC]">Create Store Requisition Voucher</h3>
                <p className="text-xs text-[#94A3B8]">Issue material request ticket from your location to central store</p>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-2 text-gray-400 hover:text-white rounded-xl hover:bg-white/5 cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Requesting Location *</label>
                <select
                  value={currentRequestingStore}
                  onChange={(e) => setCurrentRequestingStore(e.target.value)}
                  className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {stores.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Target Issuing Store *</label>
                <select
                  value={targetIssuingStore}
                  onChange={(e) => setTargetIssuingStore(e.target.value)}
                  className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {stores.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Requested By (Staff Name) *</label>
                <input
                  type="text"
                  required
                  value={requestedBy}
                  onChange={(e) => setRequestedBy(e.target.value)}
                  className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            {/* Select Multiple Raw Ingredients */}
            <div className="space-y-2.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <label className="block text-xs font-bold text-[#D4AF37] uppercase tracking-wider">
                  Select Raw Materials ({Object.keys(selectedItems).length} Items Selected)
                </label>

                <div className="relative">
                  <input
                    type="text"
                    value={itemSearch}
                    onChange={(e) => setItemSearch(e.target.value)}
                    placeholder="Search raw material..."
                    className="w-full sm:w-56 h-9 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl pl-8 pr-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                  <Search size={14} className="absolute left-2.5 top-2.5 text-[#94A3B8]" />
                </div>
              </div>

              <div className="max-h-60 overflow-y-auto border border-white/10 rounded-2xl p-2 bg-[#243244] space-y-2">
                {filteredInventory.map((inv) => {
                  const isChecked = selectedItems[inv.id] !== undefined;
                  const isLow = inv.stockQty <= inv.reorderLevel;

                  return (
                    <div
                      key={inv.id}
                      className={`p-3 rounded-xl flex items-center justify-between text-xs border transition-all ${
                        isChecked
                          ? 'bg-[#1E293B] border-[#D4AF37] text-[#F8FAFC]'
                          : 'bg-[#1E293B]/50 border-white/5 text-[#CBD5E1] hover:bg-[#1E293B]'
                      }`}
                    >
                      <label className="flex items-center gap-2.5 cursor-pointer flex-1">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleItem(inv)}
                          className="w-4 h-4 accent-[#D4AF37] rounded cursor-pointer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm block">{inv.name}</span>
                            {isLow && (
                              <span className="bg-red-500/20 text-red-400 border border-red-500/30 text-[9px] font-black px-2 py-0.5 rounded-full">
                                LOW STOCK
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-[#94A3B8]">
                            SKU: {inv.sku} | Avail Stock: <strong className="text-[#F8FAFC]">{inv.stockQty} {inv.unit}</strong> | Min: {inv.reorderLevel} {inv.unit}
                          </span>
                        </div>
                      </label>

                      {isChecked && (
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-[#94A3B8]">Requested Qty:</span>
                          <input
                            type="number"
                            min={1}
                            value={selectedItems[inv.id]}
                            onChange={(e) => handleQtyChange(inv.id, Number(e.target.value))}
                            className="w-20 h-8 bg-[#243244] text-[#D4AF37] font-extrabold border border-[#D4AF37]/50 rounded-lg px-2 text-xs focus:outline-none"
                          />
                          <span className="text-xs text-[#94A3B8] font-bold">{inv.unit}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Voucher Remark / Reason *</label>
              <input
                type="text"
                value={remark}
                onChange={(e) => setRemark(e.target.value)}
                placeholder="e.g. Daily morning kitchen prep supply requisition"
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl px-4 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex gap-3 pt-3">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 h-12 bg-[#243244] hover:bg-[#2F4158] text-[#CBD5E1] rounded-2xl text-xs font-bold cursor-pointer transition-all"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={Object.keys(selectedItems).length === 0}
                className="flex-1 h-12 bg-[#D4AF37] hover:bg-[#F6C453] disabled:opacity-40 text-[#0F172A] rounded-2xl text-xs font-extrabold shadow-lg cursor-pointer transition-all"
              >
                Submit Requisition Voucher
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: View Official Request Voucher / Printable Receipt Ticket */}
      {selectedVoucherForView && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[28px] max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl text-[#F8FAFC]">
            {/* Header Controls */}
            <div className="flex justify-between items-center border-b border-white/10 pb-4">
              <div className="flex items-center gap-2 text-[#D4AF37]">
                <FileText size={22} />
                <h3 className="font-serif font-bold text-lg text-[#F8FAFC]">Official Requisition Voucher</h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrintVoucher}
                  className="px-3 py-1.5 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center gap-1.5 shadow-md cursor-pointer"
                >
                  <Printer size={14} /> Print Receipt
                </button>
                <button
                  onClick={() => setSelectedVoucherForView(null)}
                  className="p-1.5 text-gray-400 hover:text-white rounded-lg hover:bg-white/5 cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Printable Ticket Receipt Container */}
            <div className="bg-white text-slate-900 p-6 rounded-2xl space-y-4 shadow-inner text-xs font-sans border border-slate-200">
              {/* Receipt Header */}
              <div className="text-center border-b border-dashed border-slate-300 pb-4 space-y-1">
                <h2 className="font-extrabold text-base tracking-tight uppercase text-slate-900">
                  Café Lina Luxury Co.
                </h2>
                <p className="text-[10px] font-bold text-slate-600 uppercase tracking-wider">
                  Store Requisition Voucher (SRV)
                </p>
                <div className="inline-block bg-slate-900 text-amber-400 font-mono font-bold text-xs px-3 py-0.5 rounded-full mt-1">
                  Voucher ID: {selectedVoucherForView.voucherId}
                </div>
              </div>

              {/* Info Grid */}
              <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 p-3 rounded-xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block text-[9px] uppercase font-bold">Requesting Location:</span>
                  <strong className="text-slate-900">{selectedVoucherForView.requestingStore || selectedVoucherForView.department}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px] uppercase font-bold">Target Issuing Store:</span>
                  <strong className="text-slate-900">{selectedVoucherForView.targetStore}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px] uppercase font-bold">Requested By:</span>
                  <strong className="text-slate-900">{selectedVoucherForView.requestedBy}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px] uppercase font-bold">Date & Time:</span>
                  <strong className="text-slate-900">{selectedVoucherForView.date} {selectedVoucherForView.createdTime}</strong>
                </div>
              </div>

              {/* Items Table */}
              <div className="space-y-2">
                <h4 className="text-[10px] font-extrabold uppercase tracking-wider text-slate-700 border-b pb-1">
                  Requested Materials List ({selectedVoucherForView.items.length})
                </h4>

                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 text-[10px] uppercase">
                      <th className="py-1">Ingredient Item</th>
                      <th className="py-1 text-center">SKU</th>
                      <th className="py-1 text-right">Requested Qty</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {selectedVoucherForView.items.map((it, idx) => (
                      <tr key={idx}>
                        <td className="py-2 text-slate-900 font-bold">{it.ingredientName}</td>
                        <td className="py-2 text-center text-slate-500 font-mono text-[10px]">{it.sku}</td>
                        <td className="py-2 text-right font-extrabold text-slate-900">
                          {it.qtyRequested} {it.unit}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {selectedVoucherForView.remark && (
                <div className="pt-2 text-[10px] text-slate-600 border-t border-dashed border-slate-300">
                  <strong>Voucher Remark:</strong> {selectedVoucherForView.remark}
                </div>
              )}

              {/* Official Signatures */}
              <div className="grid grid-cols-3 gap-2 pt-6 border-t border-slate-300 text-[9px] text-center text-slate-500 font-medium">
                <div>
                  <div className="border-b border-slate-400 mb-1 h-6"></div>
                  <span>Requested By</span>
                </div>
                <div>
                  <div className="border-b border-slate-400 mb-1 h-6"></div>
                  <span>Store Keeper Approval</span>
                </div>
                <div>
                  <div className="border-b border-slate-400 mb-1 h-6"></div>
                  <span>Received By</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setSelectedVoucherForView(null)}
              className="w-full h-11 bg-[#243244] hover:bg-[#2F4158] text-[#F8FAFC] rounded-2xl text-xs font-bold transition-all cursor-pointer"
            >
              Close Receipt Ticket
            </button>
          </div>
        </div>
      )}

      {/* MODAL 3: Edit Request Voucher */}
      {editingVoucher && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onUpdateRequest(editingVoucher);
              setEditingVoucher(null);
            }}
            className="bg-[#1E293B] border border-white/10 rounded-[28px] max-w-md w-full p-6 sm:p-8 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg">Edit Requisition {editingVoucher.voucherId}</h3>
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="p-1 text-gray-400 hover:text-white cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Requested By</label>
              <input
                type="text"
                value={editingVoucher.requestedBy}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, requestedBy: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Voucher Remark</label>
              <input
                type="text"
                value={editingVoucher.remark || ''}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, remark: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 h-11 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
