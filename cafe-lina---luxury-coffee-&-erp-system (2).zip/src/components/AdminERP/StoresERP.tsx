import React, { useState } from 'react';
import { StoreRecord } from '../../types';
import { Store, Plus, Trash2, Phone, MapPin, User, CheckCircle2, XCircle, X } from 'lucide-react';

interface StoresERPProps {
  stores: StoreRecord[];
  onAddStore: (store: StoreRecord) => void;
  onDeleteStore: (id: string) => void;
}

export const StoresERP: React.FC<StoresERPProps> = ({
  stores,
  onAddStore,
  onDeleteStore,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [code, setCode] = useState(`STR-${Math.floor(100 + Math.random() * 900)}`);
  const [location, setLocation] = useState('Bole Atlas, Addis Ababa');
  const [managerName, setManagerName] = useState('Dawit Solomon');
  const [phone, setPhone] = useState('+251 911 222 333');
  const [capacity, setCapacity] = useState('500 Sq. Meters / 20 Tons');
  const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
  const [notes, setNotes] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const newStore: StoreRecord = {
      id: `STR-REC-${Date.now()}`,
      name,
      code,
      location,
      managerName,
      phone,
      capacity,
      status,
      notes,
    };

    onAddStore(newStore);
    setIsModalOpen(false);
    setName('');
    setCode(`STR-${Math.floor(100 + Math.random() * 900)}`);
  };

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Multi-Location Warehouse ERP
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <Store className="text-[#D4AF37]" size={28} />
            Store Locations & Warehouses (Storochen Mmezegbbet)
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Register and manage central stores, branch coffee labs, and cold storage warehouses professionally.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg min-h-[44px]"
        >
          <Plus size={18} />
          <span>Register New Store</span>
        </button>
      </div>

      {/* Stores List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {stores.map((st) => (
          <div
            key={st.id}
            className="bg-[#243244] p-5 rounded-[22px] border border-white/10 shadow-md space-y-4 hover:border-[#D4AF37]/40 transition-all"
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <span className="text-[10px] font-mono text-[#D4AF37] bg-[#1E293B] px-2 py-0.5 rounded border border-[#D4AF37]/20">
                  {st.code}
                </span>
                <h3 className="font-serif font-bold text-lg text-[#F8FAFC] mt-1">{st.name}</h3>
              </div>

              <span
                className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                  st.status === 'Active'
                    ? 'bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/30'
                    : 'bg-red-500/20 text-red-400 border border-red-500/30'
                }`}
              >
                {st.status === 'Active' ? <CheckCircle2 size={12} /> : <XCircle size={12} />}
                {st.status}
              </span>
            </div>

            <div className="space-y-2 text-xs text-[#CBD5E1]">
              <div className="flex items-center gap-2">
                <MapPin size={15} className="text-[#D4AF37] shrink-0" />
                <span>{st.location}</span>
              </div>

              <div className="flex items-center gap-2">
                <User size={15} className="text-[#D4AF37] shrink-0" />
                <span>Manager: <strong className="text-[#F8FAFC]">{st.managerName}</strong></span>
              </div>

              <div className="flex items-center gap-2">
                <Phone size={15} className="text-[#D4AF37] shrink-0" />
                <span>{st.phone}</span>
              </div>

              <div className="p-2.5 bg-[#1E293B] rounded-xl border border-white/5 text-[11px] mt-2">
                <span className="text-[#94A3B8] block text-[10px] font-semibold uppercase">Storage Capacity</span>
                <span className="font-bold text-[#D4AF37]">{st.capacity}</span>
              </div>
            </div>

            <div className="pt-2 border-t border-white/5 flex justify-end">
              <button
                onClick={() => onDeleteStore(st.id)}
                className="text-gray-400 hover:text-[#EF4444] text-xs flex items-center gap-1"
              >
                <Trash2 size={15} /> Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Add Store */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={handleAdd}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-lg w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg">Register Store Location</h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Store Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Bole Main Warehouse"
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Store Code *</label>
                <input
                  type="text"
                  required
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs font-mono focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Location Address *</label>
              <input
                type="text"
                required
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="e.g. Kazanchis Industry Zone, Addis Ababa"
                className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Manager Name *</label>
                <input
                  type="text"
                  required
                  value={managerName}
                  onChange={(e) => setManagerName(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Manager Phone *</label>
                <input
                  type="text"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Storage Capacity</label>
                <input
                  type="text"
                  value={capacity}
                  onChange={(e) => setCapacity(e.target.value)}
                  placeholder="e.g. 300 Sqm / 15 Tons"
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Store Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  <option value="Active">Active</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 h-11 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold shadow-md"
              >
                Save Store
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
