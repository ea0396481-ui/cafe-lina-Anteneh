import React, { useState } from 'react';
import { InventoryItem, MenuItem, ProductRecipeItem } from '../../types';
import {
  Utensils,
  Plus,
  Search,
  CheckCircle2,
  Trash2,
  DollarSign,
  TrendingUp,
  Image as ImageIcon,
  Upload,
  X,
  Sparkles,
  Calculator,
  Check,
  Tag,
  BookOpen,
} from 'lucide-react';

interface ProductCostingERPProps {
  inventory: InventoryItem[];
  menuItems: MenuItem[];
  onAddMenuItem: (item: Partial<MenuItem>) => void;
  onDeleteMenuItem: (id: string) => void;
}

const SAMPLE_PRODUCT_PHOTOS = [
  { label: 'Cappuccino', url: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=800&q=80' },
  { label: 'Breakfast Spread', url: 'https://images.unsplash.com/photo-1533089860892-a7c6f0a88666?auto=format&fit=crop&w=800&q=80' },
  { label: 'Belgian Cake', url: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80' },
  { label: 'Fresh Juice', url: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=800&q=80' },
  { label: 'Macchiato', url: 'https://images.unsplash.com/photo-1485808191679-5f86510681a2?auto=format&fit=crop&w=800&q=80' },
  { label: 'Croissant', url: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80' },
  { label: 'Caffe Latte', url: 'https://images.unsplash.com/photo-1534778101976-62847782c213?auto=format&fit=crop&w=800&q=80' },
  { label: 'Gourmet Burger', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80' },
];

export const ProductCostingERP: React.FC<ProductCostingERPProps> = ({
  inventory,
  menuItems,
  onAddMenuItem,
  onDeleteMenuItem,
}) => {
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  // New Product Form State
  const [productName, setProductName] = useState('');
  const [productCategory, setProductCategory] = useState<string>('Coffee');
  const [productDescription, setProductDescription] = useState('');
  const [previewImage, setPreviewImage] = useState<string>(SAMPLE_PRODUCT_PHOTOS[0].url);
  const [targetMarginPercent, setTargetMarginPercent] = useState<number>(60); // % margin

  // Recipe ingredients selected for this product
  const [selectedIngredients, setSelectedIngredients] = useState<ProductRecipeItem[]>([]);
  const [ingredientSearch, setIngredientSearch] = useState('');

  // Handle Photo File Upload
  const handlePhotoFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Add ingredient from inventory list into product recipe
  const handleAddIngredientToRecipe = (invItem: InventoryItem) => {
    if (selectedIngredients.some((i) => i.inventoryId === invItem.id)) return;

    const defaultQty = invItem.unit === 'kg' ? 0.02 : invItem.unit === 'liters' ? 0.15 : 1;
    const itemCost = invItem.costPerUnit;

    const newItem: ProductRecipeItem = {
      inventoryId: invItem.id,
      ingredientName: invItem.name,
      sku: invItem.sku,
      qty: defaultQty,
      unit: invItem.unit,
      unitCost: itemCost,
      portionCost: defaultQty * itemCost,
      isMainIngredient: selectedIngredients.length === 0, // First added defaults to main
    };

    setSelectedIngredients((prev) => [...prev, newItem]);
  };

  // Update quantity of an ingredient portion in recipe
  const handleUpdatePortionQty = (invId: string, newQty: number) => {
    setSelectedIngredients((prev) =>
      prev.map((item) => {
        if (item.inventoryId === invId) {
          const liveUnitCost = inventory.find((i) => i.id === invId)?.costPerUnit || item.unitCost;
          return {
            ...item,
            qty: newQty,
            unitCost: liveUnitCost,
            portionCost: newQty * liveUnitCost,
          };
        }
        return item;
      })
    );
  };

  // Toggle "Main Ingredient" (Wana Gbat)
  const handleToggleMainIngredient = (invId: string) => {
    setSelectedIngredients((prev) =>
      prev.map((item) => ({
        ...item,
        isMainIngredient: item.inventoryId === invId,
      }))
    );
  };

  // Remove ingredient portion from recipe
  const handleRemoveIngredientFromRecipe = (invId: string) => {
    setSelectedIngredients((prev) => prev.filter((i) => i.inventoryId !== invId));
  };

  // Live Auto-calculated total raw ingredient cost
  const totalIngredientCost = selectedIngredients.reduce((sum, item) => {
    const liveUnitCost = inventory.find((i) => i.id === item.inventoryId)?.costPerUnit || item.unitCost;
    return sum + item.qty * liveUnitCost;
  }, 0);

  // Auto-calculated recommended selling price based on profit margin %
  const recommendedSellingPrice = Math.ceil(
    totalIngredientCost * (1 + (targetMarginPercent || 0) / 100)
  );

  // Submit product registration
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productName.trim()) return;

    onAddMenuItem({
      name: productName,
      category: productCategory as any,
      price: recommendedSellingPrice > 0 ? recommendedSellingPrice : 150,
      currency: 'ETB',
      description: productDescription || `Crafted with ${selectedIngredients.map((i) => i.ingredientName).join(', ')}`,
      image: previewImage,
      ingredients: selectedIngredients.map((i) => i.ingredientName),
      barcode: `CL-REC-${Math.floor(100 + Math.random() * 900)}`,
      calories: 220,
      prepTimeMinutes: 5,
      isAvailable: true,
    });

    // Reset & close modal
    setIsRegisterModalOpen(false);
    setProductName('');
    setProductDescription('');
    setSelectedIngredients([]);
    setTargetMarginPercent(60);
    setPreviewImage(SAMPLE_PRODUCT_PHOTOS[0].url);
  };

  // Search filtered inventory for dropdown
  const filteredInventoryToAdd = inventory.filter(
    (item) =>
      !selectedIngredients.some((s) => s.inventoryId === item.id) &&
      (item.name.toLowerCase().includes(ingredientSearch.toLowerCase()) ||
        item.sku.toLowerCase().includes(ingredientSearch.toLowerCase()) ||
        item.category.toLowerCase().includes(ingredientSearch.toLowerCase()))
  );

  const filteredMenuItems = menuItems.filter(
    (item) =>
      item.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      item.category.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Product Recipe & Cost Calculator
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <BookOpen className="text-[#D4AF37]" size={28} />
            Product Registration & Dynamic Cost Engine
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Register products, select raw ingredients from inventory, flag Main Ingredient (Wana Gbat), enter profit margin %, and auto-calculate selling price.
          </p>
        </div>

        <button
          onClick={() => setIsRegisterModalOpen(true)}
          className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg hover:shadow-[#D4AF37]/20 active:scale-95 min-h-[44px]"
        >
          <Plus size={18} />
          <span>Register Product (Product Mmezegbbet)</span>
        </button>
      </div>

      {/* Overview Metric Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#243244] p-5 rounded-[20px] border border-white/10 shadow-md flex items-center justify-between">
          <div>
            <span className="text-[#94A3B8] text-xs font-semibold block uppercase tracking-wider">Registered Products</span>
            <span className="text-2xl font-extrabold text-[#F8FAFC]">{menuItems.length} Items</span>
          </div>
          <Utensils className="text-[#D4AF37]" size={28} />
        </div>

        <div className="bg-[#243244] p-5 rounded-[20px] border border-white/10 shadow-md flex items-center justify-between">
          <div>
            <span className="text-[#94A3B8] text-xs font-semibold block uppercase tracking-wider">Available Raw Ingredients</span>
            <span className="text-2xl font-extrabold text-[#22C55E]">{inventory.length} SKUs</span>
          </div>
          <Calculator className="text-[#22C55E]" size={28} />
        </div>

        <div className="bg-[#243244] p-5 rounded-[20px] border border-white/10 shadow-md flex items-center justify-between">
          <div>
            <span className="text-[#94A3B8] text-xs font-semibold block uppercase tracking-wider">Dynamic Cost Syncing</span>
            <span className="text-xs font-bold text-[#D4AF37] bg-[#D4AF37]/10 px-2.5 py-1 rounded-full border border-[#D4AF37]/30">
              Active Auto Update
            </span>
          </div>
          <TrendingUp className="text-[#D4AF37]" size={28} />
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="bg-[#243244] p-4 rounded-[20px] border border-white/10 shadow-md">
        <div className="relative">
          <input
            type="text"
            value={searchFilter}
            onChange={(e) => setSearchFilter(e.target.value)}
            placeholder="Search registered product name or category..."
            className="w-full h-[48px] bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl pl-11 pr-4 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#D4AF37]"
          />
          <Search size={18} className="absolute left-3.5 top-3.5 text-[#94A3B8]" />
        </div>
      </div>

      {/* Product Catalog Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredMenuItems.map((item) => (
          <div
            key={item.id}
            className="bg-[#243244] rounded-[22px] border border-white/10 overflow-hidden shadow-lg flex flex-col justify-between hover:border-[#D4AF37]/40 transition-all group"
          >
            <div>
              <div className="relative h-44 overflow-hidden">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#1E293B] via-transparent to-transparent" />
                <span className="absolute top-3 right-3 bg-[#D4AF37] text-[#0F172A] font-extrabold text-xs px-3 py-1 rounded-full shadow-md">
                  {item.price} ETB
                </span>
                <span className="absolute bottom-3 left-3 bg-[#1E293B]/90 backdrop-blur-xs text-[#CBD5E1] border border-white/10 text-[11px] font-semibold px-2.5 py-1 rounded-lg">
                  {item.category}
                </span>
              </div>

              <div className="p-5 space-y-3">
                <h3 className="font-serif font-bold text-lg text-[#F8FAFC]">{item.name}</h3>
                <p className="text-xs text-[#94A3B8] line-clamp-2">{item.description}</p>

                {item.ingredients && item.ingredients.length > 0 && (
                  <div className="space-y-1.5 pt-2 border-t border-white/5">
                    <span className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-wider block">
                      Ingredients Recipe:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {item.ingredients.map((ing, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] bg-[#1E293B] text-[#CBD5E1] px-2 py-0.5 rounded border border-white/5"
                        >
                          {ing}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="p-4 bg-[#1E293B] border-t border-white/10 flex items-center justify-between text-xs">
              <span className="text-[#94A3B8] font-mono text-[11px]">{item.barcode || 'CL-PRODUCT'}</span>
              <button
                onClick={() => onDeleteMenuItem(item.id)}
                className="p-1.5 text-gray-400 hover:text-[#EF4444] rounded-lg transition-colors"
                title="Delete product"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* MODAL: Register Product (Product Mmezegbbet) */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-3xl w-full p-5 sm:p-7 space-y-5 my-6 shadow-2xl text-[#F8FAFC]">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-xl text-[#D4AF37]">
                  <Utensils size={22} />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-serif font-bold text-[#F8FAFC]">
                    Product Registration & Recipe Costing (Product Mmezegbbet)
                  </h2>
                  <p className="text-xs text-[#94A3B8]">
                    Select raw ingredients, set quantities in liter/gram/kilo, flag Wana Gbat & auto-calculate selling price!
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsRegisterModalOpen(false)}
                className="p-2 text-[#94A3B8] hover:text-white rounded-xl bg-[#243244]"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-5">
              {/* Product Basic Info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Product Name (Product Name) *
                  </label>
                  <input
                    type="text"
                    required
                    value={productName}
                    onChange={(e) => setProductName(e.target.value)}
                    placeholder="e.g. Special Yirgacheffe Latte, Belgian Cake"
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Product Category *
                  </label>
                  <select
                    value={productCategory}
                    onChange={(e) => setProductCategory(e.target.value)}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] cursor-pointer"
                  >
                    <option value="Coffee">Coffee & Espresso</option>
                    <option value="Latte">Latte Drinks</option>
                    <option value="Cappuccino">Cappuccino</option>
                    <option value="Macchiato">Macchiato</option>
                    <option value="Tea">Teas & Infusions</option>
                    <option value="Bakery">Bakery & Pastry</option>
                    <option value="Cake">Cakes & Desserts</option>
                    <option value="Breakfast">Breakfast & Meals</option>
                    <option value="Fresh Juice">Fresh Juices</option>
                    <option value="Burger">Burgers & Sandwiches</option>
                    <option value="Pizza">Wood-fired Pizzas</option>
                  </select>
                </div>
              </div>

              {/* Product Image Selection & Upload */}
              <div className="bg-[#243244] p-4 rounded-xl border border-white/10 space-y-3">
                <label className="block text-xs font-bold text-[#CBD5E1] flex items-center gap-2">
                  <ImageIcon size={16} className="text-[#D4AF37]" />
                  Product Photo Upload (Photo Upload Maregbet)
                </label>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-20 h-20 object-cover rounded-xl border-2 border-[#D4AF37] shrink-0"
                  />

                  <div className="space-y-2 flex-1 w-full">
                    <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#1E293B] hover:bg-[#2F4158] text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl text-xs font-bold cursor-pointer transition-all">
                      <Upload size={16} /> Upload Custom Photo
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePhotoFileChange}
                        className="hidden"
                      />
                    </label>

                    <p className="text-[11px] text-[#94A3B8]">Or select from preset photos:</p>
                    <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                      {SAMPLE_PRODUCT_PHOTOS.map((preset, idx) => (
                        <button
                          type="button"
                          key={idx}
                          onClick={() => setPreviewImage(preset.url)}
                          className={`p-1 rounded-lg border text-[10px] font-semibold whitespace-nowrap flex items-center gap-1 shrink-0 ${
                            previewImage === preset.url
                              ? 'border-[#D4AF37] bg-[#D4AF37]/20 text-[#D4AF37]'
                              : 'border-white/10 bg-[#1E293B] text-gray-300'
                          }`}
                        >
                          <img src={preset.url} alt="" className="w-5 h-5 object-cover rounded" />
                          <span>{preset.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* RAW INGREDIENTS RECIPE PICKER SECTION */}
              <div className="bg-[#243244] p-4 rounded-xl border border-white/10 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
                  <div>
                    <h3 className="text-xs font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-2">
                      <Sparkles size={16} className="text-[#D4AF37]" />
                      Select Raw Ingredients for Recipe (Gbat Search Arge Memret)
                    </h3>
                    <p className="text-[11px] text-[#94A3B8]">
                      Search registered ingredients, add portions (liters, grams, kg), and tick Main Ingredient (Wana Gbat).
                    </p>
                  </div>
                  <span className="text-xs font-bold text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-lg border border-[#D4AF37]/30">
                    {selectedIngredients.length} Ingredients Added
                  </span>
                </div>

                {/* Search Box to Pick Ingredients from Inventory */}
                <div className="relative">
                  <input
                    type="text"
                    value={ingredientSearch}
                    onChange={(e) => setIngredientSearch(e.target.value)}
                    placeholder="Search registered ingredients (e.g. Yirgacheffe, Milk, Butter)..."
                    className="w-full h-[44px] bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl pl-10 pr-4 text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                  <Search size={16} className="absolute left-3 top-3.5 text-[#94A3B8]" />
                </div>

                {/* Filtered Search Dropdown List */}
                {ingredientSearch.trim() && (
                  <div className="bg-[#1E293B] border border-white/10 rounded-xl max-h-40 overflow-y-auto p-2 space-y-1">
                    {filteredInventoryToAdd.length === 0 ? (
                      <div className="text-center py-2 text-[11px] text-[#94A3B8]">
                        No matching ingredients available in inventory.
                      </div>
                    ) : (
                      filteredInventoryToAdd.map((inv) => (
                        <div
                          key={inv.id}
                          onClick={() => {
                            handleAddIngredientToRecipe(inv);
                            setIngredientSearch('');
                          }}
                          className="p-2 hover:bg-[#2F4158] rounded-lg cursor-pointer flex items-center justify-between text-xs transition-colors"
                        >
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-[#F8FAFC]">{inv.name}</span>
                            <span className="text-[10px] text-[#D4AF37] bg-[#243244] px-1.5 py-0.5 rounded">
                              {inv.costPerUnit} ETB/{inv.unit}
                            </span>
                          </div>
                          <span className="text-[10px] text-[#22C55E] font-bold">+ Add to Recipe</span>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* Selected Ingredients Portions Table */}
                {selectedIngredients.length === 0 ? (
                  <div className="p-6 text-center border-2 border-dashed border-white/10 rounded-xl text-xs text-[#94A3B8]">
                    No ingredients added yet. Search above to add raw ingredients to this product recipe.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-[#1E293B] text-[#CBD5E1] text-[10px] uppercase font-bold tracking-wider">
                        <tr>
                          <th className="p-2.5">Raw Ingredient</th>
                          <th className="p-2.5">Portion Quantity</th>
                          <th className="p-2.5">Live Unit Price</th>
                          <th className="p-2.5">Portion Cost</th>
                          <th className="p-2.5 text-center">Wana Gbat (Main)</th>
                          <th className="p-2.5 text-right">Remove</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {selectedIngredients.map((item) => {
                          const liveCost = inventory.find((i) => i.id === item.inventoryId)?.costPerUnit || item.unitCost;
                          const portionTotal = item.qty * liveCost;

                          return (
                            <tr key={item.inventoryId} className="hover:bg-[#1E293B]/50">
                              <td className="p-2.5 font-bold text-[#F8FAFC]">
                                {item.ingredientName}
                                <span className="text-[10px] text-[#94A3B8] block font-mono">{item.sku}</span>
                              </td>

                              <td className="p-2.5">
                                <div className="flex items-center gap-1.5">
                                  <input
                                    type="number"
                                    step="any"
                                    min="0.001"
                                    value={item.qty}
                                    onChange={(e) =>
                                      handleUpdatePortionQty(item.inventoryId, parseFloat(e.target.value) || 0)
                                    }
                                    className="w-20 h-9 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg text-center text-xs font-bold focus:outline-none focus:border-[#D4AF37]"
                                  />
                                  <span className="text-[#94A3B8] text-xs">{item.unit}</span>
                                </div>
                              </td>

                              <td className="p-2.5 text-[#D4AF37] font-semibold">
                                {liveCost} ETB/{item.unit}
                              </td>

                              <td className="p-2.5 font-extrabold text-[#F8FAFC]">
                                {portionTotal.toFixed(2)} ETB
                              </td>

                              <td className="p-2.5 text-center">
                                <label className="inline-flex items-center gap-1.5 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={item.isMainIngredient}
                                    onChange={() => handleToggleMainIngredient(item.inventoryId)}
                                    className="w-4 h-4 accent-[#D4AF37] rounded cursor-pointer"
                                  />
                                  {item.isMainIngredient && (
                                    <span className="text-[10px] bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 font-bold px-1.5 py-0.5 rounded">
                                      Main
                                    </span>
                                  )}
                                </label>
                              </td>

                              <td className="p-2.5 text-right">
                                <button
                                  type="button"
                                  onClick={() => handleRemoveIngredientFromRecipe(item.inventoryId)}
                                  className="text-gray-400 hover:text-[#EF4444] p-1"
                                >
                                  <Trash2 size={16} />
                                </button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* PROFIT MARGIN & SELLING PRICE ENGINE */}
              <div className="bg-[#1E293B] p-4 sm:p-5 rounded-2xl border border-[#D4AF37]/40 space-y-4">
                <h3 className="text-xs font-extrabold text-[#D4AF37] uppercase tracking-wider flex items-center gap-2">
                  <Calculator size={18} />
                  Automatic Pricing Engine (Ye Product Waga Sira)
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Step 1: Total Raw Material Cost */}
                  <div className="bg-[#243244] p-3.5 rounded-xl border border-white/10">
                    <span className="text-[#94A3B8] text-[10px] uppercase font-bold block mb-1">
                      Total Ingredient Cost (Teklala Gbat Waga)
                    </span>
                    <span className="text-xl font-extrabold text-[#F8FAFC]">
                      {totalIngredientCost.toFixed(2)} ETB
                    </span>
                  </div>

                  {/* Step 2: Target Profit Margin % */}
                  <div className="bg-[#243244] p-3.5 rounded-xl border border-white/10">
                    <label className="text-[#94A3B8] text-[10px] uppercase font-bold block mb-1">
                      Desired Profit Margin % (Materfewn %)
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min="0"
                        max="1000"
                        value={targetMarginPercent}
                        onChange={(e) => setTargetMarginPercent(parseFloat(e.target.value) || 0)}
                        className="w-full h-10 bg-[#1E293B] text-[#D4AF37] border border-white/10 rounded-lg px-3 text-sm font-extrabold focus:outline-none focus:border-[#D4AF37]"
                      />
                      <span className="text-xs font-bold text-[#D4AF37]">%</span>
                    </div>
                  </div>

                  {/* Step 3: Auto Recommended Selling Price */}
                  <div className="bg-[#D4AF37]/20 p-3.5 rounded-xl border border-[#D4AF37]">
                    <span className="text-[#D4AF37] text-[10px] uppercase font-bold block mb-1">
                      Calculated Selling Price (Meshecha Waga)
                    </span>
                    <span className="text-2xl font-black text-[#F8FAFC]">
                      {recommendedSellingPrice} ETB
                    </span>
                  </div>
                </div>
              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-5 py-3 rounded-xl bg-[#243244] hover:bg-[#2F4158] text-[#CBD5E1] text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] text-xs font-extrabold shadow-lg flex items-center gap-2"
                >
                  <CheckCircle2 size={18} />
                  <span>Save Product & Price (Save Mareg)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
