import React, { useState } from 'react';
import { UserRole } from '../../types';
import {
  LayoutDashboard,
  ShoppingBag,
  Utensils,
  BookOpen,
  PackageCheck,
  Truck,
  Calculator,
  Users,
  Recycle,
  BarChart3,
  Settings,
  Shield,
  Coffee,
  LogOut,
  Menu as MenuIcon,
  X,
  Layers,
  Store as StoreIcon,
  Receipt,
  UserCheck,
  ClipboardList,
  ArrowRightLeft,
  Calendar,
  CreditCard,
  ShieldAlert,
  UtensilsCrossed,
  BarChart2,
} from 'lucide-react';
import { BrandLogo } from '../BrandLogo';

interface ERPLayoutProps {
  currentUserRole: UserRole;
  setCurrentUserRole: (role: UserRole) => void;
  activeModule: string;
  setActiveModule: (module: string) => void;
  onExitERP: () => void;
  children: React.ReactNode;
}

export const ERPLayout: React.FC<ERPLayoutProps> = ({
  currentUserRole,
  setCurrentUserRole,
  activeModule,
  setActiveModule,
  onExitERP,
  children,
}) => {
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  const erpModules = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['Admin', 'Manager'] },
    { id: 'pos', label: 'POS Terminal & Wana Gbat', icon: Utensils, roles: ['Admin', 'Manager', 'Cashier'] },
    { id: 'order_vouchers', label: 'Order Vouchers & Sales', icon: ShoppingBag, roles: ['Admin', 'Manager', 'Cashier'] },
    { id: 'kds', label: 'Kitchen Orders (KDS)', icon: Coffee, roles: ['Admin', 'Manager', 'Kitchen'] },
    { id: 'orders', label: 'Live Orders Queue', icon: ShoppingBag, roles: ['Admin', 'Manager', 'Cashier'] },
    { id: 'inventory', label: 'Raw Ingredients (Gbatochen)', icon: PackageCheck, roles: ['Admin', 'Manager'] },
    { id: 'bincard', label: 'Store Bin Card Ledger', icon: CreditCard, roles: ['Admin', 'Manager'] },
    { id: 'store_balance', label: 'Store Balance & Expiry', icon: Calendar, roles: ['Admin', 'Manager'] },
    { id: 'store_requests', label: 'Store Requests', icon: ClipboardList, roles: ['Admin', 'Manager', 'Kitchen'] },
    { id: 'store_transfers', label: 'Store Transfers', icon: ArrowRightLeft, roles: ['Admin', 'Manager'] },
    { id: 'damage', label: 'Damage & Spoilage', icon: ShieldAlert, roles: ['Admin', 'Manager', 'Kitchen'] },
    { id: 'staff_food', label: 'Staff Meal Allowances', icon: UtensilsCrossed, roles: ['Admin', 'Manager', 'Kitchen'] },
    { id: 'product_costing', label: 'Product Costing (Product Mmezegbbet)', icon: Calculator, roles: ['Admin', 'Manager'] },
    { id: 'stock_in', label: 'Stock In & Vouchers', icon: Receipt, roles: ['Admin', 'Manager'] },
    { id: 'categories', label: 'Categories Management', icon: Layers, roles: ['Admin', 'Manager'] },
    { id: 'stores', label: 'Stores & Warehouses', icon: StoreIcon, roles: ['Admin', 'Manager'] },
    { id: 'suppliers', label: 'Suppliers & Vendors', icon: Truck, roles: ['Admin', 'Manager'] },
    { id: 'customers', label: 'Customers Registry', icon: UserCheck, roles: ['Admin', 'Manager', 'Cashier'] },
    { id: 'menu_mgr', label: 'Menu Catalog', icon: BookOpen, roles: ['Admin', 'Manager'] },
    { id: 'hr', label: 'HR & Payroll', icon: Users, roles: ['Admin', 'Manager'] },
    { id: 'epr', label: 'EPR Compliance', icon: Recycle, roles: ['Admin', 'Manager'] },
    { id: 'reports', label: 'Sales & P&L Reports', icon: BarChart2, roles: ['Admin', 'Manager'] },
    { id: 'settings', label: 'Settings & User Mgmt', icon: Settings, roles: ['Admin'] },
  ];


  const allowedModules = erpModules.filter((m) => m.roles.includes(currentUserRole));

  const handleModuleSelect = (id: string) => {
    setActiveModule(id);
    setMobileDrawerOpen(false);
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full overflow-y-auto">
      {/* Header & Logo Area */}
      <div className="p-5 sm:p-6 border-b border-[#262A34] bg-[#13151B]">
        <BrandLogo size="sm" variant="light" showSubtitle={true} />

        {/* User Access Badge / Switcher */}
        <div className="mt-4 flex items-center justify-between bg-[#1C2029] px-3.5 py-2.5 rounded-2xl border border-[#D4AF37]/30 shadow-xs">
          <div className="flex items-center gap-2 text-xs">
            <Shield size={14} className="text-[#D4AF37]" />
            <span className="font-semibold text-[#D4AF37]">{currentUserRole} Mode</span>
          </div>
          <select
            value={currentUserRole}
            onChange={(e) => setCurrentUserRole(e.target.value as UserRole)}
            className="bg-transparent text-xs font-bold text-[#EAEAEA] focus:outline-none cursor-pointer py-1"
          >
            <option value="Admin" className="bg-[#171A21] text-white">Admin</option>
            <option value="Manager" className="bg-[#171A21] text-white">Manager</option>
            <option value="Cashier" className="bg-[#171A21] text-white">Cashier</option>
            <option value="Kitchen" className="bg-[#171A21] text-white">Kitchen</option>
          </select>
        </div>
      </div>

      {/* Navigation List */}
      <nav className="p-4 space-y-1.5 flex-1">
        <span className="text-[10px] font-bold uppercase tracking-widest text-[#9CA3AF] px-3 mb-2 block">
          Management Portal
        </span>
        {allowedModules.map((mod) => {
          const Icon = mod.icon;
          const isActive = activeModule === mod.id;

          return (
            <button
              key={mod.id}
              onClick={() => handleModuleSelect(mod.id)}
              className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-semibold flex items-center gap-3.5 transition-all duration-250 min-h-[44px] ${
                isActive
                  ? 'bg-[#D4AF37] text-[#0F1115] shadow-[0_0_20px_rgba(212,175,55,0.35)] font-bold scale-[1.01]'
                  : 'text-[#9CA3AF] hover:bg-white/5 hover:text-[#EAEAEA] hover:translate-x-1'
              }`}
            >
              <Icon
                size={18}
                className={isActive ? 'text-[#0F1115]' : 'text-[#9CA3AF] group-hover:text-[#D4AF37]'}
              />
              <span>{mod.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer Exit */}
      <div className="p-5 border-t border-[#262A34] bg-[#13151B]">
        <button
          onClick={onExitERP}
          className="w-full bg-white/5 hover:bg-white/10 text-[#EAEAEA] border border-white/10 hover:border-[#D4AF37]/50 py-3.5 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 transition-all duration-250 min-h-[48px]"
        >
          <LogOut size={16} className="text-[#D4AF37]" />
          <span>Return to Main Website</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#111827] flex flex-col lg:flex-row text-[#EAEAEA] font-sans antialiased overflow-x-hidden">
      {/* Mobile / Tablet Sticky Header with Hamburger */}
      <header className="lg:hidden sticky top-0 z-40 bg-[#171A21] border-b border-[#262A34] px-4 py-3 flex items-center justify-between shadow-lg">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileDrawerOpen(true)}
            className="p-2 text-[#D4AF37] bg-[#1C2029] hover:bg-white/10 rounded-xl border border-[#D4AF37]/30 transition-colors"
            aria-label="Open Navigation Menu"
          >
            <MenuIcon size={22} />
          </button>
          <BrandLogo size="xs" variant="light" />
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onExitERP}
            className="px-3 py-1.5 bg-[#1C2029] text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl text-xs font-bold flex items-center gap-1.5 hover:bg-[#D4AF37] hover:text-[#0F1115] transition-all"
          >
            <LogOut size={14} />
            <span className="hidden sm:inline">Exit</span>
          </button>
        </div>
      </header>

      {/* Mobile Drawer Backdrop */}
      {mobileDrawerOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/80 backdrop-blur-xs z-50 transition-opacity duration-300"
          onClick={() => setMobileDrawerOpen(false)}
        />
      )}

      {/* Mobile Drawer Off-Canvas */}
      <aside
        className={`lg:hidden fixed top-0 left-0 bottom-0 w-80 max-w-[85vw] bg-[#171A21] z-50 shadow-2xl transition-transform duration-300 transform ${
          mobileDrawerOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={() => setMobileDrawerOpen(false)}
            className="p-2 text-[#9CA3AF] hover:text-white rounded-xl bg-[#13151B] border border-white/10"
            aria-label="Close Navigation Menu"
          >
            <X size={20} />
          </button>
        </div>
        <SidebarContent />
      </aside>

      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:flex w-72 bg-[#171A21] text-[#EAEAEA] flex-col justify-between shrink-0 shadow-2xl border-r border-[#262A34] sticky top-0 h-screen z-20">
        <SidebarContent />
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-3 sm:p-6 lg:p-10 overflow-y-auto max-h-[calc(100vh-57px)] lg:max-h-screen bg-[#111827]">
        <div className="max-w-[1400px] mx-auto space-y-6 sm:space-y-8">
          {children}
        </div>
      </main>
    </div>
  );
};


