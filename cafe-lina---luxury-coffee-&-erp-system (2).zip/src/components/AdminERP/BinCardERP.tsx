import React, { useState } from 'react';
import { InventoryItem, BinCardEntry, Order, StoreRecord } from '../../types';
import {
  CreditCard,
  Search,
  Calendar,
  ArrowDownRight,
  ArrowUpRight,
  ShoppingBag,
  AlertTriangle,
  Layers,
  Filter,
  Building2,
  Store,
  CheckCircle2,
  MapPin,
  User,
  Package
} from 'lucide-react';

interface BinCardERPProps {
  inventory: InventoryItem[];
  binCards: BinCardEntry[];
  orders: Order[];
  stores?: StoreRecord[];
}

export const BinCardERP: React.FC<BinCardERPProps> = ({
  inventory,
  binCards,
  orders,
  stores = [],
}) => {
  const [selectedStoreName, setSelectedStoreName] = useState<string>('All');
  const [selectedInventoryId, setSelectedInventoryId] = useState<string>(
    inventory[0]?.id || ''
  );
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<string>('All');

  // Available store list
  const availableStoreNames = Array.from(
    new Set([
      'All',
      ...stores.map((s) => s.name),
      ...inventory.map((i) => i.storeName).filter((s): s is string => Boolean(s)),
      'Bole Main Central Store',
      'Kazanchis Bakery Lab & Cold Room',
    ])
  );

  const selectedStoreObj = stores.find((s) => s.name === selectedStoreName);

  // Filter inventory by search and selected store
  const filteredInventory = inventory.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.sku.toLowerCase().includes(search.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedStoreName === 'All') return true;
    const itemStore = item.storeName || 'Bole Main Central Store';
    return itemStore === selectedStoreName;
  });

  // Ensure an item is selected if current selection is filtered out
  const effectiveSelectedId =
    filteredInventory.some((i) => i.id === selectedInventoryId)
      ? selectedInventoryId
      : filteredInventory[0]?.id || inventory[0]?.id || '';

  const selectedItem = inventory.find((i) => i.id === effectiveSelectedId) || inventory[0];

  // Bin card entries for selected item
  const currentItemBinEntries = binCards.filter(
    (b) => b.inventoryId === effectiveSelectedId
  );

  // Filter entries by store and transaction type
  const filteredEntries = currentItemBinEntries.filter((e) => {
    if (filterType !== 'All' && e.transactionType !== filterType) {
      return false;
    }
    if (selectedStoreName === 'All') return true;

    const entryStore = e.storeName || selectedItem?.storeName || 'Bole Main Central Store';
    return entryStore === selectedStoreName;
  });

  // Derive order usages for this ingredient based on orders placed
  const orderUsages = orders.flatMap((ord) => {
    return ord.items.map((it) => ({
      orderId: ord.id,
      date: ord.createdAt,
      productName: it.menuItem.name,
      productImage: it.menuItem.image,
      category: it.menuItem.category,
      qtyOrdered: it.quantity,
      estimatedIngredientUsed: (it.quantity * 0.15).toFixed(2),
    }));
  });

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Raw Material Movement Ledger
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <CreditCard className="text-[#D4AF37]" size={28} />
            Store Bin Card Ledger (Ye Stor Bin Card)
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Select a Store Location and Ingredient (Gbat) to view store-specific balance, stock-in history, and product consumption.
          </p>
        </div>

        {selectedItem && (
          <div className="bg-[#243244] p-3 px-5 rounded-2xl border border-white/10 shadow-md flex items-center gap-4">
            <div>
              <span className="text-[10px] text-[#94A3B8] uppercase block font-bold">
                {selectedStoreName === 'All' ? 'Total Stock Balance' : `${selectedStoreName} Balance`}
              </span>
              <span className="text-xl font-extrabold text-[#22C55E]">
                {selectedItem.stockQty} {selectedItem.unit}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* STORE SELECTION BAR */}
      <div className="bg-[#243244] p-4 rounded-[20px] border border-[#D4AF37]/30 shadow-lg space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Building2 className="text-[#D4AF37]" size={20} />
            <div>
              <h3 className="text-xs font-bold text-[#F8FAFC] uppercase tracking-wider">
                Select Store Location (Store Memret)
              </h3>
              <p className="text-[11px] text-[#94A3B8]">
                Filtering Bin Card Ledger by specific warehouse/branch store
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-[#CBD5E1] hidden sm:inline">Selected:</span>
            <select
              value={selectedStoreName}
              onChange={(e) => setSelectedStoreName(e.target.value)}
              className="bg-[#1E293B] text-[#D4AF37] border border-[#D4AF37]/50 rounded-xl px-3 py-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#D4AF37] cursor-pointer"
            >
              {availableStoreNames.map((st) => (
                <option key={st} value={st} className="bg-[#1E293B] text-white">
                  {st === 'All' ? '🏬 All Store Locations (Overall)' : `🏬 ${st}`}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Store Quick Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/5">
          {availableStoreNames.map((st) => {
            const isSelected = selectedStoreName === st;
            return (
              <button
                key={st}
                type="button"
                onClick={() => setSelectedStoreName(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#D4AF37] text-[#0f0f0f] shadow-md'
                    : 'bg-[#1E293B] text-[#CBD5E1] hover:bg-[#2A3B50] hover:text-white border border-white/10'
                }`}
              >
                <Store size={13} />
                <span>{st === 'All' ? 'All Stores' : st}</span>
                {isSelected && <CheckCircle2 size={13} className="ml-0.5" />}
              </button>
            );
          })}
        </div>

        {/* Store Location Detail Card if specific store selected */}
        {selectedStoreObj && (
          <div className="mt-2 p-3 bg-[#1E293B] rounded-xl border border-white/10 text-xs text-[#CBD5E1] grid grid-cols-1 sm:grid-cols-3 gap-2">
            <div className="flex items-center gap-2">
              <MapPin size={14} className="text-[#D4AF37] shrink-0" />
              <span className="truncate"><strong>Location:</strong> {selectedStoreObj.location}</span>
            </div>
            <div className="flex items-center gap-2">
              <User size={14} className="text-[#D4AF37] shrink-0" />
              <span className="truncate"><strong>Manager:</strong> {selectedStoreObj.managerName}</span>
            </div>
            <div className="flex items-center gap-2">
              <Package size={14} className="text-[#D4AF37] shrink-0" />
              <span className="truncate"><strong>Code:</strong> {selectedStoreObj.code} | {selectedStoreObj.capacity}</span>
            </div>
          </div>
        )}
      </div>

      {/* Main Grid: Left Ingredient Selector, Right Ledger */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ingredient List Selection Panel */}
        <div className="bg-[#243244] p-5 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
          <div className="flex justify-between items-center">
            <h2 className="text-sm font-serif font-bold text-[#F8FAFC]">Select Ingredient (Gbat)</h2>
            <span className="text-[10px] text-[#D4AF37] bg-[#1E293B] px-2 py-0.5 rounded font-mono font-bold">
              {filteredInventory.length} SKUs
            </span>
          </div>

          <div className="relative">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search ingredient or SKU..."
              className="w-full h-10 bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl pl-9 pr-3 text-xs focus:outline-none focus:border-[#D4AF37]"
            />
            <Search size={15} className="absolute left-3 top-3 text-[#94A3B8]" />
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {filteredInventory.length === 0 ? (
              <div className="text-center py-8 text-gray-400 text-xs">
                No raw ingredients found for store "{selectedStoreName}".
              </div>
            ) : (
              filteredInventory.map((inv) => {
                const isSelected = inv.id === effectiveSelectedId;
                const itemStore = inv.storeName || 'Bole Main Central Store';
                return (
                  <button
                    key={inv.id}
                    onClick={() => setSelectedInventoryId(inv.id)}
                    className={`w-full p-3 rounded-xl border text-left transition-all flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-[#1E293B] border-[#D4AF37] shadow-md ring-1 ring-[#D4AF37]'
                        : 'bg-[#1E293B]/50 border-white/5 hover:bg-[#1E293B] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={inv.image}
                        alt={inv.name}
                        className="w-10 h-10 object-cover rounded-lg shrink-0 border border-white/10"
                      />
                      <div className="min-w-0">
                        <span className="font-bold text-xs text-[#F8FAFC] truncate block">{inv.name}</span>
                        <span className="text-[10px] text-[#94A3B8] flex items-center gap-1">
                          <span>SKU: {inv.sku}</span>
                        </span>
                        <span className="text-[9px] text-[#D4AF37] bg-white/5 px-1.5 py-0.5 rounded mt-0.5 inline-block truncate max-w-[140px]">
                          🏬 {itemStore}
                        </span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-xs font-extrabold text-[#22C55E] block">
                        {inv.stockQty} {inv.unit}
                      </span>
                      <span className="text-[9px] text-[#94A3B8]">Remain</span>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Detailed Bin Card Ledger Panel */}
        <div className="lg:col-span-2 space-y-6">
          {selectedItem ? (
            <>
              {/* Selected Ingredient Summary Banner */}
              <div className="bg-[#243244] p-5 rounded-[24px] border border-white/10 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <img
                    src={selectedItem.image}
                    alt={selectedItem.name}
                    className="w-16 h-16 object-cover rounded-2xl border-2 border-[#D4AF37]"
                  />
                  <div>
                    <span className="text-[10px] text-[#D4AF37] font-mono font-bold uppercase block">
                      SKU: {selectedItem.sku} | {selectedItem.category}
                    </span>
                    <h2 className="text-lg font-serif font-bold text-[#F8FAFC]">{selectedItem.name}</h2>
                    <p className="text-xs text-[#94A3B8]">
                      Store: <strong className="text-[#D4AF37]">{selectedItem.storeName || 'Bole Main Central Store'}</strong> | Unit Cost: {selectedItem.costPerUnit} ETB
                    </p>
                  </div>
                </div>

                <div className="bg-[#1E293B] p-3 rounded-xl border border-white/10 text-center px-5">
                  <span className="text-[10px] text-[#94A3B8] uppercase block">Valuation</span>
                  <span className="text-base font-extrabold text-[#D4AF37]">
                    {(selectedItem.stockQty * selectedItem.costPerUnit).toLocaleString()} ETB
                  </span>
                </div>
              </div>

              {/* Transactions Ledger Log */}
              <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/10">
                  <div>
                    <h3 className="text-base font-serif font-bold text-[#F8FAFC]">
                      Bin Card Movement History
                    </h3>
                    <p className="text-[11px] text-[#94A3B8]">
                      {selectedStoreName === 'All'
                        ? 'Showing entries across all stores'
                        : `Filtered for store: ${selectedStoreName}`}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <Filter size={14} className="text-[#D4AF37]" />
                    <select
                      value={filterType}
                      onChange={(e) => setFilterType(e.target.value)}
                      className="bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-[#D4AF37]"
                    >
                      <option value="All">All Transactions</option>
                      <option value="Stock In">Stock In</option>
                      <option value="Order Sales Consumption">Order Sales Consumption</option>
                      <option value="Initial Stock">Initial Stock</option>
                      <option value="Damage Spoilage">Damage / Spoilage</option>
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  {filteredEntries.length === 0 ? (
                    <div className="text-center py-10 bg-[#1E293B]/40 rounded-2xl border border-white/5 space-y-2">
                      <CreditCard className="mx-auto text-gray-500" size={32} />
                      <p className="text-xs text-gray-300 font-semibold">
                        No bin card transaction history found for {selectedItem.name}
                        {selectedStoreName !== 'All' && ` at ${selectedStoreName}`}.
                      </p>
                      <p className="text-[11px] text-gray-500">
                        Try selecting "All Stores" or choose a different transaction filter.
                      </p>
                    </div>
                  ) : (
                    <table className="w-full text-left text-xs text-[#CBD5E1]">
                      <thead className="bg-[#1E293B] text-[#94A3B8] uppercase text-[10px] font-extrabold tracking-wider border-b border-white/10">
                        <tr>
                          <th className="py-3 px-3">Date</th>
                          <th className="py-3 px-3">Store Location</th>
                          <th className="py-3 px-3">Type</th>
                          <th className="py-3 px-3">Reference / Product</th>
                          <th className="py-3 px-3 text-right">In (+</th>
                          <th className="py-3 px-3 text-right">Out (-</th>
                          <th className="py-3 px-3 text-right">Balance</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 font-medium">
                        {filteredEntries.map((e) => {
                          const entryStore = e.storeName || selectedItem.storeName || 'Bole Main Central Store';
                          return (
                            <tr key={e.id} className="hover:bg-[#1E293B]/50 transition-colors">
                              <td className="py-3 px-3 text-[11px] font-mono">{e.date}</td>
                              <td className="py-3 px-3 text-[11px]">
                                <span className="text-[10px] bg-[#1E293B] text-[#D4AF37] px-2 py-0.5 rounded border border-[#D4AF37]/30 font-semibold inline-flex items-center gap-1">
                                  <Building2 size={10} />
                                  {entryStore}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                <span
                                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                    e.qtyIn > 0
                                      ? 'bg-[#22C55E]/20 text-[#22C55E]'
                                      : 'bg-red-500/20 text-red-400'
                                  }`}
                                >
                                  {e.transactionType}
                                </span>
                              </td>
                              <td className="py-3 px-3">
                                {e.productName ? (
                                  <div className="flex items-center gap-2">
                                    {e.productImage && (
                                      <img
                                        src={e.productImage}
                                        alt={e.productName}
                                        className="w-6 h-6 object-cover rounded"
                                      />
                                    )}
                                    <span className="font-bold text-[#F8FAFC]">{e.productName}</span>
                                  </div>
                                ) : (
                                  <span className="font-mono text-[#D4AF37]">{e.referenceId}</span>
                                )}
                              </td>
                              <td className="py-3 px-3 text-right font-extrabold text-[#22C55E]">
                                {e.qtyIn > 0 ? `+${e.qtyIn} ${e.unit}` : '-'}
                              </td>
                              <td className="py-3 px-3 text-right font-extrabold text-red-400">
                                {e.qtyOut > 0 ? `-${e.qtyOut} ${e.unit}` : '-'}
                              </td>
                              <td className="py-3 px-3 text-right font-extrabold text-[#D4AF37]">
                                {e.balanceAfter} {e.unit}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  )}
                </div>
              </div>

              {/* Product Consumption breakdown (Lemn lemn product endetetekemkut Kene product photo) */}
              <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
                <div className="border-b border-white/10 pb-3">
                  <h3 className="text-base font-serif font-bold text-[#F8FAFC]">
                    Products Using {selectedItem.name} (Lemn lemn product endetetekemkut)
                  </h3>
                  <p className="text-xs text-[#94A3B8]">
                    List of finished menu products and recipes consuming this raw ingredient.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {orderUsages.slice(0, 4).map((u, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-[#1E293B] rounded-xl border border-white/10 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3">
                        <img
                          src={u.productImage}
                          alt={u.productName}
                          className="w-12 h-12 object-cover rounded-xl border border-white/10"
                        />
                        <div>
                          <span className="font-bold text-xs text-[#F8FAFC] block">{u.productName}</span>
                          <span className="text-[10px] text-[#94A3B8]">{u.category}</span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-bold text-[#D4AF37] block">
                          -{u.estimatedIngredientUsed} {selectedItem.unit}
                        </span>
                        <span className="text-[9px] text-[#94A3B8]">per order</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-[#243244] p-10 rounded-[24px] border border-white/10 text-center text-gray-400">
              Select an ingredient on the left to view its bin card movement ledger.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
