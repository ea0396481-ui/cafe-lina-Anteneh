import React, { useState } from 'react';
import { InventoryItem, StoreRecord, StoreTransferVoucher, StoreTransferItem } from '../../types';
import { ArrowRightLeft, Plus, Trash2, Eye, Edit, Printer, CheckCircle2, X, Search } from 'lucide-react';

interface StoreTransferERPProps {
  inventory: InventoryItem[];
  stores: StoreRecord[];
  transfers: StoreTransferVoucher[];
  onAddTransfer: (transfer: StoreTransferVoucher) => void;
  onUpdateTransfer: (transfer: StoreTransferVoucher) => void;
  onDeleteTransfer: (voucherId: string) => void;
}

export const StoreTransferERP: React.FC<StoreTransferERPProps> = ({
  inventory,
  stores,
  transfers,
  onAddTransfer,
  onUpdateTransfer,
  onDeleteTransfer,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVoucherForView, setSelectedVoucherForView] = useState<StoreTransferVoucher | null>(null);
  const [editingVoucher, setEditingVoucher] = useState<StoreTransferVoucher | null>(null);

  // Transfer Form State
  const [fromStore, setFromStore] = useState(stores[0]?.name || 'Bole Main Central Store');
  const [toStore, setToStore] = useState(stores[1]?.name || 'Kazanchis Bakery Lab & Cold Room');
  const [transferredBy, setTransferredBy] = useState('Store Manager Dawit');
  const [driverOrHandler, setDriverOrHandler] = useState('Ermias Driver');
  const [remark, setRemark] = useState('');

  // Selected ingredients with transfer quantities
  const [selectedItems, setSelectedItems] = useState<{ [invId: string]: number }>({});
  const [itemSearch, setItemSearch] = useState('');

  const handleToggleItem = (inv: InventoryItem) => {
    setSelectedItems((prev) => {
      const copy = { ...prev };
      if (copy[inv.id] !== undefined) {
        delete copy[inv.id];
      } else {
        copy[inv.id] = 1;
      }
      return copy;
    });
  };

  const handleQtyChange = (invId: string, qty: number) => {
    if (qty <= 0) return;
    setSelectedItems((prev) => ({ ...prev, [invId]: qty }));
  };

  const handleSubmitTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const itemIds = Object.keys(selectedItems);
    if (itemIds.length === 0 || fromStore === toStore) return;

    const trnItems: StoreTransferItem[] = itemIds.map((id) => {
      const inv = inventory.find((i) => i.id === id)!;
      return {
        inventoryId: inv.id,
        ingredientName: inv.name,
        sku: inv.sku,
        qtyTransferred: selectedItems[id],
        unit: inv.unit,
      };
    });

    const newVoucher: StoreTransferVoucher = {
      voucherId: `TRN-2026-${Math.floor(100 + Math.random() * 900)}`,
      date: new Date().toISOString().split('T')[0],
      fromStore,
      toStore,
      transferredBy,
      driverOrHandler,
      remark,
      createdTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: trnItems,
    };

    onAddTransfer(newVoucher);
    setIsModalOpen(false);
    setSelectedItems({});
    setRemark('');
  };

  const filteredInventory = inventory.filter((i) =>
    i.name.toLowerCase().includes(itemSearch.toLowerCase()) || i.sku.toLowerCase().includes(itemSearch.toLowerCase())
  );

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Inter-Store Logistics
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <ArrowRightLeft className="text-[#D4AF37]" size={28} />
            Store-to-Store Ingredient Transfers (Transfers)
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Batch transfer multiple raw ingredients between central warehouses and branch labs with transfer vouchers.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-5 py-3 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg min-h-[44px]"
        >
          <Plus size={18} />
          <span>New Multi-Ingredient Transfer</span>
        </button>
      </div>

      {/* Transfer Vouchers Log Table */}
      <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
        <h2 className="text-lg font-serif font-bold text-[#F8FAFC]">Transfer Vouchers Registry</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#CBD5E1]">
            <thead className="bg-[#1E293B] text-[#94A3B8] uppercase text-[10px] font-extrabold tracking-wider border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">Voucher ID</th>
                <th className="py-3.5 px-4">From Source Store</th>
                <th className="py-3.5 px-4">To Destination Store</th>
                <th className="py-3.5 px-4">Transferred By</th>
                <th className="py-3.5 px-4">Items Count</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {transfers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-[#94A3B8]">
                    No store transfer vouchers recorded yet.
                  </td>
                </tr>
              ) : (
                transfers.map((t) => (
                  <tr key={t.voucherId} className="hover:bg-[#1E293B]/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-[#D4AF37]">{t.voucherId}</td>
                    <td className="py-3.5 px-4 font-bold text-[#F8FAFC]">{t.fromStore}</td>
                    <td className="py-3.5 px-4 font-bold text-[#22C55E]">{t.toStore}</td>
                    <td className="py-3.5 px-4">{t.transferredBy}</td>
                    <td className="py-3.5 px-4 font-bold text-[#D4AF37]">{t.items.length} Items</td>
                    <td className="py-3.5 px-4">
                      <span>{t.date}</span> <span className="text-[10px] text-[#94A3B8]">{t.createdTime}</span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => setSelectedVoucherForView(t)}
                          className="p-2 bg-[#1E293B] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] rounded-lg transition-all"
                          title="View Voucher"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          onClick={() => setEditingVoucher(t)}
                          className="p-2 bg-[#1E293B] text-[#3B82F6] hover:bg-[#3B82F6] hover:text-white rounded-lg transition-all"
                          title="Edit Voucher"
                        >
                          <Edit size={15} />
                        </button>
                        <button
                          onClick={() => onDeleteTransfer(t.voucherId)}
                          className="p-2 bg-[#1E293B] text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-all"
                          title="Delete Voucher"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: Create Multi-Item Transfer Voucher */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={handleSubmitTransfer}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-2xl w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg">Create Batch Store Transfer Voucher</h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">From Source Store *</label>
                <select
                  value={fromStore}
                  onChange={(e) => setFromStore(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {stores.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">To Destination Store *</label>
                <select
                  value={toStore}
                  onChange={(e) => setToStore(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  {stores.map((s) => (
                    <option key={s.id} value={s.name}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Transferred By *</label>
                <input
                  type="text"
                  required
                  value={transferredBy}
                  onChange={(e) => setTransferredBy(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Driver / Handler</label>
                <input
                  type="text"
                  value={driverOrHandler}
                  onChange={(e) => setDriverOrHandler(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>
            </div>

            {/* Select Multiple Ingredients for Transfer */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="block text-xs font-bold text-[#D4AF37] uppercase">
                  Select Ingredients to Transfer ({Object.keys(selectedItems).length} Selected)
                </label>

                <div className="relative">
                  <input
                    type="text"
                    value={itemSearch}
                    onChange={(e) => setItemSearch(e.target.value)}
                    placeholder="Search ingredient..."
                    className="w-48 h-8 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-lg pl-8 pr-2 text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                  <Search size={14} className="absolute left-2.5 top-2 text-[#94A3B8]" />
                </div>
              </div>

              <div className="max-h-52 overflow-y-auto border border-white/10 rounded-xl p-2 bg-[#243244] space-y-1.5">
                {filteredInventory.map((inv) => {
                  const isChecked = selectedItems[inv.id] !== undefined;
                  return (
                    <div
                      key={inv.id}
                      className={`p-2.5 rounded-lg flex items-center justify-between text-xs border transition-all ${
                        isChecked
                          ? 'bg-[#1E293B] border-[#D4AF37] text-[#F8FAFC]'
                          : 'bg-[#1E293B]/50 border-white/5 text-[#CBD5E1] hover:bg-[#1E293B]'
                      }`}
                    >
                      <label className="flex items-center gap-2 cursor-pointer flex-1">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleItem(inv)}
                          className="w-4 h-4 accent-[#D4AF37] rounded"
                        />
                        <div>
                          <span className="font-bold block">{inv.name}</span>
                          <span className="text-[10px] text-[#94A3B8]">
                            SKU: {inv.sku} | Avail Stock: {inv.stockQty} {inv.unit}
                          </span>
                        </div>
                      </label>

                      {isChecked && (
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] text-[#94A3B8]">Transfer Qty:</span>
                          <input
                            type="number"
                            min={1}
                            value={selectedItems[inv.id]}
                            onChange={(e) => handleQtyChange(inv.id, Number(e.target.value))}
                            className="w-16 h-7 bg-[#243244] text-[#D4AF37] font-bold border border-[#D4AF37]/40 rounded px-2 text-xs focus:outline-none"
                          />
                          <span className="text-xs text-[#94A3B8]">{inv.unit}</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={Object.keys(selectedItems).length === 0 || fromStore === toStore}
                className="flex-1 h-11 bg-[#D4AF37] hover:bg-[#F6C453] disabled:opacity-40 text-[#0F172A] rounded-xl text-xs font-extrabold shadow-md"
              >
                Confirm Transfer Voucher
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: View Transfer Voucher */}
      {selectedVoucherForView && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-lg w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-lg text-[#D4AF37]">Transfer Voucher Ticket</h3>
                <p className="text-xs text-[#94A3B8]">Voucher ID: {selectedVoucherForView.voucherId}</p>
              </div>
              <button onClick={() => setSelectedVoucherForView(null)} className="p-1 text-gray-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-2 text-xs text-[#CBD5E1]">
              <p>From: <strong className="text-[#F8FAFC]">{selectedVoucherForView.fromStore}</strong></p>
              <p>To: <strong className="text-[#22C55E]">{selectedVoucherForView.toStore}</strong></p>
              <p>Transferred By: <strong>{selectedVoucherForView.transferredBy}</strong></p>
              <p>Driver: <strong>{selectedVoucherForView.driverOrHandler}</strong></p>
              <p>Date: {selectedVoucherForView.date} {selectedVoucherForView.createdTime}</p>
            </div>

            <div className="border-t border-b border-white/10 py-3 space-y-2">
              <h4 className="text-xs font-extrabold text-[#D4AF37] uppercase">Transferred Ingredients</h4>
              {selectedVoucherForView.items.map((it, idx) => (
                <div key={idx} className="flex justify-between p-2 bg-[#243244] rounded-lg text-xs">
                  <div>
                    <span className="font-bold text-[#F8FAFC] block">{it.ingredientName}</span>
                    <span className="text-[10px] text-[#94A3B8]">SKU: {it.sku}</span>
                  </div>
                  <span className="font-extrabold text-[#D4AF37]">
                    {it.qtyTransferred} {it.unit}
                  </span>
                </div>
              ))}
            </div>

            <div className="flex gap-2 font-sans">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-[#D4AF37] text-[#0F172A] rounded-xl text-xs font-bold flex items-center justify-center gap-1"
              >
                <Printer size={15} /> Print Voucher
              </button>
              <button
                onClick={() => setSelectedVoucherForView(null)}
                className="flex-1 py-2.5 bg-[#243244] hover:bg-[#2F4158] text-[#F8FAFC] rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Edit Transfer Voucher */}
      {editingVoucher && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onUpdateTransfer(editingVoucher);
              setEditingVoucher(null);
            }}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg">Edit Transfer Voucher {editingVoucher.voucherId}</h3>
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Transferred By</label>
              <input
                type="text"
                value={editingVoucher.transferredBy}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, transferredBy: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Driver / Handler</label>
              <input
                type="text"
                value={editingVoucher.driverOrHandler || ''}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, driverOrHandler: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 h-11 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
