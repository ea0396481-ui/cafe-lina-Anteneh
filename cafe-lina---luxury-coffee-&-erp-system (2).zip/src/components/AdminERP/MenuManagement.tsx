import React, { useState } from 'react';
import { MenuItem, Category } from '../../types';
import { Plus, Trash2 } from 'lucide-react';

interface MenuManagementProps {
  menuItems: MenuItem[];
  onAddItem: (item: Partial<MenuItem>) => void;
  onDeleteItem: (id: string) => void;
}

export const MenuManagement: React.FC<MenuManagementProps> = ({
  menuItems,
  onAddItem,
  onDeleteItem,
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [name, setName] = useState('');
  const [category, setCategory] = useState<Category>('Coffee');
  const [price, setPrice] = useState(120);
  const [description, setDescription] = useState('');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    onAddItem({
      name,
      category,
      price: Number(price),
      currency: 'ETB',
      description,
      ingredients: ['Fresh Quality Blend'],
      calories: 180,
      prepTimeMinutes: 5,
      isAvailable: true,
      image: 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=800&q=80',
      barcode: `CL-${category.substring(0, 3).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`,
    });
    setShowAddModal(false);
    setName('');
    setDescription('');
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
            Catalog Management
          </span>
          <h1 className="text-2xl font-serif font-bold text-[#EAEAEA]">Menu & Products Catalog</h1>
          <p className="text-xs text-[#9CA3AF] mt-0.5">Manage item details, pricing, availability and barcodes</p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="bg-[#D4AF37] hover:bg-[#C5A028] text-[#0F1115] h-[50px] px-6 rounded-[16px] text-xs font-bold flex items-center justify-center gap-2 shadow-md transition-all duration-250 self-start sm:self-auto"
        >
          <Plus size={18} /> Add New Menu Item
        </button>
      </div>

      {/* Menu Table Card / Desktop View */}
      <div className="bg-[#243244] rounded-[22px] border border-white/10 overflow-hidden shadow-[0_12px_30px_rgba(0,0,0,0.35)]">
        {/* Desktop & Tablet Table */}
        <div className="hidden sm:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1E293B] border-b border-white/10 text-[#CBD5E1] uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="p-5">Product</th>
                <th className="p-5">Category</th>
                <th className="p-5">Price</th>
                <th className="p-5">Barcode</th>
                <th className="p-5">Status</th>
                <th className="p-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {menuItems.map((item) => (
                <tr key={item.id} className="hover:bg-[#2F4158] transition-colors">
                  <td className="p-5 flex items-center gap-4">
                    <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-[14px]" />
                    <div>
                      <span className="font-bold text-[#F8FAFC] text-sm block">{item.name}</span>
                      <span className="text-[#94A3B8] text-[11px]">{item.calories} kcal</span>
                    </div>
                  </td>
                  <td className="p-5">
                    <span className="bg-[#1E293B] text-[#D4AF37] border border-[#D4AF37]/30 font-bold px-3 py-1 rounded-[10px] text-[11px]">
                      {item.category}
                    </span>
                  </td>
                  <td className="p-5 font-extrabold text-[#D4AF37] text-sm">{item.price} ETB</td>
                  <td className="p-5 font-mono text-[#CBD5E1]">{item.barcode || 'CL-GEN-01'}</td>
                  <td className="p-5">
                    <span className="bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/30 text-[11px] font-bold px-3 py-1 rounded-full">
                      Available
                    </span>
                  </td>
                  <td className="p-5 text-right">
                    <button
                      onClick={() => onDeleteItem(item.id)}
                      className="p-2 text-[#EF4444] hover:bg-[#EF4444]/10 rounded-xl transition-colors cursor-pointer min-h-[44px] min-w-[44px] inline-flex items-center justify-center"
                      aria-label="Delete Item"
                    >
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Mobile Stacked Cards View (< 640px) */}
        <div className="sm:hidden divide-y divide-white/10">
          {menuItems.map((item) => (
            <div key={item.id} className="p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img src={item.image} alt={item.name} className="w-14 h-14 object-cover rounded-[14px]" />
                  <div>
                    <h3 className="font-bold text-[#F8FAFC] text-sm">{item.name}</h3>
                    <span className="text-[#94A3B8] text-[11px]">{item.calories} kcal • {item.barcode || 'CL-GEN-01'}</span>
                  </div>
                </div>
                <button
                  onClick={() => onDeleteItem(item.id)}
                  className="p-2.5 text-[#EF4444] bg-[#EF4444]/10 rounded-xl transition-colors"
                  aria-label="Delete Item"
                >
                  <Trash2 size={18} />
                </button>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                <span className="bg-[#1E293B] text-[#D4AF37] border border-[#D4AF37]/30 font-bold px-3 py-1 rounded-[10px]">
                  {item.category}
                </span>
                <span className="font-extrabold text-[#D4AF37] text-base">{item.price} ETB</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <form onSubmit={handleAdd} className="bg-[#1E293B] p-8 rounded-[24px] max-w-md w-full space-y-5 border border-white/10 shadow-2xl text-[#F8FAFC]">
            <div className="border-b border-white/10 pb-3">
              <h3 className="font-bold text-lg text-[#F8FAFC]">Add New Product</h3>
              <p className="text-xs text-[#CBD5E1]">Enter menu item details</p>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#CBD5E1] block">Item Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Specialty Yirgacheffe V60"
                className="w-full h-[56px] bg-[#243244] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-[16px] px-4 text-sm font-medium focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#CBD5E1] block">Price (ETB)</label>
              <input
                type="number"
                required
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
                className="w-full h-[56px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-[16px] px-4 text-sm font-medium focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
              />
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold text-[#CBD5E1] block">Description</label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Flavor notes, roast profile..."
                className="w-full bg-[#243244] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-[16px] p-4 text-sm font-medium focus:outline-none focus:border-[#D4AF37] focus:ring-2 focus:ring-[#D4AF37]/20 transition-all"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="submit"
                className="flex-1 h-[52px] bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-[16px] font-extrabold text-xs shadow-md transition-all cursor-pointer"
              >
                Save Product
              </button>
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="flex-1 h-[52px] bg-[#243244] text-[#F8FAFC] border border-white/10 hover:bg-[#2F4158] rounded-[16px] font-bold text-xs transition-all cursor-pointer"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

