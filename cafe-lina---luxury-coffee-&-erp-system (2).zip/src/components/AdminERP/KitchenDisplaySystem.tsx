import React from 'react';
import { Order, OrderStatus } from '../../types';
import { Clock, CheckCircle2, Coffee } from 'lucide-react';

interface KitchenDisplaySystemProps {
  orders: Order[];
  onUpdateStatus: (id: string, status: OrderStatus) => void;
}

export const KitchenDisplaySystem: React.FC<KitchenDisplaySystemProps> = ({
  orders,
  onUpdateStatus,
}) => {
  const kitchenTickets = orders.filter((o) => o.status === 'Pending' || o.status === 'Preparing');

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37]">
            Kitchen Operations
          </span>
          <h1 className="text-2xl font-serif font-bold text-[#EAEAEA] flex items-center gap-2">
            <Coffee size={24} className="text-[#D4AF37]" />
            Kitchen Display System (KDS)
          </h1>
        </div>
        <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold px-4 py-2 rounded-full animate-pulse self-start sm:self-auto">
          ● {kitchenTickets.length} Active Ticket(s) in Queue
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {kitchenTickets.length === 0 ? (
          <div className="col-span-full text-center py-20 bg-[#243244] rounded-[22px] border border-white/10 shadow-[0_12px_30px_rgba(0,0,0,0.35)] text-[#CBD5E1]">
            <CheckCircle2 size={52} className="mx-auto text-[#22C55E] mb-3" />
            <p className="font-bold text-lg text-[#F8FAFC]">Kitchen Queue Clear!</p>
            <p className="text-xs text-[#94A3B8] mt-1">All orders have been freshly prepared and served.</p>
          </div>
        ) : (
          kitchenTickets.map((ord) => (
            <div
              key={ord.id}
              className={`bg-[#243244] rounded-[22px] p-8 border shadow-[0_12px_30px_rgba(0,0,0,0.35)] hover:shadow-[0_16px_40px_rgba(0,0,0,0.5)] hover:-translate-y-1 space-y-6 flex flex-col justify-between transition-all duration-250 ${
                ord.status === 'Pending' ? 'border-[#EF4444] border-2' : 'border-[#F59E0B] border-2'
              }`}
            >
              <div>
                <div className="flex justify-between items-center border-b border-white/10 pb-3 text-xs font-bold">
                  <span className="text-[#D4AF37] font-mono text-base">{ord.id}</span>
                  <span className="flex items-center gap-1.5 text-[#CBD5E1]">
                    <Clock size={14} />
                    {new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="my-3 text-xs font-medium text-[#F8FAFC] space-y-0.5">
                  <p>Customer: <span className="font-bold text-[#F8FAFC]">{ord.customerName}</span></p>
                  <p className="text-[11px] text-[#CBD5E1]">Order Type: {ord.deliveryType}</p>
                </div>

                <div className="bg-[#1E293B] p-4 rounded-[16px] border border-white/10 space-y-2.5 text-xs">
                  {ord.items.map((it, idx) => (
                    <div key={idx} className="flex justify-between font-bold text-[#F8FAFC]">
                      <span>{it.quantity}x {it.menuItem.name}</span>
                      <span className="text-[#D4AF37]">{it.menuItem.category}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Status Action Buttons */}
              <div className="pt-2 border-t border-white/10 flex gap-2">
                {ord.status === 'Pending' && (
                  <button
                    onClick={() => onUpdateStatus(ord.id, 'Preparing')}
                    className="w-full h-[48px] bg-[#F59E0B] hover:bg-[#D97706] text-[#0F172A] rounded-[14px] text-xs font-extrabold transition-all shadow-md cursor-pointer"
                  >
                    Start Preparation ☕
                  </button>
                )}

                {ord.status === 'Preparing' && (
                  <button
                    onClick={() => onUpdateStatus(ord.id, 'Ready')}
                    className="w-full h-[48px] bg-[#22C55E] hover:bg-[#16A34A] text-[#0F172A] rounded-[14px] text-xs font-extrabold flex items-center justify-center gap-2 transition-all shadow-md cursor-pointer"
                  >
                    <CheckCircle2 size={16} /> Mark Ready
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

