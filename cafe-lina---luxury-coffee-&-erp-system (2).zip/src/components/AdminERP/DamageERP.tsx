import React, { useState } from 'react';
import { InventoryItem, MenuItem, DamageVoucher, DamageItem, StoreRecord } from '../../types';
import { ShieldAlert, Plus, Trash2, Eye, Edit, Printer, X, Search, AlertOctagon, Building2 } from 'lucide-react';

interface DamageERPProps {
  inventory: InventoryItem[];
  menuItems: MenuItem[];
  stores?: StoreRecord[];
  damageVouchers: DamageVoucher[];
  onAddDamageVoucher: (voucher: DamageVoucher) => void;
  onUpdateDamageVoucher: (voucher: DamageVoucher) => void;
  onDeleteDamageVoucher: (voucherId: string) => void;
}

export const DamageERP: React.FC<DamageERPProps> = ({
  inventory,
  menuItems,
  stores = [],
  damageVouchers,
  onAddDamageVoucher,
  onUpdateDamageVoucher,
  onDeleteDamageVoucher,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedVoucherForView, setSelectedVoucherForView] = useState<DamageVoucher | null>(null);
  const [editingVoucher, setEditingVoucher] = useState<DamageVoucher | null>(null);

  // Form State for new Multi-Item Damage Voucher
  const [recordedBy, setRecordedBy] = useState('Chef Biruk Tadesse');
  const [storeName, setStoreName] = useState(
    stores.length > 0 ? stores[0].name : 'Bole Main Central Store'
  );
  const [remark, setRemark] = useState('');

  // Selected damage items
  const [stagedItems, setStagedItems] = useState<DamageItem[]>([]);

  // Staging form inputs
  const [itemType, setItemType] = useState<'Ingredient' | 'Finished Product'>('Ingredient');
  const [selectedItemId, setSelectedItemId] = useState<string>('');
  const [damageQty, setDamageQty] = useState<number>(1);
  const [damageReason, setDamageReason] = useState<string>('Exceeded shelf life / Expired');

  const handleStageItem = () => {
    if (!selectedItemId || damageQty <= 0) return;

    if (itemType === 'Ingredient') {
      const inv = inventory.find((i) => i.id === selectedItemId);
      if (!inv) return;

      const newItem: DamageItem = {
        itemType: 'Ingredient',
        itemId: inv.id,
        name: inv.name,
        image: inv.image,
        qty: damageQty,
        unit: inv.unit,
        costPerUnit: inv.costPerUnit,
        totalCost: damageQty * inv.costPerUnit,
        reason: damageReason,
      };

      setStagedItems((prev) => [...prev, newItem]);
    } else {
      const item = menuItems.find((m) => m.id === selectedItemId);
      if (!item) return;

      const newItem: DamageItem = {
        itemType: 'Finished Product',
        itemId: item.id,
        name: item.name,
        image: item.image,
        qty: damageQty,
        unit: 'portions',
        costPerUnit: item.price * 0.4, // estimated cost price
        totalCost: damageQty * item.price * 0.4,
        reason: damageReason,
      };

      setStagedItems((prev) => [...prev, newItem]);
    }

    // Reset staging input
    setSelectedItemId('');
    setDamageQty(1);
  };

  const handleRemoveStagedItem = (index: number) => {
    setStagedItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleSubmitVoucher = (e: React.FormEvent) => {
    e.preventDefault();
    if (stagedItems.length === 0) return;

    const totalLoss = stagedItems.reduce((sum, item) => sum + item.totalCost, 0);

    const newVoucher: DamageVoucher = {
      voucherId: `DMG-2026-${Math.floor(100 + Math.random() * 900)}`,
      date: new Date().toISOString().split('T')[0],
      createdTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      recordedBy,
      storeName,
      items: stagedItems,
      totalLossAmount: totalLoss,
      remark,
    };

    onAddDamageVoucher(newVoucher);
    setIsModalOpen(false);
    setStagedItems([]);
    setRemark('');
  };

  const totalDamageValueAllTime = damageVouchers.reduce((sum, v) => sum + v.totalLossAmount, 0);

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-red-400 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/30">
            Spoilage & Loss Registry
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <ShieldAlert className="text-red-400" size={28} />
            Raw Material & Product Damage Registry (Damage Voucher)
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Register single or batch damages for ingredients and finished menu products with auto cost deduction.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#243244] p-3 px-5 rounded-2xl border border-white/10 shadow-md">
            <span className="text-[10px] text-[#94A3B8] uppercase block font-bold">Total Damage Loss Value</span>
            <span className="text-xl font-extrabold text-red-400">
              {totalDamageValueAllTime.toLocaleString()} ETB
            </span>
          </div>

          <button
            onClick={() => setIsModalOpen(true)}
            className="px-5 py-3.5 bg-red-500 hover:bg-red-600 text-white rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg min-h-[44px]"
          >
            <Plus size={18} />
            <span>Register Batch Damage</span>
          </button>
        </div>
      </div>

      {/* Damage Vouchers Log Table */}
      <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-4 shadow-xl">
        <h2 className="text-lg font-serif font-bold text-[#F8FAFC]">Damage Vouchers & Receipts Log</h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-[#CBD5E1]">
            <thead className="bg-[#1E293B] text-[#94A3B8] uppercase text-[10px] font-extrabold tracking-wider border-b border-white/10">
              <tr>
                <th className="py-3.5 px-4">Voucher ID</th>
                <th className="py-3.5 px-4">Recorded By</th>
                <th className="py-3.5 px-4">Store Location</th>
                <th className="py-3.5 px-4">Damaged Items</th>
                <th className="py-3.5 px-4 font-right">Total Loss (ETB)</th>
                <th className="py-3.5 px-4">Date & Time</th>
                <th className="py-3.5 px-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {damageVouchers.length === 0 ? (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-[#94A3B8]">
                    No damage vouchers recorded yet.
                  </td>
                </tr>
              ) : (
                damageVouchers.map((v) => (
                  <tr key={v.voucherId} className="hover:bg-[#1E293B]/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-red-400">{v.voucherId}</td>
                    <td className="py-3.5 px-4 font-bold text-[#F8FAFC]">{v.recordedBy}</td>
                    <td className="py-3.5 px-4">{v.storeName}</td>
                    <td className="py-3.5 px-4 font-bold text-[#D4AF37]">{v.items.length} Items</td>
                    <td className="py-3.5 px-4 font-extrabold text-red-400">{v.totalLossAmount.toLocaleString()} ETB</td>
                    <td className="py-3.5 px-4">
                      <span>{v.date}</span> <span className="text-[10px] text-[#94A3B8]">{v.createdTime}</span>
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => setSelectedVoucherForView(v)}
                          className="p-2 bg-[#1E293B] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] rounded-lg transition-all"
                          title="View Receipt"
                        >
                          <Eye size={15} />
                        </button>
                        <button
                          onClick={() => setEditingVoucher(v)}
                          className="p-2 bg-[#1E293B] text-[#3B82F6] hover:bg-[#3B82F6] hover:text-white rounded-lg transition-all"
                          title="Edit Voucher"
                        >
                          <Edit size={15} />
                        </button>
                        <button
                          onClick={() => onDeleteDamageVoucher(v.voucherId)}
                          className="p-2 bg-[#1E293B] text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-all"
                          title="Delete Voucher"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL 1: Create Batch Damage Voucher */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={handleSubmitVoucher}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-2xl w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg text-red-400 flex items-center gap-2">
                <AlertOctagon size={20} /> Register Batch Damage Voucher
              </h3>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Recorded By *</label>
                <input
                  type="text"
                  required
                  value={recordedBy}
                  onChange={(e) => setRecordedBy(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1 flex items-center gap-1">
                  <Building2 size={13} className="text-[#D4AF37]" />
                  Damaged Store Location (Damage Yehonebet Store) *
                </label>
                <select
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full h-10 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37] font-medium cursor-pointer"
                >
                  {stores.length > 0 ? (
                    stores.map((s) => (
                      <option key={s.id} value={s.name} className="bg-[#1E293B] text-[#F8FAFC]">
                        {s.name} ({s.location})
                      </option>
                    ))
                  ) : (
                    <>
                      <option value="Bole Main Central Store" className="bg-[#1E293B]">Bole Main Central Store</option>
                      <option value="Kazanchis Branch Store" className="bg-[#1E293B]">Kazanchis Branch Store</option>
                      <option value="Kitchen & Bakery Sub-Store" className="bg-[#1E293B]">Kitchen & Bakery Sub-Store</option>
                    </>
                  )}
                </select>
              </div>
            </div>

            {/* Stage Items to Damage */}
            <div className="p-4 bg-[#243244] rounded-2xl border border-white/10 space-y-3">
              <span className="text-xs font-extrabold text-[#D4AF37] uppercase block">
                Add Items to Damage List (Multi-Item Selection)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div>
                  <label className="block text-[10px] text-[#94A3B8] font-bold mb-1">Item Category</label>
                  <select
                    value={itemType}
                    onChange={(e) => {
                      setItemType(e.target.value as any);
                      setSelectedItemId('');
                    }}
                    className="w-full h-9 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg px-2 text-xs focus:outline-none"
                  >
                    <option value="Ingredient">Raw Ingredient (Gbat)</option>
                    <option value="Finished Product">Finished Menu Product</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-[#94A3B8] font-bold mb-1">Select Item</label>
                  <select
                    value={selectedItemId}
                    onChange={(e) => setSelectedItemId(e.target.value)}
                    className="w-full h-9 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg px-2 text-xs focus:outline-none"
                  >
                    <option value="">-- Choose Item --</option>
                    {itemType === 'Ingredient'
                      ? inventory.map((i) => (
                          <option key={i.id} value={i.id}>
                            {i.name} ({i.stockQty} {i.unit})
                          </option>
                        ))
                      : menuItems.map((m) => (
                          <option key={m.id} value={m.id}>
                            {m.name} ({m.price} ETB)
                          </option>
                        ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-[#94A3B8] font-bold mb-1">Damage Quantity</label>
                  <input
                    type="number"
                    min={1}
                    value={damageQty}
                    onChange={(e) => setDamageQty(Number(e.target.value))}
                    className="w-full h-9 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg px-2 text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] text-[#94A3B8] font-bold mb-1">Reason for Damage</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={damageReason}
                    onChange={(e) => setDamageReason(e.target.value)}
                    placeholder="e.g. Expired shelf-life / Accidental spill / Preparation flaw"
                    className="flex-1 h-9 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-lg px-3 text-xs focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={handleStageItem}
                    disabled={!selectedItemId}
                    className="px-4 h-9 bg-red-500 hover:bg-red-600 disabled:opacity-40 text-white rounded-lg text-xs font-bold transition-all"
                  >
                    + Add Item
                  </button>
                </div>
              </div>
            </div>

            {/* Staged Items List */}
            <div className="space-y-2">
              <label className="block text-xs font-bold text-[#CBD5E1]">
                Staged Damaged Items ({stagedItems.length})
              </label>

              <div className="max-h-36 overflow-y-auto space-y-1.5 border border-white/10 rounded-xl p-2 bg-[#243244]">
                {stagedItems.length === 0 ? (
                  <p className="text-center text-xs text-[#94A3B8] py-4">No items added to damage batch yet.</p>
                ) : (
                  stagedItems.map((stg, idx) => (
                    <div
                      key={idx}
                      className="p-2 bg-[#1E293B] rounded-lg flex items-center justify-between gap-3 text-xs border border-white/5"
                    >
                      <div className="flex items-center gap-2">
                        <img src={stg.image} alt={stg.name} className="w-8 h-8 rounded object-cover" />
                        <div>
                          <span className="font-bold text-[#F8FAFC] block">{stg.name}</span>
                          <span className="text-[10px] text-[#94A3B8]">
                            Reason: {stg.reason} ({stg.itemType})
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="font-bold text-red-400">
                          {stg.qty} {stg.unit} ({stg.totalCost.toLocaleString()} ETB)
                        </span>
                        <button
                          type="button"
                          onClick={() => handleRemoveStagedItem(idx)}
                          className="p-1 text-gray-400 hover:text-red-400"
                        >
                          <X size={14} />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={stagedItems.length === 0}
                className="flex-1 h-11 bg-red-500 hover:bg-red-600 disabled:opacity-40 text-white rounded-xl text-xs font-extrabold shadow-md"
              >
                Save & Issue Damage Voucher
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: View Damage Voucher Ticket */}
      {selectedVoucherForView && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-lg text-red-400">Damage Voucher Receipt</h3>
                <p className="text-xs text-[#94A3B8]">ID: {selectedVoucherForView.voucherId}</p>
              </div>
              <button onClick={() => setSelectedVoucherForView(null)} className="p-1 text-gray-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-1.5 text-xs text-[#CBD5E1]">
              <p>Recorded By: <strong className="text-[#F8FAFC]">{selectedVoucherForView.recordedBy}</strong></p>
              <p>Store Branch: <strong className="text-[#F8FAFC]">{selectedVoucherForView.storeName}</strong></p>
              <p>Date & Time: {selectedVoucherForView.date} {selectedVoucherForView.createdTime}</p>
            </div>

            <div className="border-t border-b border-white/10 py-3 space-y-2">
              <h4 className="text-xs font-extrabold text-red-400 uppercase">Damaged Items Breakdown</h4>
              {selectedVoucherForView.items.map((it, idx) => (
                <div key={idx} className="flex justify-between items-center p-2 bg-[#243244] rounded-lg text-xs">
                  <div className="flex items-center gap-2">
                    <img src={it.image} alt={it.name} className="w-8 h-8 rounded object-cover" />
                    <div>
                      <span className="font-bold text-[#F8FAFC] block">{it.name}</span>
                      <span className="text-[10px] text-[#94A3B8]">{it.reason}</span>
                    </div>
                  </div>
                  <span className="font-extrabold text-red-400">
                    {it.qty} {it.unit} @ {it.totalCost} ETB
                  </span>
                </div>
              ))}
            </div>

            <div className="flex justify-between text-base font-bold text-[#F8FAFC]">
              <span>TOTAL LOSS AMOUNT:</span>
              <span className="text-red-400">{selectedVoucherForView.totalLossAmount.toLocaleString()} ETB</span>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-[#D4AF37] text-[#0F172A] rounded-xl text-xs font-bold flex items-center justify-center gap-1"
              >
                <Printer size={15} /> Print Receipt
              </button>
              <button
                onClick={() => setSelectedVoucherForView(null)}
                className="flex-1 py-2.5 bg-[#243244] hover:bg-[#2F4158] text-[#F8FAFC] rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Edit Damage Voucher */}
      {editingVoucher && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onUpdateDamageVoucher(editingVoucher);
              setEditingVoucher(null);
            }}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg text-red-400">
                Edit Damage Voucher {editingVoucher.voucherId}
              </h3>
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Recorded By</label>
              <input
                type="text"
                value={editingVoucher.recordedBy}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, recordedBy: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Store Location (Damage Yehonebet Store)</label>
              <select
                value={editingVoucher.storeName}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, storeName: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37] font-medium cursor-pointer"
              >
                {stores.length > 0 ? (
                  stores.map((s) => (
                    <option key={s.id} value={s.name} className="bg-[#1E293B] text-[#F8FAFC]">
                      {s.name} ({s.location})
                    </option>
                  ))
                ) : (
                  <>
                    <option value="Bole Main Central Store" className="bg-[#1E293B]">Bole Main Central Store</option>
                    <option value="Kazanchis Branch Store" className="bg-[#1E293B]">Kazanchis Branch Store</option>
                    <option value="Kitchen & Bakery Sub-Store" className="bg-[#1E293B]">Kitchen & Bakery Sub-Store</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Remark</label>
              <input
                type="text"
                value={editingVoucher.remark || ''}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, remark: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 h-11 bg-red-500 hover:bg-red-600 text-white rounded-xl text-xs font-extrabold"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
