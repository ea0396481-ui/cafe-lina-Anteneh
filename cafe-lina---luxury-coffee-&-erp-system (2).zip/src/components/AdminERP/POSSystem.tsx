import React, { useState } from 'react';
import { MenuItem, InventoryItem, POSReceiptVoucher, Order, OrderItem } from '../../types';
import {
  Search,
  Barcode,
  Printer,
  CheckCircle2,
  ShoppingBag,
  X,
  AlertTriangle,
  RefreshCw,
  Upload,
  Receipt,
  Eye,
  Trash2,
  Edit,
  CreditCard,
  Building2,
  Phone,
  FileText,
  DollarSign,
  Plus,
} from 'lucide-react';

interface POSSystemProps {
  menuItems: MenuItem[];
  inventory: InventoryItem[];
  posReceipts: POSReceiptVoucher[];
  onCompletePOSOrder: (order: Order) => void;
  onSavePOSReceipt: (receipt: POSReceiptVoucher) => void;
  onUpdatePOSReceipt: (receipt: POSReceiptVoucher) => void;
  onDeletePOSReceipt: (voucherId: string) => void;
}

export const POSSystem: React.FC<POSSystemProps> = ({
  menuItems,
  inventory,
  posReceipts,
  onCompletePOSOrder,
  onSavePOSReceipt,
  onUpdatePOSReceipt,
  onDeletePOSReceipt,
}) => {
  const [cart, setCart] = useState<{ item: MenuItem; qty: number; substitutedIngredient?: string }[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState('');
  const [barcodeInput, setBarcodeInput] = useState('');
  const [activeTab, setActiveTab] = useState<'terminal' | 'vouchers'>('terminal');

  // Payment State
  const [paymentType, setPaymentType] = useState<'Cash' | 'Card' | 'Bank Transfer' | 'Telebirr'>('Cash');
  const [accountOrPhone, setAccountOrPhone] = useState('100039201923 (CBE / Telebirr)');
  const [amountPaid, setAmountPaid] = useState<number>(0);
  const [slipPhoto, setSlipPhoto] = useState<string>('');

  // Missing Ingredient Modal State
  const [missingIngModalItem, setMissingIngModalItem] = useState<{
    item: MenuItem;
    missingName: string;
    requiredQty: number;
    availableQty: number;
    unit: string;
  } | null>(null);
  const [selectedSubstituteId, setSelectedSubstituteId] = useState<string>('');

  // Receipt Modal State
  const [receiptModal, setReceiptModal] = useState<POSReceiptVoucher | null>(null);
  const [selectedVoucherForView, setSelectedVoucherForView] = useState<POSReceiptVoucher | null>(null);
  const [editingVoucher, setEditingVoucher] = useState<POSReceiptVoucher | null>(null);

  const [mobileCartOpen, setMobileCartOpen] = useState(false);

  const categories = ['All', 'Coffee', 'Espresso', 'Latte', 'Cappuccino', 'Bakery', 'Breakfast', 'Fresh Juice'];

  const filtered = menuItems.filter((i) => {
    const matchCat = selectedCategory === 'All' || i.category === selectedCategory;
    const matchSearch =
      i.name.toLowerCase().includes(search.toLowerCase()) ||
      (i.barcode && i.barcode.toLowerCase().includes(barcodeInput.toLowerCase()));
    return matchCat && matchSearch;
  });

  // Check Main Ingredient Availability (Wana Gbat Check)
  const addToCartWithCheck = (item: MenuItem) => {
    // Determine main ingredient name based on item
    const mainIngredientName = item.ingredients && item.ingredients.length > 0 ? item.ingredients[0] : 'Coffee Beans';

    // Find in inventory
    const matchedInv = inventory.find(
      (inv) =>
        inv.name.toLowerCase().includes(mainIngredientName.toLowerCase()) ||
        mainIngredientName.toLowerCase().includes(inv.name.toLowerCase()) ||
        inv.category.toLowerCase().includes('coffee')
    );

    const requiredQtyPerUnit = 0.15; // e.g. 150g or 0.15L per serving
    const currentCartQty = cart.filter((c) => c.item.id === item.id).reduce((s, c) => s + c.qty, 0);
    const totalRequired = (currentCartQty + 1) * requiredQtyPerUnit;

    const stockAvailable = matchedInv ? matchedInv.stockQty : 0;

    if (stockAvailable < totalRequired) {
      // Main ingredient is missing / insufficient -> trigger modal!
      setMissingIngModalItem({
        item,
        missingName: matchedInv ? matchedInv.name : mainIngredientName,
        requiredQty: totalRequired,
        availableQty: stockAvailable,
        unit: matchedInv ? matchedInv.unit : 'kg/L',
      });
      // default substitute
      const possibleSub = inventory.find((inv) => inv.id !== matchedInv?.id && inv.stockQty > 0);
      setSelectedSubstituteId(possibleSub ? possibleSub.id : '');
      return;
    }

    // Fully available -> Add directly
    pushToCart(item);
  };

  const pushToCart = (item: MenuItem, substitutedIngredientName?: string) => {
    setCart((prev) => {
      const existing = prev.find((c) => c.item.id === item.id);
      if (existing) {
        return prev.map((c) =>
          c.item.id === item.id ? { ...c, qty: c.qty + 1, substitutedIngredient: substitutedIngredientName } : c
        );
      }
      return [...prev, { item, qty: 1, substitutedIngredient: substitutedIngredientName }];
    });
  };

  // Handle Substitute Ingredient Selection
  const handleConfirmSubstitute = () => {
    if (!missingIngModalItem) return;
    const subInv = inventory.find((i) => i.id === selectedSubstituteId);
    const subName = subInv ? `${subInv.name} (${subInv.stockQty} ${subInv.unit} avail)` : 'Alternative Stock';

    pushToCart(missingIngModalItem.item, subName);
    setMissingIngModalItem(null);
  };

  // Handle Force Sell with Current Available Stock
  const handleForceSellCurrentStock = () => {
    if (!missingIngModalItem) return;
    pushToCart(missingIngModalItem.item, 'Sold using current partial stock');
    setMissingIngModalItem(null);
  };

  const updateQty = (id: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) => (c.item.id === id ? { ...c, qty: c.qty + delta } : c))
        .filter((c) => c.qty > 0)
    );
  };

  const subtotal = cart.reduce((sum, c) => sum + c.item.price * c.qty, 0);
  const tax = Math.round(subtotal * 0.05);
  const grandTotal = subtotal + tax;
  const totalItemCount = cart.reduce((sum, c) => sum + c.qty, 0);

  // File Upload Handler for Payment Slip
  const handleSlipFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSlipPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCheckoutPOS = () => {
    if (cart.length === 0) return;

    const orderId = `POS-${Math.floor(1000 + Math.random() * 9000)}`;
    const voucherId = `POS-REC-${Math.floor(10000 + Math.random() * 90000)}`;

    const newOrd: Order = {
      id: orderId,
      customerName: 'Counter Guest',
      customerEmail: 'pos@cafelina.com',
      customerPhone: accountOrPhone || '+251 900 000 000',
      deliveryType: 'Pickup',
      items: cart.map((c) => ({ menuItem: c.item, quantity: c.qty })),
      subtotal,
      discount: 0,
      tax,
      deliveryFee: 0,
      total: grandTotal,
      currency: 'ETB',
      paymentMethod: paymentType === 'Card' ? 'Stripe' : paymentType === 'Cash' ? 'Cash' : 'Bank Transfer',
      paymentStatus: 'Paid',
      status: 'Ready',
      createdAt: new Date().toISOString(),
    };

    const hasSubstitutions = cart.some((c) => c.substitutedIngredient);
    const posVoucher: POSReceiptVoucher = {
      voucherId,
      orderId,
      date: new Date().toISOString().split('T')[0],
      cashierName: 'Abebe Cashier',
      customerName: 'Counter Guest',
      items: cart.map((c) => ({ menuItem: c.item, quantity: c.qty })),
      subtotal,
      tax,
      grandTotal,
      paymentMethod: paymentType,
      accountNumberOrPhone: paymentType !== 'Cash' ? accountOrPhone : undefined,
      amountReceived: amountPaid > 0 ? amountPaid : grandTotal,
      slipPhotoUrl: slipPhoto || undefined,
      mainIngredientStatus: hasSubstitutions ? 'Substituted' : 'Fully Available',
      substitutionNotes: cart
        .filter((c) => c.substitutedIngredient)
        .map((c) => `${c.item.name}: ${c.substitutedIngredient}`)
        .join(' | '),
      createdTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    onCompletePOSOrder(newOrd);
    onSavePOSReceipt(posVoucher);
    setReceiptModal(posVoucher);

    // Reset Cart & Payment Form
    setCart([]);
    setSlipPhoto('');
    setAmountPaid(0);
    setMobileCartOpen(false);
  };

  const CartContent = () => (
    <div className="flex flex-col justify-between h-full space-y-4">
      <div>
        <div className="border-b border-white/10 pb-3 flex justify-between items-center">
          <div>
            <h2 className="font-serif font-bold text-lg sm:text-xl text-[#F8FAFC] flex items-center gap-2">
              <ShoppingBag size={20} className="text-[#D4AF37]" />
              Current Bill Ticket
            </h2>
            <p className="text-xs text-[#CBD5E1] mt-0.5">Order items & ingredient verification</p>
          </div>
          <button
            onClick={() => setMobileCartOpen(false)}
            className="lg:hidden p-2 text-[#CBD5E1] hover:text-white rounded-xl bg-[#1E293B]"
          >
            <X size={20} />
          </button>
        </div>

        <div className="overflow-y-auto max-h-[35vh] sm:max-h-[40vh] my-4 space-y-3 pr-1">
          {cart.length === 0 ? (
            <div className="text-center text-xs text-[#94A3B8] py-10 space-y-2">
              <p className="font-semibold text-[#CBD5E1]">Ticket is empty</p>
              <p>Select products from the left menu to add to order</p>
            </div>
          ) : (
            cart.map((c) => (
              <div
                key={c.item.id}
                className="bg-[#1E293B] p-3.5 rounded-[16px] border border-white/10 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <div className="flex-1 min-w-0 pr-2">
                    <span className="font-bold text-[#F8FAFC] block truncate">{c.item.name}</span>
                    <span className="text-[#94A3B8]">
                      {c.item.price} ETB x {c.qty}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => updateQty(c.item.id, -1)}
                      className="w-7 h-7 bg-[#2F4158] text-[#F8FAFC] rounded-lg font-bold hover:bg-[#3B82F6] flex items-center justify-center text-sm"
                    >
                      -
                    </button>
                    <span className="font-bold text-sm text-[#F8FAFC] min-w-[18px] text-center">
                      {c.qty}
                    </span>
                    <button
                      onClick={() => updateQty(c.item.id, 1)}
                      className="w-7 h-7 bg-[#D4AF37] text-[#0F172A] rounded-lg font-bold hover:bg-[#F6C453] flex items-center justify-center text-sm"
                    >
                      +
                    </button>
                  </div>
                </div>

                {c.substitutedIngredient && (
                  <div className="text-[10px] bg-[#D4AF37]/10 text-[#D4AF37] p-1.5 rounded-lg border border-[#D4AF37]/20 flex items-center gap-1">
                    <RefreshCw size={12} className="shrink-0" />
                    <span className="truncate">Ingredient: {c.substitutedIngredient}</span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>

      {/* Bill Calculations & Payment Options */}
      <div className="space-y-4 border-t border-white/10 pt-3">
        <div className="space-y-1.5 text-xs text-[#CBD5E1]">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>{subtotal} ETB</span>
          </div>
          <div className="flex justify-between">
            <span>VAT (5%)</span>
            <span>{tax} ETB</span>
          </div>
          <div className="flex justify-between font-extrabold text-base text-[#F8FAFC] pt-2 border-t border-white/10">
            <span>Total Payable</span>
            <span className="text-[#D4AF37]">{grandTotal} ETB</span>
          </div>
        </div>

        {/* Payment Selector */}
        <div className="space-y-2">
          <label className="block text-[11px] font-bold text-[#CBD5E1] uppercase">Payment Method (Kfyat)</label>
          <div className="grid grid-cols-4 gap-1.5 text-[11px] font-bold">
            {(['Cash', 'Card', 'Bank Transfer', 'Telebirr'] as const).map((pt) => (
              <button
                key={pt}
                onClick={() => setPaymentType(pt)}
                className={`py-2 px-1 rounded-xl border text-center transition-all ${
                  paymentType === pt
                    ? 'bg-[#D4AF37] text-[#0F172A] border-[#D4AF37] font-extrabold'
                    : 'bg-[#1E293B] text-[#CBD5E1] border-white/10 hover:bg-[#2F4158]'
                }`}
              >
                {pt}
              </button>
            ))}
          </div>
        </div>

        {/* Bank Transfer / Telebirr Details & Slip Upload */}
        {(paymentType === 'Bank Transfer' || paymentType === 'Telebirr') && (
          <div className="p-3 bg-[#1E293B] rounded-2xl border border-white/10 space-y-2.5 text-xs animate-fadeIn">
            <div>
              <label className="block text-[10px] font-bold text-[#94A3B8] mb-1">
                Account No. / Telebirr Phone Number
              </label>
              <input
                type="text"
                value={accountOrPhone}
                onChange={(e) => setAccountOrPhone(e.target.value)}
                placeholder="e.g. 100028312093 (CBE) or +251 911 000 111"
                className="w-full h-9 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-2.5 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-[#94A3B8] mb-1">
                  Amount Received (ETB)
                </label>
                <input
                  type="number"
                  value={amountPaid || grandTotal}
                  onChange={(e) => setAmountPaid(Number(e.target.value))}
                  className="w-full h-9 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-2.5 text-xs font-bold text-[#D4AF37] focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-[#94A3B8] mb-1">Upload Slip Photo</label>
                <label className="flex items-center justify-center gap-1 h-9 bg-[#243244] hover:bg-[#2F4158] text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl cursor-pointer font-bold text-[11px]">
                  <Upload size={14} />
                  <span>{slipPhoto ? 'Change' : 'Upload Slip'}</span>
                  <input type="file" accept="image/*" onChange={handleSlipFileUpload} className="hidden" />
                </label>
              </div>
            </div>

            {slipPhoto && (
              <div className="flex items-center gap-2 pt-1">
                <img src={slipPhoto} alt="Slip Preview" className="w-10 h-10 object-cover rounded-lg border border-white/10" />
                <span className="text-[10px] text-[#22C55E] font-bold">Slip image attached! (Saved to voucher)</span>
              </div>
            )}
          </div>
        )}

        <button
          onClick={handleCheckoutPOS}
          disabled={cart.length === 0}
          className="w-full h-[50px] bg-[#D4AF37] hover:bg-[#F6C453] disabled:opacity-40 text-[#0F172A] font-extrabold text-xs uppercase tracking-wider rounded-[16px] shadow-lg flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <CheckCircle2 size={18} />
          <span>Complete Sale & Issue Voucher</span>
        </button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6 font-sans pb-24 lg:pb-12">
      {/* Top Header & View Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Smart Counter Operations
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <ShoppingBag className="text-[#D4AF37]" size={28} />
            POS Terminal & Ingredient Checker
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Validates main ingredient (Wana Gbat) availability automatically before issuing sales tickets.
          </p>
        </div>

        {/* Tab Switcher: POS Terminal vs Vouchers Registry */}
        <div className="flex bg-[#1E293B] p-1.5 rounded-2xl border border-white/10">
          <button
            onClick={() => setActiveTab('terminal')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all ${
              activeTab === 'terminal'
                ? 'bg-[#D4AF37] text-[#0F172A] shadow-md'
                : 'text-[#CBD5E1] hover:text-white'
            }`}
          >
            <ShoppingBag size={16} />
            <span>POS Register</span>
          </button>

          <button
            onClick={() => setActiveTab('vouchers')}
            className={`px-4 py-2.5 rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all ${
              activeTab === 'vouchers'
                ? 'bg-[#D4AF37] text-[#0F172A] shadow-md'
                : 'text-[#CBD5E1] hover:text-white'
            }`}
          >
            <Receipt size={16} />
            <span>POS Vouchers ({posReceipts.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'terminal' ? (
        <div className="space-y-6 lg:space-y-0 lg:grid lg:grid-cols-3 lg:gap-8">
          {/* Left Menu Grid */}
          <div className="lg:col-span-2 space-y-5">
            {/* Search & Barcode Scan Inputs */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div className="relative">
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search product title..."
                  className="w-full h-[48px] bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-[16px] pl-11 pr-4 text-xs font-medium focus:outline-none focus:border-[#D4AF37]"
                />
                <Search size={18} className="absolute left-3.5 top-3.5 text-[#94A3B8]" />
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  placeholder="Scan Barcode (e.g. CL-CAP-01)"
                  className="w-full h-[48px] bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-[16px] pl-11 pr-4 text-xs font-mono focus:outline-none focus:border-[#D4AF37]"
                />
                <Barcode size={18} className="absolute left-3.5 top-3.5 text-[#94A3B8]" />
              </div>
            </div>

            {/* Category Pills */}
            <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-[14px] text-xs font-bold whitespace-nowrap transition-all ${
                    selectedCategory === cat
                      ? 'bg-[#D4AF37] text-[#0F172A] shadow-md scale-105'
                      : 'bg-[#1E293B] text-[#CBD5E1] border border-white/10 hover:bg-[#2F4158]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Products Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {filtered.map((item) => (
                <button
                  key={item.id}
                  onClick={() => addToCartWithCheck(item)}
                  className="bg-[#243244] p-3.5 rounded-[22px] border border-white/10 hover:border-[#D4AF37] text-left transition-all shadow-md hover:-translate-y-1 flex flex-col justify-between group active:scale-95"
                >
                  <div>
                    <div className="overflow-hidden rounded-[16px] mb-2.5">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-28 sm:h-32 object-cover rounded-[16px] group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <h4 className="font-bold text-xs sm:text-sm text-[#F8FAFC] line-clamp-1">{item.name}</h4>
                    <span className="text-[10px] text-[#94A3B8] font-mono block mt-0.5">
                      Main: {item.ingredients && item.ingredients[0] ? item.ingredients[0] : 'Coffee Beans'}
                    </span>
                  </div>

                  <div className="mt-2.5 flex items-center justify-between border-t border-white/10 pt-2">
                    <span className="font-extrabold text-xs sm:text-sm text-[#D4AF37]">{item.price} ETB</span>
                    <span className="text-[10px] bg-[#1E293B] text-[#F8FAFC] px-2.5 py-1 rounded-[10px] font-bold border border-white/10 group-hover:bg-[#D4AF37] group-hover:text-[#0F172A] transition-all">
                      + Select
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Desktop Right Cart */}
          <div className="hidden lg:flex bg-[#243244] p-6 rounded-[22px] border border-white/10 shadow-xl flex-col justify-between h-[82vh]">
            <CartContent />
          </div>
        </div>
      ) : (
        /* VOUCHERS REGISTRY TAB (View, Edit, Delete POS Receipt Vouchers) */
        <div className="bg-[#243244] p-6 rounded-[24px] border border-white/10 space-y-6 shadow-xl animate-fadeIn">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4 border-b border-white/10 pb-4">
            <div>
              <h2 className="text-xl font-serif font-bold text-[#F8FAFC]">POS Sales Receipt Vouchers Registry</h2>
              <p className="text-xs text-[#94A3B8]">
                Complete audit history of counter orders, payment slip photos, and ingredient substitution logs.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-[#CBD5E1]">
              <thead className="bg-[#1E293B] text-[#94A3B8] uppercase text-[10px] font-extrabold tracking-wider border-b border-white/10">
                <tr>
                  <th className="py-3.5 px-4">Voucher ID</th>
                  <th className="py-3.5 px-4">Date & Time</th>
                  <th className="py-3.5 px-4">Items Summary</th>
                  <th className="py-3.5 px-4">Payment Method</th>
                  <th className="py-3.5 px-4">Total Amount</th>
                  <th className="py-3.5 px-4">Main Ingredient Status</th>
                  <th className="py-3.5 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-medium">
                {posReceipts.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-[#94A3B8]">
                      No POS receipt vouchers registered yet.
                    </td>
                  </tr>
                ) : (
                  posReceipts.map((v) => (
                    <tr key={v.voucherId} className="hover:bg-[#1E293B]/50 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-[#D4AF37]">{v.voucherId}</td>
                      <td className="py-3.5 px-4">
                        <span className="block font-bold text-[#F8FAFC]">{v.date}</span>
                        <span className="text-[10px] text-[#94A3B8]">{v.createdTime}</span>
                      </td>
                      <td className="py-3.5 px-4 max-w-xs truncate">
                        {v.items.map((i) => `${i.quantity}x ${i.menuItem.name}`).join(', ')}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="bg-[#1E293B] px-2.5 py-1 rounded-full border border-white/10 font-bold text-[#F8FAFC]">
                          {v.paymentMethod}
                        </span>
                        {v.accountNumberOrPhone && (
                          <span className="block text-[10px] text-[#D4AF37] font-mono mt-0.5">
                            {v.accountNumberOrPhone}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-extrabold text-[#22C55E] text-sm">
                        {v.grandTotal} ETB
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                            v.mainIngredientStatus === 'Fully Available'
                              ? 'bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30'
                              : 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30'
                          }`}
                        >
                          {v.mainIngredientStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => setSelectedVoucherForView(v)}
                            className="p-2 bg-[#1E293B] text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0F172A] rounded-lg transition-all"
                            title="View Voucher"
                          >
                            <Eye size={15} />
                          </button>
                          <button
                            onClick={() => setEditingVoucher(v)}
                            className="p-2 bg-[#1E293B] text-[#3B82F6] hover:bg-[#3B82F6] hover:text-white rounded-lg transition-all"
                            title="Edit Voucher"
                          >
                            <Edit size={15} />
                          </button>
                          <button
                            onClick={() => onDeletePOSReceipt(v.voucherId)}
                            className="p-2 bg-[#1E293B] text-red-400 hover:bg-red-500 hover:text-white rounded-lg transition-all"
                            title="Delete Voucher"
                          >
                            <Trash2 size={15} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Mobile & Tablet Floating Cart Action Bar */}
      {activeTab === 'terminal' && (
        <div className="lg:hidden fixed bottom-4 left-4 right-4 z-40">
          <button
            onClick={() => setMobileCartOpen(true)}
            className="w-full h-[56px] bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] font-extrabold rounded-[20px] shadow-[0_10px_25px_rgba(212,175,55,0.4)] flex items-center justify-between px-5 transition-all active:scale-98 cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#0F172A] text-[#D4AF37] flex items-center justify-center font-black text-xs">
                {totalItemCount}
              </div>
              <span className="text-xs uppercase tracking-wider font-extrabold">
                {cart.length > 0 ? 'Current Bill Ticket' : 'Open Bill Ticket'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-sm">{grandTotal} ETB</span>
              <ShoppingBag size={18} />
            </div>
          </button>
        </div>
      )}

      {/* Mobile & Tablet Cart Bottom Sheet / Drawer Modal */}
      {mobileCartOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="bg-[#243244] w-full max-w-lg rounded-t-[28px] sm:rounded-[28px] border border-white/10 p-6 shadow-2xl max-h-[92vh] overflow-y-auto space-y-4 text-[#F8FAFC]">
            <CartContent />
          </div>
        </div>
      )}

      {/* MODAL 1: Missing Main Ingredient (Wana Gbat) Verification Modal */}
      {missingIngModalItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-red-500/30 rounded-[24px] max-w-lg w-full p-6 space-y-5 shadow-2xl text-[#F8FAFC]">
            <div className="flex justify-between items-start border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5 text-red-400 font-serif font-bold text-lg">
                <AlertTriangle size={24} className="shrink-0 animate-bounce" />
                <h3>Main Ingredient Missing / Insufficient (Wana Gbat Yaltemula)</h3>
              </div>
              <button
                onClick={() => setMissingIngModalItem(null)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className="p-4 bg-[#243244] rounded-2xl border border-white/10 space-y-2 text-xs">
              <p className="font-bold text-sm text-[#F8FAFC]">Product Selected: {missingIngModalItem.item.name}</p>
              <div className="grid grid-cols-2 gap-2 text-[#CBD5E1]">
                <div>
                  <span className="text-[#94A3B8] block text-[10px] uppercase font-bold">Main Ingredient</span>
                  <span className="font-extrabold text-red-400">{missingIngModalItem.missingName}</span>
                </div>
                <div>
                  <span className="text-[#94A3B8] block text-[10px] uppercase font-bold">Stock Status</span>
                  <span className="font-bold text-yellow-400">
                    Required: {missingIngModalItem.requiredQty} | Avail: {missingIngModalItem.availableQty}{' '}
                    {missingIngModalItem.unit}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-xs font-bold uppercase text-[#D4AF37]">Select Solution Option:</h4>

              {/* Option A: Substitute Ingredient */}
              <div className="p-3.5 bg-[#243244] rounded-xl border border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#F8FAFC] block">Option 1: Substitute with Available Ingredient</span>
                <select
                  value={selectedSubstituteId}
                  onChange={(e) => setSelectedSubstituteId(e.target.value)}
                  className="w-full h-10 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
                >
                  <option value="">-- Choose Alternative Available Ingredient --</option>
                  {inventory
                    .filter((inv) => inv.stockQty > 0)
                    .map((inv) => (
                      <option key={inv.id} value={inv.id}>
                        {inv.name} (Available: {inv.stockQty} {inv.unit})
                      </option>
                    ))}
                </select>
                <button
                  onClick={handleConfirmSubstitute}
                  disabled={!selectedSubstituteId}
                  className="w-full py-2.5 bg-[#D4AF37] hover:bg-[#F6C453] disabled:opacity-40 text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center justify-center gap-2"
                >
                  <RefreshCw size={15} /> Substitute Ingredient & Continue Sale
                </button>
              </div>

              {/* Option B: Force Sell with Current Stock */}
              <div className="p-3.5 bg-[#243244] rounded-xl border border-white/10 space-y-2">
                <span className="text-xs font-bold text-[#F8FAFC] block">
                  Option 2: Sell with Current Partial Stock
                </span>
                <button
                  onClick={handleForceSellCurrentStock}
                  className="w-full py-2.5 bg-[#243244] hover:bg-[#2F4158] text-[#F8FAFC] border border-white/20 rounded-xl text-xs font-bold"
                >
                  Proceed Sale using Available Partial Stock
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Printable Thermal Receipt (Note: Thermal receipt ticket intentionally excludes heavy slip photo as requested) */}
      {receiptModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-[#1E293B] p-6 rounded-[24px] max-w-sm w-full text-center space-y-4 font-mono text-xs shadow-2xl border border-white/10 text-[#F8FAFC]">
            <h3 className="font-bold text-lg text-[#D4AF37]">CAFE LINA POS RECEIPT</h3>
            <div className="text-[10px] text-[#94A3B8] space-y-0.5">
              <p>Voucher ID: {receiptModal.voucherId}</p>
              <p>Order ID: {receiptModal.orderId}</p>
              <p>Cashier: {receiptModal.cashierName}</p>
              <p>Date: {receiptModal.date} {receiptModal.createdTime}</p>
            </div>

            <div className="border-t border-b border-white/10 py-3 space-y-1.5 text-left">
              {receiptModal.items.map((it, idx) => (
                <div key={idx} className="flex justify-between text-[#CBD5E1]">
                  <span>
                    {it.quantity}x {it.menuItem.name}
                  </span>
                  <span className="font-bold text-[#F8FAFC]">{it.quantity * it.menuItem.price} ETB</span>
                </div>
              ))}
            </div>

            <div className="space-y-1 text-left text-[11px] text-[#CBD5E1]">
              <div className="flex justify-between font-bold">
                <span>Payment Method</span>
                <span className="text-[#D4AF37]">{receiptModal.paymentMethod}</span>
              </div>
              {receiptModal.accountNumberOrPhone && (
                <div className="flex justify-between">
                  <span>Acc / Phone</span>
                  <span className="font-mono">{receiptModal.accountNumberOrPhone}</span>
                </div>
              )}
            </div>

            <div className="flex justify-between font-bold text-base text-[#F8FAFC] border-t border-white/10 pt-2">
              <span>TOTAL PAID</span>
              <span className="text-[#D4AF37]">{receiptModal.grandTotal} ETB</span>
            </div>

            <div className="flex gap-3 pt-2">
              <button
                onClick={() => window.print()}
                className="flex-1 bg-[#D4AF37] text-[#0F172A] py-3 rounded-[14px] font-sans font-bold text-xs flex items-center justify-center gap-1.5 shadow-md"
              >
                <Printer size={16} /> Print Receipt
              </button>
              <button
                onClick={() => setReceiptModal(null)}
                className="flex-1 bg-[#243244] text-[#F8FAFC] py-3 rounded-[14px] font-sans font-bold text-xs hover:bg-[#2F4158] border border-white/10"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: View Voucher Full Details (Includes attached payment slip photo preview) */}
      {selectedVoucherForView && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]">
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <div>
                <h3 className="font-serif font-bold text-lg text-[#D4AF37]">{selectedVoucherForView.voucherId}</h3>
                <p className="text-xs text-[#94A3B8]">Date: {selectedVoucherForView.date} {selectedVoucherForView.createdTime}</p>
              </div>
              <button onClick={() => setSelectedVoucherForView(null)} className="p-1 text-gray-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="p-3 bg-[#243244] rounded-xl space-y-1">
                <p>Cashier: <strong className="text-[#F8FAFC]">{selectedVoucherForView.cashierName}</strong></p>
                <p>Payment: <strong className="text-[#22C55E]">{selectedVoucherForView.paymentMethod}</strong></p>
                {selectedVoucherForView.accountNumberOrPhone && (
                  <p>Account/Phone: <strong className="text-[#D4AF37] font-mono">{selectedVoucherForView.accountNumberOrPhone}</strong></p>
                )}
                <p>Total Amount: <strong className="text-[#D4AF37] text-sm">{selectedVoucherForView.grandTotal} ETB</strong></p>
              </div>

              {selectedVoucherForView.slipPhotoUrl && (
                <div className="p-3 bg-[#243244] rounded-xl space-y-2 border border-white/10">
                  <span className="text-[10px] uppercase font-bold text-[#94A3B8] block">Attached Payment Slip Photo</span>
                  <img
                    src={selectedVoucherForView.slipPhotoUrl}
                    alt="Payment Slip"
                    className="w-full h-40 object-cover rounded-lg border border-white/10"
                  />
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedVoucherForView(null)}
              className="w-full py-2.5 bg-[#243244] hover:bg-[#2F4158] text-[#F8FAFC] rounded-xl text-xs font-bold"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* MODAL 4: Edit POS Voucher */}
      {editingVoucher && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onUpdatePOSReceipt(editingVoucher);
              setEditingVoucher(null);
            }}
            className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]"
          >
            <div className="flex justify-between items-center border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg">Edit POS Voucher {editingVoucher.voucherId}</h3>
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="p-1 text-gray-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Payment Method</label>
              <select
                value={editingVoucher.paymentMethod}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, paymentMethod: e.target.value as any })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              >
                <option value="Cash">Cash</option>
                <option value="Card">Card</option>
                <option value="Bank Transfer">Bank Transfer</option>
                <option value="Telebirr">Telebirr</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#CBD5E1] mb-1">Account No. / Phone Number</label>
              <input
                type="text"
                value={editingVoucher.accountNumberOrPhone || ''}
                onChange={(e) => setEditingVoucher({ ...editingVoucher, accountNumberOrPhone: e.target.value })}
                className="w-full h-11 bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3 text-xs focus:outline-none focus:border-[#D4AF37]"
              />
            </div>

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditingVoucher(null)}
                className="flex-1 h-11 bg-[#243244] text-[#CBD5E1] rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 h-11 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
