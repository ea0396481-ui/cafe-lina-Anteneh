import React, { useState } from 'react';
import { InventoryItem, StoreRecord } from '../../types';
import {
  PackageCheck,
  Plus,
  Search,
  AlertTriangle,
  Calendar,
  Tag,
  Box,
  Trash2,
  Upload,
  X,
  CheckCircle2,
  Layers,
  Building2,
  Clock,
  Sparkles,
  Check,
  Image as ImageIcon,
} from 'lucide-react';

interface InventoryERPProps {
  inventory: InventoryItem[];
  stores?: StoreRecord[];
  onUpdateStock: (id: string, change: number, action: 'add' | 'subtract', newExpiryDate?: string) => void;
  onAddInventoryItem: (item: Partial<InventoryItem>) => void;
  onDeleteInventoryItem: (id: string) => void;
}

const DEFAULT_CATEGORIES = [
  'Coffee Beans',
  'Dairy & Milk',
  'Bakery & Flour',
  'Syrups & Flavors',
  'Teas & Spices',
  'Packaging & Bio-Compost',
  'Produce & Fruit',
  'Oils & Condiments',
  'Beverages',
];

const PRESET_IMAGES = [
  { label: 'Coffee Beans', url: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=400&q=80' },
  { label: 'Fresh Milk', url: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=400&q=80' },
  { label: 'Chocolate', url: 'https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=400&q=80' },
  { label: 'Butter', url: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&w=400&q=80' },
  { label: 'Syrup Bottle', url: 'https://images.unsplash.com/photo-1546554137-f86b9593a222?auto=format&fit=crop&w=400&q=80' },
  { label: 'Eco Cups', url: 'https://images.unsplash.com/photo-1517256064527-09c73fc73e38?auto=format&fit=crop&w=400&q=80' },
  { label: 'Spices & Tea', url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=400&q=80' },
  { label: 'Flour & Grain', url: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=400&q=80' },
];

export const InventoryERP: React.FC<InventoryERPProps> = ({
  inventory,
  stores = [],
  onUpdateStock,
  onAddInventoryItem,
  onDeleteInventoryItem,
}) => {
  const [categories, setCategories] = useState<string[]>(DEFAULT_CATEGORIES);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [filterType, setFilterType] = useState<'All' | 'LowStock' | 'ExpiringSoon'>('All');
  const [search, setSearch] = useState<string>('');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState<boolean>(false);
  const [newCategoryName, setNewCategoryName] = useState<string>('');

  // Stock In Modal
  const [stockInItem, setStockInItem] = useState<InventoryItem | null>(null);
  const [stockInQty, setStockInQty] = useState<number>(10);
  const [stockInExpiry, setStockInExpiry] = useState<string>('');

  // New Ingredient Form state
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    category: 'Coffee Beans',
    sku: '',
    unit: 'kg',
    stockQty: '10',
    storeName: stores.length > 0 ? stores[0].name : 'Bole Main Central Store',
    reorderLevel: '5',
    costPerUnit: '150',
    supplierName: 'Abyssinia Coffee Traders',
    image: PRESET_IMAGES[0].url,
    hasExpiry: true,
    expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  });

  const [previewImage, setPreviewImage] = useState<string>(PRESET_IMAGES[0].url);

  // Helper calculation for expiry status
  const getExpiryStatus = (item: InventoryItem) => {
    if (!item.hasExpiry || !item.expiryDate) {
      return { status: 'none', label: 'No Expiry', color: 'bg-gray-500/10 text-gray-400 border-gray-500/20' };
    }
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const expDate = new Date(item.expiryDate);
    expDate.setHours(0, 0, 0, 0);

    const diffDays = Math.ceil((expDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
      return { status: 'expired', label: `Expired (${Math.abs(diffDays)}d ago)`, color: 'bg-red-500/20 text-red-400 border-red-500/30 font-bold animate-pulse' };
    }
    if (diffDays <= 30) {
      return { status: 'expiring', label: `Expires in ${diffDays}d`, color: 'bg-amber-500/20 text-amber-400 border-amber-500/30 font-bold' };
    }
    return { status: 'valid', label: `Exp: ${item.expiryDate}`, color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' };
  };

  // Image Upload Handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setPreviewImage(result);
        setFormData((prev) => ({ ...prev, image: result }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddCategory = () => {
    if (!newCategoryName.trim()) return;
    const cleanCat = newCategoryName.trim();
    if (!categories.includes(cleanCat)) {
      setCategories((prev) => [...prev, cleanCat]);
      setFormData((prev) => ({ ...prev, category: cleanCat }));
    }
    setNewCategoryName('');
    setIsCategoryModalOpen(false);
  };

  const handleDeleteCategory = (catToDelete: string) => {
    setCategories((prev) => prev.filter((c) => c !== catToDelete));
    if (selectedCategory === catToDelete) {
      setSelectedCategory('All');
    }
    if (formData.category === catToDelete) {
      const remaining = categories.filter((c) => c !== catToDelete);
      setFormData((prev) => ({ ...prev, category: remaining[0] || '' }));
    }
  };

  const handleSubmitIngredient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim()) return;

    onAddInventoryItem({
      name: formData.name,
      brand: formData.brand || 'Artisan Brand',
      category: formData.category,
      sku: formData.sku || `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      unit: formData.unit,
      stockQty: parseFloat(formData.stockQty) || 0,
      storeName: formData.storeName || (stores.length > 0 ? stores[0].name : 'Bole Main Central Store'),
      reorderLevel: parseFloat(formData.reorderLevel) || 5,
      costPerUnit: parseFloat(formData.costPerUnit) || 100,
      supplierName: formData.supplierName,
      image: previewImage,
      hasExpiry: formData.hasExpiry,
      expiryDate: formData.hasExpiry ? formData.expiryDate : undefined,
    });

    setIsAddModalOpen(false);
    // Reset form
    setFormData({
      name: '',
      brand: '',
      category: categories[0] || 'Coffee Beans',
      sku: '',
      unit: 'kg',
      stockQty: '10',
      storeName: stores.length > 0 ? stores[0].name : 'Bole Main Central Store',
      reorderLevel: '5',
      costPerUnit: '150',
      supplierName: 'Abyssinia Coffee Traders',
      image: PRESET_IMAGES[0].url,
      hasExpiry: true,
      expiryDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    });
    setPreviewImage(PRESET_IMAGES[0].url);
  };

  const handleStockInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!stockInItem) return;
    onUpdateStock(
      stockInItem.id,
      stockInQty,
      'add',
      stockInItem.hasExpiry ? stockInExpiry : undefined
    );
    setStockInItem(null);
  };

  // Filter logic
  const filteredInventory = inventory.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.sku.toLowerCase().includes(search.toLowerCase()) ||
      (item.brand && item.brand.toLowerCase().includes(search.toLowerCase())) ||
      item.supplierName.toLowerCase().includes(search.toLowerCase());

    const expStatus = getExpiryStatus(item);
    let matchesFilter = true;
    if (filterType === 'LowStock') {
      matchesFilter = item.stockQty <= item.reorderLevel;
    } else if (filterType === 'ExpiringSoon') {
      matchesFilter = expStatus.status === 'expired' || expStatus.status === 'expiring';
    }

    return matchesCategory && matchesSearch && matchesFilter;
  });

  const lowStockCount = inventory.filter((i) => i.stockQty <= i.reorderLevel).length;
  const expiringCount = inventory.filter((i) => {
    const status = getExpiryStatus(i).status;
    return status === 'expired' || status === 'expiring';
  }).length;

  const totalValue = inventory.reduce((sum, item) => sum + item.stockQty * item.costPerUnit, 0);

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
              Warehouse & Raw Materials
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1.5 flex items-center gap-2.5">
            <PackageCheck className="text-[#D4AF37]" size={28} />
            Raw Ingredients & Inventory ERP
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Register raw ingredients, units (kg, liters, grams), brands, categories, and track expiration dates.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setIsCategoryModalOpen(true)}
            className="px-3.5 py-2.5 bg-[#1E293B] hover:bg-[#2F4158] text-[#CBD5E1] hover:text-white border border-white/10 rounded-xl text-xs font-bold flex items-center gap-2 transition-all min-h-[44px]"
          >
            <Layers size={16} className="text-[#D4AF37]" />
            <span>Manage Categories</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2.5 bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] rounded-xl text-xs font-extrabold flex items-center gap-2 transition-all shadow-lg hover:shadow-[#D4AF37]/20 active:scale-95 min-h-[44px]"
          >
            <Plus size={18} />
            <span>Register Ingredient (mmezegbbet)</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5">
        <div className="bg-[#243244] p-4 sm:p-5 rounded-[20px] border border-white/10 shadow-md">
          <span className="text-[11px] font-semibold text-[#94A3B8] block mb-1 uppercase tracking-wider">Total Raw SKUs</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#F8FAFC]">{inventory.length}</span>
            <span className="text-xs font-mono text-[#D4AF37]">{totalValue.toLocaleString()} ETB Value</span>
          </div>
        </div>

        <div className="bg-[#243244] p-4 sm:p-5 rounded-[20px] border border-white/10 shadow-md">
          <span className="text-[11px] font-semibold text-[#94A3B8] block mb-1 uppercase tracking-wider">Low Stock Alerts</span>
          <div className="flex items-center justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#F59E0B]">{lowStockCount}</span>
            <AlertTriangle className="text-[#F59E0B]" size={22} />
          </div>
        </div>

        <div className="bg-[#243244] p-4 sm:p-5 rounded-[20px] border border-white/10 shadow-md">
          <span className="text-[11px] font-semibold text-[#94A3B8] block mb-1 uppercase tracking-wider">Expiry Risks</span>
          <div className="flex items-center justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#EF4444]">{expiringCount}</span>
            <Clock className="text-[#EF4444]" size={22} />
          </div>
        </div>

        <div className="bg-[#243244] p-4 sm:p-5 rounded-[20px] border border-white/10 shadow-md">
          <span className="text-[11px] font-semibold text-[#94A3B8] block mb-1 uppercase tracking-wider">Active Categories</span>
          <div className="flex items-center justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#D4AF37]">{categories.length}</span>
            <Layers className="text-[#D4AF37]" size={22} />
          </div>
        </div>
      </div>

      {/* Search & Category Filter bar */}
      <div className="bg-[#243244] p-4 rounded-[20px] border border-white/10 shadow-md space-y-3">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search Box */}
          <div className="relative flex-1">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search ingredient by name, brand, SKU, or supplier..."
              className="w-full h-[48px] bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl pl-11 pr-4 text-xs sm:text-sm font-medium focus:outline-none focus:border-[#D4AF37]"
            />
            <Search size={18} className="absolute left-3.5 top-3.5 text-[#94A3B8]" />
          </div>

          {/* Quick Filter Status Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => setFilterType('All')}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all ${
                filterType === 'All'
                  ? 'bg-[#D4AF37] text-[#0F172A] border-[#D4AF37]'
                  : 'bg-[#1E293B] text-[#CBD5E1] border-white/10 hover:bg-[#2F4158]'
              }`}
            >
              All SKUs ({inventory.length})
            </button>
            <button
              onClick={() => setFilterType('LowStock')}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all ${
                filterType === 'LowStock'
                  ? 'bg-[#F59E0B] text-[#0F172A] border-[#F59E0B]'
                  : 'bg-[#1E293B] text-[#CBD5E1] border-white/10 hover:bg-[#2F4158]'
              }`}
            >
              Low Stock ({lowStockCount})
            </button>
            <button
              onClick={() => setFilterType('ExpiringSoon')}
              className={`px-3.5 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap border transition-all ${
                filterType === 'ExpiringSoon'
                  ? 'bg-[#EF4444] text-white border-[#EF4444]'
                  : 'bg-[#1E293B] text-[#CBD5E1] border-white/10 hover:bg-[#2F4158]'
              }`}
            >
              Expiring Risks ({expiringCount})
            </button>
          </div>
        </div>

        {/* Category Pills */}
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar pt-1 border-t border-white/5">
          <button
            onClick={() => setSelectedCategory('All')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
              selectedCategory === 'All'
                ? 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 font-bold'
                : 'bg-[#1E293B] text-[#94A3B8] border border-white/5 hover:text-white'
            }`}
          >
            All Categories
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#D4AF37]/20 text-[#D4AF37] border border-[#D4AF37]/40 font-bold'
                  : 'bg-[#1E293B] text-[#94A3B8] border border-white/5 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Table / Mobile Grid */}
      <div className="bg-[#243244] rounded-[22px] border border-white/10 overflow-hidden shadow-[0_12px_30px_rgba(0,0,0,0.35)]">
        {/* Desktop Table View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1E293B] border-b border-white/10 text-[#CBD5E1] uppercase font-bold text-[10px] tracking-wider">
              <tr>
                <th className="p-4">Raw Ingredient & Brand</th>
                <th className="p-4">Category</th>
                <th className="p-4">Stock Level & Unit</th>
                <th className="p-4">Unit Cost</th>
                <th className="p-4">Expiration Status</th>
                <th className="p-4">Supplier</th>
                <th className="p-4 text-center">Actions / Stock In</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filteredInventory.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-12 text-center text-[#94A3B8] text-xs">
                    No raw ingredients match your query. Click "Register Ingredient" to add a new item.
                  </td>
                </tr>
              ) : (
                filteredInventory.map((item) => {
                  const expInfo = getExpiryStatus(item);
                  return (
                    <tr key={item.id} className="hover:bg-[#2F4158] transition-colors">
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={item.image || PRESET_IMAGES[0].url}
                            alt={item.name}
                            className="w-11 h-11 object-cover rounded-xl border border-white/10 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-[#F8FAFC] text-sm block">{item.name}</span>
                            <div className="flex items-center gap-2 mt-0.5">
                              {item.brand && (
                                <span className="text-[10px] text-[#D4AF37] font-semibold bg-[#1E293B] px-1.5 py-0.5 rounded border border-[#D4AF37]/30">
                                  {item.brand}
                                </span>
                              )}
                              <span className="text-[10px] text-[#94A3B8] font-mono">{item.sku}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      <td className="p-4 text-[#CBD5E1]">
                        <span className="bg-[#1E293B] px-2.5 py-1 rounded-lg text-xs border border-white/5 font-medium">
                          {item.category}
                        </span>
                      </td>

                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-sm text-[#F8FAFC]">
                            {item.stockQty} {item.unit}
                          </span>
                          {item.stockQty <= item.reorderLevel && (
                            <span className="text-[10px] bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/30 font-bold px-2 py-0.5 rounded-full">
                              Low Stock
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-[#94A3B8] block mt-0.5">Reorder at {item.reorderLevel} {item.unit}</span>
                        <span className="text-[10px] text-[#D4AF37] font-semibold flex items-center gap-1 mt-1">
                          <Building2 size={11} /> {item.storeName || 'Bole Main Central Store'}
                        </span>
                      </td>

                      <td className="p-4 font-extrabold text-[#D4AF37] text-sm">
                        {item.costPerUnit} ETB/{item.unit}
                      </td>

                      <td className="p-4">
                        <span className={`text-[11px] px-2.5 py-1 rounded-full border ${expInfo.color} inline-block font-semibold`}>
                          {expInfo.label}
                        </span>
                      </td>

                      <td className="p-4 text-[#CBD5E1]">
                        <span className="text-xs">{item.supplierName}</span>
                      </td>

                      <td className="p-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => {
                              setStockInItem(item);
                              setStockInQty(10);
                              setStockInExpiry(item.expiryDate || new Date(Date.now() + 60 * 24 * 3600 * 1000).toISOString().split('T')[0]);
                            }}
                            className="bg-[#22C55E]/10 hover:bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/30 text-xs font-bold px-3 py-1.5 rounded-xl transition-all flex items-center gap-1"
                          >
                            <Plus size={14} /> Stock In
                          </button>
                          <button
                            onClick={() => onUpdateStock(item.id, 5, 'subtract')}
                            className="bg-[#EF4444]/10 hover:bg-[#EF4444]/20 text-[#EF4444] border border-[#EF4444]/30 text-xs font-bold px-2.5 py-1.5 rounded-xl transition-all"
                            title="Subtract stock"
                          >
                            - Out
                          </button>
                          <button
                            onClick={() => onDeleteInventoryItem(item.id)}
                            className="p-1.5 text-gray-400 hover:text-[#EF4444] hover:bg-[#EF4444]/10 rounded-lg transition-colors"
                            title="Delete SKU"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Mobile Stacked Card View (< 768px) */}
        <div className="md:hidden divide-y divide-white/10">
          {filteredInventory.length === 0 ? (
            <div className="p-8 text-center text-[#94A3B8] text-xs">
              No raw ingredients match your search query.
            </div>
          ) : (
            filteredInventory.map((item) => {
              const expInfo = getExpiryStatus(item);
              return (
                <div key={item.id} className="p-4 space-y-3">
                  <div className="flex items-start gap-3">
                    <img
                      src={item.image || PRESET_IMAGES[0].url}
                      alt={item.name}
                      className="w-14 h-14 object-cover rounded-xl border border-white/10 shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-[#F8FAFC] text-sm leading-tight">{item.name}</h3>
                      <div className="flex flex-wrap items-center gap-1.5 mt-1">
                        {item.brand && (
                          <span className="text-[10px] text-[#D4AF37] font-semibold bg-[#1E293B] px-1.5 py-0.5 rounded border border-[#D4AF37]/30">
                            {item.brand}
                          </span>
                        )}
                        <span className="text-[10px] text-[#94A3B8] font-mono">{item.sku}</span>
                        <span className="text-[10px] bg-[#1E293B] text-[#CBD5E1] px-1.5 py-0.5 rounded">
                          {item.category}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => onDeleteInventoryItem(item.id)}
                      className="p-2 text-gray-400 hover:text-[#EF4444]"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-[#1E293B] p-3 rounded-xl border border-white/5">
                    <div>
                      <span className="text-[#94A3B8] text-[10px] uppercase block">Current Stock</span>
                      <span className="font-extrabold text-[#F8FAFC] text-sm">{item.stockQty} {item.unit}</span>
                    </div>
                    <div>
                      <span className="text-[#94A3B8] text-[10px] uppercase block">Unit Cost</span>
                      <span className="font-extrabold text-[#D4AF37] text-sm">{item.costPerUnit} ETB/{item.unit}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-xs pt-1">
                    <div>
                      <span className="text-[10px] text-[#94A3B8] block">Expiration Status</span>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full border ${expInfo.color} font-semibold inline-block mt-0.5`}>
                        {expInfo.label}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setStockInItem(item);
                          setStockInQty(10);
                          setStockInExpiry(item.expiryDate || new Date(Date.now() + 60 * 24 * 3600 * 1000).toISOString().split('T')[0]);
                        }}
                        className="bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30 text-xs font-bold px-3 py-2 rounded-xl active:scale-95 transition-all"
                      >
                        + Stock In
                      </button>
                      <button
                        onClick={() => onUpdateStock(item.id, 5, 'subtract')}
                        className="bg-[#EF4444]/10 text-[#EF4444] border border-[#EF4444]/30 text-xs font-bold px-3 py-2 rounded-xl active:scale-95 transition-all"
                      >
                        - Out
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* MODAL 1: Register New Ingredient (Gbatochen Mmezegbbet) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-2xl w-full p-5 sm:p-7 space-y-5 my-8 shadow-2xl text-[#F8FAFC]">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 bg-[#D4AF37]/10 border border-[#D4AF37]/30 rounded-xl text-[#D4AF37]">
                  <PackageCheck size={22} />
                </div>
                <div>
                  <h2 className="text-lg sm:text-xl font-serif font-bold text-[#F8FAFC]">
                    Register New Raw Ingredient (Gbatochen Mmezegbbet)
                  </h2>
                  <p className="text-xs text-[#94A3B8]">Add raw material details, measurement unit, brand & expiry date</p>
                </div>
              </div>

              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 text-[#94A3B8] hover:text-white rounded-xl bg-[#243244]"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSubmitIngredient} className="space-y-4">
              {/* Row 1: Ingredient Name & Brand */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Ingredient Name (Gbatochen Name) *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Yirgacheffe Beans, Organic Milk, Wheat Flour"
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Brand Name (Brandun Mmezegbbet)
                  </label>
                  <input
                    type="text"
                    value={formData.brand}
                    onChange={(e) => setFormData({ ...formData, brand: e.target.value })}
                    placeholder="e.g. Tadele Farmers, Lame Dairy, Monin, Callebaut"
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Row 2: Category Selection & Category Add */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#CBD5E1]">
                    Category (Ingredient Category Mercha) *
                  </label>
                  <button
                    type="button"
                    onClick={() => setIsCategoryModalOpen(true)}
                    className="text-xs text-[#D4AF37] font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus size={14} /> Add New Category
                  </button>
                </div>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] cursor-pointer"
                >
                  {categories.map((c) => (
                    <option key={c} value={c} className="bg-[#1E293B] text-white">
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* Row 3: Unit of Measurement & Quantity Stock */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Measurement Unit (Be Liter, Be Gram, Be Kilo, etc.) *
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] cursor-pointer"
                  >
                    <option value="kg">Kilogram (kg / Be Kilo)</option>
                    <option value="g">Gram (g / Be Gram)</option>
                    <option value="liters">Liter (L / Be Liter)</option>
                    <option value="ml">Milliliter (ml)</option>
                    <option value="units">Piece / Unit (Andu)</option>
                    <option value="packs">Pack / Packet</option>
                    <option value="boxes">Box</option>
                    <option value="bottles">Bottle</option>
                    <option value="bags">Bag / Sack</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Initial Stock Amount (Bzat) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={formData.stockQty}
                    onChange={(e) => setFormData({ ...formData, stockQty: e.target.value })}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1 flex items-center gap-1">
                    <Building2 size={13} className="text-[#D4AF37]" />
                    Stock Store Location (Stocku Yalebet Store) *
                  </label>
                  <select
                    value={formData.storeName}
                    onChange={(e) => setFormData({ ...formData, storeName: e.target.value })}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37] font-medium cursor-pointer"
                  >
                    {stores.length > 0 ? (
                      stores.map((s) => (
                        <option key={s.id} value={s.name} className="bg-[#1E293B]">
                          {s.name} ({s.location})
                        </option>
                      ))
                    ) : (
                      <>
                        <option value="Bole Main Central Store" className="bg-[#1E293B]">Bole Main Central Store</option>
                        <option value="Kazanchis Branch Store" className="bg-[#1E293B]">Kazanchis Branch Store</option>
                        <option value="Kitchen & Bakery Sub-Store" className="bg-[#1E293B]">Kitchen & Bakery Sub-Store</option>
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Reorder Alert Level
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={formData.reorderLevel}
                    onChange={(e) => setFormData({ ...formData, reorderLevel: e.target.value })}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Row 4: Unit Cost & Supplier */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Cost Per Unit (ETB) *
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={formData.costPerUnit}
                    onChange={(e) => setFormData({ ...formData, costPerUnit: e.target.value })}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                    Supplier Name
                  </label>
                  <input
                    type="text"
                    value={formData.supplierName}
                    onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                    placeholder="e.g. Abyssinia Coffee Traders, Lame Dairy"
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              {/* Row 5: Photo Upload (Photo Upload Maregbet) */}
              <div className="bg-[#243244] p-4 rounded-xl border border-white/10 space-y-3">
                <label className="block text-xs font-bold text-[#CBD5E1] flex items-center gap-2">
                  <ImageIcon size={16} className="text-[#D4AF37]" />
                  Ingredient Photo Upload (Photo Upload Maregbet)
                </label>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  <img
                    src={previewImage}
                    alt="Preview"
                    className="w-16 h-16 object-cover rounded-xl border-2 border-[#D4AF37] shrink-0"
                  />

                  <div className="space-y-2 flex-1 w-full">
                    <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#1E293B] hover:bg-[#2F4158] text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl text-xs font-bold cursor-pointer transition-all">
                      <Upload size={16} /> Choose Image File
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageFileChange}
                        className="hidden"
                      />
                    </label>

                    <p className="text-[11px] text-[#94A3B8]">Or pick from sample presets below:</p>
                    <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
                      {PRESET_IMAGES.map((preset, idx) => (
                        <button
                          type="button"
                          key={idx}
                          onClick={() => {
                            setPreviewImage(preset.url);
                            setFormData({ ...formData, image: preset.url });
                          }}
                          className={`p-1 rounded-lg border text-[10px] font-semibold whitespace-nowrap flex items-center gap-1 shrink-0 ${
                            previewImage === preset.url
                              ? 'border-[#D4AF37] bg-[#D4AF37]/20 text-[#D4AF37]'
                              : 'border-white/10 bg-[#1E293B] text-gray-300'
                          }`}
                        >
                          <img src={preset.url} alt="" className="w-5 h-5 object-cover rounded" />
                          <span>{preset.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Row 6: Expiration Date Checkbox & Date Picker (Expired Date Kalew Tik Maregbet) */}
              <div className="bg-[#243244] p-4 rounded-xl border border-white/10 space-y-3">
                <label className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.hasExpiry}
                    onChange={(e) => setFormData({ ...formData, hasExpiry: e.target.checked })}
                    className="w-5 h-5 accent-[#D4AF37] rounded cursor-pointer"
                  />
                  <div>
                    <span className="text-xs font-extrabold text-[#F8FAFC]">
                      Has Expiration Date? (Expired Date kalew Tik Maregbet)
                    </span>
                    <span className="text-[11px] text-[#94A3B8] block">
                      Check this box if the ingredient has a shelf life/expiration date
                    </span>
                  </div>
                </label>

                {formData.hasExpiry && (
                  <div className="pt-2 border-t border-white/5 animate-fadeIn">
                    <label className="block text-xs font-bold text-[#CBD5E1] mb-1 flex items-center gap-1.5">
                      <Calendar size={14} className="text-[#D4AF37]" /> Expiration Date (Expiry Date) *
                    </label>
                    <input
                      type="date"
                      required={formData.hasExpiry}
                      value={formData.expiryDate}
                      onChange={(e) => setFormData({ ...formData, expiryDate: e.target.value })}
                      className="w-full h-[48px] bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                )}
              </div>

              {/* Modal Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-5 py-3 rounded-xl bg-[#243244] hover:bg-[#2F4158] text-[#CBD5E1] text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-xl bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] text-xs font-extrabold shadow-lg flex items-center gap-2"
                >
                  <CheckCircle2 size={18} />
                  <span>Save Ingredient (Mmezgeb)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: Add New Ingredient Category (Category Mmezegbbet) */}
      {isCategoryModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC]">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="font-serif font-bold text-lg text-[#F8FAFC] flex items-center gap-2">
                <Layers className="text-[#D4AF37]" size={20} />
                Add Ingredient Category (Category Mmezegbbet)
              </h3>
              <button
                onClick={() => setIsCategoryModalOpen(false)}
                className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg bg-[#243244]"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <label className="block text-xs font-semibold text-[#CBD5E1]">
                New Category Title
              </label>
              <input
                type="text"
                value={newCategoryName}
                onChange={(e) => setNewCategoryName(e.target.value)}
                placeholder="e.g. Ethiopian Spices, Specialty Syrups, Bio Compost"
                className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs sm:text-sm focus:outline-none focus:border-[#D4AF37]"
              />

              <div className="pt-2">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[11px] text-[#94A3B8] font-semibold">Existing Categories:</span>
                  <span className="text-[10px] text-[#D4AF37] font-medium">{categories.length} Registered</span>
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto pr-1">
                  {categories.map((c) => (
                    <span
                      key={c}
                      className="text-[11px] bg-[#243244] hover:bg-[#2d3f56] text-[#CBD5E1] hover:text-[#F8FAFC] px-2.5 py-1 rounded-lg border border-white/10 flex items-center gap-1.5 transition-all group"
                    >
                      <span className="font-medium">{c}</span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteCategory(c);
                        }}
                        className="text-gray-400 hover:text-red-400 p-0.5 rounded transition-colors"
                        title={`Delete ${c} category`}
                        aria-label={`Delete ${c} category`}
                      >
                        <X size={12} />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setIsCategoryModalOpen(false)}
                className="px-4 py-2.5 rounded-xl bg-[#243244] text-[#CBD5E1] text-xs font-bold"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleAddCategory}
                disabled={!newCategoryName.trim()}
                className="px-5 py-2.5 rounded-xl bg-[#D4AF37] hover:bg-[#F6C453] text-[#0F172A] text-xs font-extrabold disabled:opacity-40"
              >
                + Register Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Stock In & Batch Expiry Update (Stoke In Ssera & Expiry Display) */}
      {stockInItem && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-5 shadow-2xl text-[#F8FAFC]">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 bg-[#22C55E]/20 text-[#22C55E] border border-[#22C55E]/30 rounded-xl">
                  <Plus size={20} />
                </div>
                <div>
                  <h3 className="font-serif font-bold text-lg text-[#F8FAFC]">Stock In Batch Receipt</h3>
                  <p className="text-xs text-[#94A3B8]">{stockInItem.name}</p>
                </div>
              </div>
              <button
                onClick={() => setStockInItem(null)}
                className="p-1.5 text-[#94A3B8] hover:text-white rounded-lg bg-[#243244]"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleStockInSubmit} className="space-y-4">
              <div className="bg-[#243244] p-3.5 rounded-xl border border-white/5 flex items-center gap-3">
                <img
                  src={stockInItem.image || PRESET_IMAGES[0].url}
                  alt=""
                  className="w-12 h-12 object-cover rounded-lg"
                />
                <div className="text-xs">
                  <span className="font-bold text-[#F8FAFC] block">{stockInItem.name}</span>
                  <span className="text-[#94A3B8]">Current Stock: <strong className="text-[#D4AF37]">{stockInItem.stockQty} {stockInItem.unit}</strong></span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-[#CBD5E1] mb-1">
                  Quantity to Add ({stockInItem.unit}) *
                </label>
                <div className="flex gap-2 mb-2">
                  {[10, 25, 50, 100].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setStockInQty(num)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold border ${
                        stockInQty === num
                          ? 'bg-[#D4AF37] text-[#0F172A] border-[#D4AF37]'
                          : 'bg-[#243244] text-[#CBD5E1] border-white/10'
                      }`}
                    >
                      +{num}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  step="any"
                  required
                  min="0.1"
                  value={stockInQty}
                  onChange={(e) => setStockInQty(parseFloat(e.target.value) || 0)}
                  className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs font-medium focus:outline-none focus:border-[#D4AF37]"
                />
              </div>

              {stockInItem.hasExpiry && (
                <div>
                  <label className="block text-xs font-bold text-[#CBD5E1] mb-1 flex items-center gap-1.5">
                    <Calendar size={14} className="text-[#D4AF37]" />
                    Batch Expiration Date (Expair Date)
                  </label>
                  <input
                    type="date"
                    value={stockInExpiry}
                    onChange={(e) => setStockInExpiry(e.target.value)}
                    className="w-full h-[48px] bg-[#243244] text-[#F8FAFC] border border-white/10 rounded-xl px-3.5 text-xs focus:outline-none focus:border-[#D4AF37]"
                  />
                  <p className="text-[10px] text-[#94A3B8] mt-1">Updates expiry tracking for this restock batch.</p>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-white/10">
                <button
                  type="button"
                  onClick={() => setStockInItem(null)}
                  className="px-4 py-2.5 rounded-xl bg-[#243244] text-[#CBD5E1] text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-[#22C55E] hover:bg-[#16A34A] text-white text-xs font-extrabold flex items-center gap-1.5 shadow-lg"
                >
                  <Check size={16} /> Complete Stock In
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
