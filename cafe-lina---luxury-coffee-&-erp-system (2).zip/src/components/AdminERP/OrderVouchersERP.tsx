import React, { useState } from 'react';
import { Order, Category } from '../../types';
import { ShoppingBag, Calendar, Layers, Search, Eye, Printer, Trash2, X, CheckCircle2 } from 'lucide-react';

interface OrderVouchersERPProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: Order['status']) => void;
  onDeleteOrder: (orderId: string) => void;
}

export const OrderVouchersERP: React.FC<OrderVouchersERPProps> = ({
  orders,
  onUpdateOrderStatus,
  onDeleteOrder,
}) => {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [search, setSearch] = useState<string>('');
  const [selectedOrderForView, setSelectedOrderForView] = useState<Order | null>(null);

  const categories = [
    'All',
    'Coffee',
    'Espresso',
    'Latte',
    'Cappuccino',
    'Bakery',
    'Breakfast',
    'Fresh Juice',
  ];

  // Filter logic: Filter by search, Date, and Category
  const filteredOrders = orders.filter((ord) => {
    const matchSearch =
      ord.id.toLowerCase().includes(search.toLowerCase()) ||
      ord.customerName.toLowerCase().includes(search.toLowerCase()) ||
      ord.customerPhone.includes(search);

    const matchDate = !selectedDate || ord.createdAt.startsWith(selectedDate);

    const matchCat =
      selectedCategory === 'All' ||
      ord.items.some((it) => it.menuItem.category === selectedCategory);

    return matchSearch && matchDate && matchCat;
  });

  const totalSalesVolume = filteredOrders.reduce((sum, o) => sum + o.total, 0);

  return (
    <div className="space-y-6 animate-fadeIn font-sans pb-12">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-white/10">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#D4AF37] bg-[#1E293B] px-3 py-1 rounded-full border border-[#D4AF37]/30">
            Sales & Orders Audit
          </span>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#F8FAFC] mt-1 flex items-center gap-2">
            <ShoppingBag className="text-[#D4AF37]" size={28} />
            Order Vouchers & Sales Breakdown (Order Vouchers)
          </h1>
          <p className="text-xs text-[#94A3B8] mt-1">
            Filter and inspect total placed product orders with item photos, prices, dates, and categories.
          </p>
        </div>

        <div className="bg-[#243244] p-3 px-5 rounded-2xl border border-white/10 shadow-md flex items-center gap-3">
          <div>
            <span className="text-[10px] text-[#94A3B8] uppercase block font-bold">Filtered Sales Volume</span>
            <span className="text-lg font-extrabold text-[#D4AF37]">{totalSalesVolume.toLocaleString()} ETB</span>
          </div>
        </div>
      </div>

      {/* Filters Bar: Date & Category Selector */}
      <div className="bg-[#243244] p-4 rounded-[22px] border border-white/10 grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* Search */}
        <div className="relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search order ID, customer name, phone..."
            className="w-full h-11 bg-[#1E293B] text-[#F8FAFC] placeholder-[#94A3B8] border border-white/10 rounded-xl pl-10 pr-3 text-xs focus:outline-none focus:border-[#D4AF37]"
          />
          <Search size={16} className="absolute left-3.5 top-3.5 text-[#94A3B8]" />
        </div>

        {/* Date Filter (Beken Filter) */}
        <div className="relative">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full h-11 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-xl pl-10 pr-3 text-xs focus:outline-none focus:border-[#D4AF37]"
          />
          <Calendar size={16} className="absolute left-3.5 top-3.5 text-[#D4AF37]" />
        </div>

        {/* Category Filter (Category Filter) */}
        <div className="relative">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full h-11 bg-[#1E293B] text-[#F8FAFC] border border-white/10 rounded-xl pl-10 pr-3 text-xs focus:outline-none focus:border-[#D4AF37]"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                Category: {c}
              </option>
            ))}
          </select>
          <Layers size={16} className="absolute left-3.5 top-3.5 text-[#D4AF37]" />
        </div>
      </div>

      {/* Orders Vouchers Grid with Photos & Prices */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredOrders.length === 0 ? (
          <div className="col-span-full py-16 text-center text-xs text-[#94A3B8] bg-[#243244] rounded-[24px] border border-white/10">
            No order vouchers matched your date or category filter.
          </div>
        ) : (
          filteredOrders.map((ord) => (
            <div
              key={ord.id}
              className="bg-[#243244] p-5 rounded-[22px] border border-white/10 shadow-md space-y-4 hover:border-[#D4AF37]/40 transition-all flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-white/10 pb-3">
                  <div>
                    <span className="text-[11px] font-mono font-bold text-[#D4AF37]">{ord.id}</span>
                    <h3 className="font-serif font-bold text-sm text-[#F8FAFC]">{ord.customerName}</h3>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                      ord.status === 'Ready' || ord.status === 'Completed'
                        ? 'bg-[#22C55E]/10 text-[#22C55E] border border-[#22C55E]/30'
                        : 'bg-[#D4AF37]/10 text-[#D4AF37] border border-[#D4AF37]/30'
                    }`}
                  >
                    {ord.status}
                  </span>
                </div>

                {/* Ordered Items List with Product Photos & Prices */}
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {ord.items.map((it, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-3 p-2 bg-[#1E293B] rounded-xl border border-white/5 text-xs"
                    >
                      <img
                        src={it.menuItem.image}
                        alt={it.menuItem.name}
                        className="w-11 h-11 object-cover rounded-lg shrink-0 border border-white/10"
                      />
                      <div className="flex-1 min-w-0">
                        <span className="font-bold text-[#F8FAFC] block truncate">{it.menuItem.name}</span>
                        <span className="text-[10px] text-[#94A3B8]">
                          {it.quantity}x @ {it.menuItem.price} ETB ({it.menuItem.category})
                        </span>
                      </div>
                      <span className="font-extrabold text-[#D4AF37] text-xs shrink-0">
                        {it.quantity * it.menuItem.price} ETB
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-white/10 flex justify-between items-center text-xs text-[#CBD5E1]">
                  <span>Date: {new Date(ord.createdAt).toLocaleDateString()}</span>
                  <span className="font-extrabold text-base text-[#22C55E]">{ord.total} ETB</span>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                <button
                  onClick={() => setSelectedOrderForView(ord)}
                  className="flex-1 py-2 bg-[#1E293B] hover:bg-[#D4AF37] hover:text-[#0F172A] text-[#D4AF37] border border-[#D4AF37]/30 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1"
                >
                  <Eye size={14} /> View Ticket
                </button>
                <button
                  onClick={() => onDeleteOrder(ord.id)}
                  className="p-2 bg-[#1E293B] hover:bg-red-500 hover:text-white text-gray-400 rounded-xl transition-all"
                  title="Delete Order"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* View Order Voucher Ticket Modal */}
      {selectedOrderForView && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#1E293B] border border-white/10 rounded-[24px] max-w-md w-full p-6 space-y-4 shadow-2xl text-[#F8FAFC] font-mono text-xs">
            <div className="flex justify-between items-center border-b border-white/10 pb-3 font-sans">
              <div>
                <h3 className="font-serif font-bold text-lg text-[#D4AF37]">Order Voucher Ticket</h3>
                <p className="text-xs text-[#94A3B8]">ID: {selectedOrderForView.id}</p>
              </div>
              <button onClick={() => setSelectedOrderForView(null)} className="p-1 text-gray-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-2 text-left">
              <p>Customer: <strong>{selectedOrderForView.customerName}</strong></p>
              <p>Phone: <strong>{selectedOrderForView.customerPhone}</strong></p>
              <p>Payment Method: <strong className="text-[#22C55E]">{selectedOrderForView.paymentMethod}</strong></p>
              <p>Date: {new Date(selectedOrderForView.createdAt).toLocaleString()}</p>
            </div>

            <div className="border-t border-b border-white/10 py-3 space-y-2">
              {selectedOrderForView.items.map((it, idx) => (
                <div key={idx} className="flex justify-between items-center text-[#CBD5E1]">
                  <div className="flex items-center gap-2">
                    <img src={it.menuItem.image} alt={it.menuItem.name} className="w-8 h-8 rounded object-cover" />
                    <span>{it.quantity}x {it.menuItem.name}</span>
                  </div>
                  <span className="font-bold text-[#F8FAFC]">{it.quantity * it.menuItem.price} ETB</span>
                </div>
              ))}
            </div>

            <div className="flex justify-between font-bold text-base text-[#F8FAFC]">
              <span>TOTAL</span>
              <span className="text-[#D4AF37]">{selectedOrderForView.total} ETB</span>
            </div>

            <div className="flex gap-2 pt-2 font-sans">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-[#D4AF37] text-[#0F172A] rounded-xl text-xs font-bold flex items-center justify-center gap-1"
              >
                <Printer size={15} /> Print
              </button>
              <button
                onClick={() => setSelectedOrderForView(null)}
                className="flex-1 py-2.5 bg-[#243244] text-[#F8FAFC] rounded-xl text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
