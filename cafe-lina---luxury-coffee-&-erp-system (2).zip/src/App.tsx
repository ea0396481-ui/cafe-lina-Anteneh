import React, { useState, useEffect } from 'react';
import {
  MenuItem,
  Order,
  Reservation,
  Customer,
  Employee,
  InventoryItem,
  Supplier,
  PurchaseOrder,
  RecipeCost,
  EPRRecord,
  BlogPost,
  CareerPosting,
  UserRole,
  OrderItem,
  DeliveryType,
} from './types';
import {
  INITIAL_MENU_ITEMS,
  INITIAL_ORDERS,
  INITIAL_RESERVATIONS,
  INITIAL_CUSTOMERS,
  INITIAL_EMPLOYEES,
  INITIAL_INVENTORY,
  INITIAL_SUPPLIERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_RECIPE_COSTS,
  INITIAL_EPR_RECORDS,
  INITIAL_BLOG_POSTS,
  INITIAL_CAREERS,
  INITIAL_CATEGORIES,
  INITIAL_STORES,
  INITIAL_STOCK_IN_VOUCHERS,
  INITIAL_STORE_REQUESTS,
  INITIAL_STORE_TRANSFERS,
  INITIAL_POS_RECEIPTS,
  INITIAL_BIN_CARDS,
  INITIAL_DAMAGE_VOUCHERS,
  INITIAL_STAFF_MEALS,
  INITIAL_SYSTEM_USERS,
} from './data/mockData';

import {
  CategoryRecord,
  StoreRecord,
  StockInVoucher,
  StoreRequestVoucher,
  StoreTransferVoucher,
  POSReceiptVoucher,
  BinCardEntry,
  DamageVoucher,
  StaffMealRecord,
  SystemUser,
} from './types';

import {
  subscribeToCollection,
  saveItem,
  deleteItem,
  resetCollection,
} from './lib/firebaseSync';

import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { TodaysSpecials } from './components/TodaysSpecials';
import { MenuView } from './components/MenuView';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { ReservationSection } from './components/ReservationSection';
import { CustomerPortal } from './components/CustomerPortal';
import { AboutPage } from './components/AboutPage';
import { GalleryPage } from './components/GalleryPage';
import { BlogPage } from './components/BlogPage';
import { CareerPage } from './components/CareerPage';
import { ContactPage } from './components/ContactPage';
import { PrivacyTermsPages } from './components/PrivacyTermsPages';
import { NotFoundPage } from './components/NotFoundPage';
import { Footer } from './components/Footer';

// Admin & ERP Modules
import { ERPLayout } from './components/AdminERP/ERPLayout';
import { AdminDashboard } from './components/AdminERP/AdminDashboard';
import { POSSystem } from './components/AdminERP/POSSystem';
import { KitchenDisplaySystem } from './components/AdminERP/KitchenDisplaySystem';
import { MenuManagement } from './components/AdminERP/MenuManagement';
import { InventoryERP } from './components/AdminERP/InventoryERP';
import { SupplierERP } from './components/AdminERP/SupplierERP';
import { RecipeCosting } from './components/AdminERP/RecipeCosting';
import { HRModule } from './components/AdminERP/HRModule';
import { EPRModule } from './components/AdminERP/EPRModule';
import { AnalyticsReports } from './components/AdminERP/AnalyticsReports';
import { SettingsManager } from './components/AdminERP/SettingsManager';
import { LiveOrdersQueue } from './components/AdminERP/LiveOrdersQueue';
import { ProductCostingERP } from './components/AdminERP/ProductCostingERP';
import { StockInVoucherERP } from './components/AdminERP/StockInVoucherERP';
import { CategoriesERP } from './components/AdminERP/CategoriesERP';
import { StoresERP } from './components/AdminERP/StoresERP';
import { CustomersERP } from './components/AdminERP/CustomersERP';
import { OrderVouchersERP } from './components/AdminERP/OrderVouchersERP';
import { StoreRequestERP } from './components/AdminERP/StoreRequestERP';
import { StoreTransferERP } from './components/AdminERP/StoreTransferERP';
import { StoreBalanceExpiryERP } from './components/AdminERP/StoreBalanceExpiryERP';
import { BinCardERP } from './components/AdminERP/BinCardERP';
import { DamageERP } from './components/AdminERP/DamageERP';
import { StaffFoodERP } from './components/AdminERP/StaffFoodERP';
import { ReportsERP } from './components/AdminERP/ReportsERP';
import { SettingsResetERP } from './components/AdminERP/SettingsResetERP';


import { AuthModal } from './components/AuthModal';

export default function App() {
  // App Navigation & Role State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [currentUserRole, setCurrentUserRole] = useState<UserRole>('Customer');
  const [isERPView, setIsERPView] = useState<boolean>(false);
  const [activeERPModule, setActiveERPModule] = useState<string>('dashboard');

  // Auth Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authTargetRole, setAuthTargetRole] = useState<UserRole | undefined>(undefined);
  const [loggedInUser, setLoggedInUser] = useState<SystemUser | null>(null);

  const handleOpenAuthModal = (open: boolean, targetRole?: UserRole) => {
    setAuthTargetRole(targetRole);
    setIsAuthModalOpen(open);
  };

  const handleLoginSuccess = (user: SystemUser) => {
    setLoggedInUser(user);
    setCurrentUserRole(user.role);
    setIsERPView(true);
    if (user.role === 'Cashier') {
      setActiveERPModule('pos');
    } else if (user.role === 'Kitchen') {
      setActiveERPModule('kds');
    } else {
      setActiveERPModule('dashboard');
    }
  };

  const handleSignOut = () => {
    setLoggedInUser(null);
    setCurrentUserRole('Customer');
    setIsERPView(false);
  };

  // Core Data States
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU_ITEMS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [reservations, setReservations] = useState<Reservation[]>(INITIAL_RESERVATIONS);
  const [inventory, setInventory] = useState<InventoryItem[]>(INITIAL_INVENTORY);
  const [suppliers, setSuppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES);
  const [recipeCosts, setRecipeCosts] = useState<RecipeCost[]>(INITIAL_RECIPE_COSTS);
  const [eprRecords, setEprRecords] = useState<EPRRecord[]>(INITIAL_EPR_RECORDS);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [categories, setCategories] = useState<CategoryRecord[]>(INITIAL_CATEGORIES);
  const [stores, setStores] = useState<StoreRecord[]>(INITIAL_STORES);
  const [stockInVouchers, setStockInVouchers] = useState<StockInVoucher[]>(INITIAL_STOCK_IN_VOUCHERS);
  const [storeRequests, setStoreRequests] = useState<StoreRequestVoucher[]>(INITIAL_STORE_REQUESTS);
  const [storeTransfers, setStoreTransfers] = useState<StoreTransferVoucher[]>(INITIAL_STORE_TRANSFERS);
  const [posReceipts, setPosReceipts] = useState<POSReceiptVoucher[]>(INITIAL_POS_RECEIPTS);
  const [binCards, setBinCards] = useState<BinCardEntry[]>(INITIAL_BIN_CARDS);
  const [damageVouchers, setDamageVouchers] = useState<DamageVoucher[]>(INITIAL_DAMAGE_VOUCHERS);
  const [staffMeals, setStaffMeals] = useState<StaffMealRecord[]>(INITIAL_STAFF_MEALS);
  const [systemUsers, setSystemUsers] = useState<SystemUser[]>(INITIAL_SYSTEM_USERS);

  // Real-time Firebase Sync Effect across all devices
  useEffect(() => {
    const unsubMenuItems = subscribeToCollection('menuItems', 'id', INITIAL_MENU_ITEMS, setMenuItems);
    const unsubOrders = subscribeToCollection('orders', 'id', INITIAL_ORDERS, setOrders);
    const unsubReservations = subscribeToCollection('reservations', 'id', INITIAL_RESERVATIONS, setReservations);
    const unsubInventory = subscribeToCollection('inventory', 'id', INITIAL_INVENTORY, setInventory);
    const unsubSuppliers = subscribeToCollection('suppliers', 'id', INITIAL_SUPPLIERS, setSuppliers);
    const unsubPO = subscribeToCollection('purchaseOrders', 'id', INITIAL_PURCHASE_ORDERS, setPurchaseOrders);
    const unsubEmployees = subscribeToCollection('employees', 'id', INITIAL_EMPLOYEES, setEmployees);
    const unsubRecipe = subscribeToCollection('recipeCosts', 'id', INITIAL_RECIPE_COSTS, setRecipeCosts);
    const unsubEpr = subscribeToCollection('eprRecords', 'id', INITIAL_EPR_RECORDS, setEprRecords);
    const unsubCustomers = subscribeToCollection('customers', 'id', INITIAL_CUSTOMERS, setCustomers);
    const unsubCategories = subscribeToCollection('categories', 'id', INITIAL_CATEGORIES, setCategories);
    const unsubStores = subscribeToCollection('stores', 'id', INITIAL_STORES, setStores);
    const unsubStockIn = subscribeToCollection('stockInVouchers', 'voucherId', INITIAL_STOCK_IN_VOUCHERS, setStockInVouchers);
    const unsubStoreReq = subscribeToCollection('storeRequests', 'voucherId', INITIAL_STORE_REQUESTS, setStoreRequests);
    const unsubStoreTransfer = subscribeToCollection('storeTransfers', 'voucherId', INITIAL_STORE_TRANSFERS, setStoreTransfers);
    const unsubPosReceipts = subscribeToCollection('posReceipts', 'voucherId', INITIAL_POS_RECEIPTS, setPosReceipts);
    const unsubBinCards = subscribeToCollection('binCards', 'id', INITIAL_BIN_CARDS, setBinCards);
    const unsubDamage = subscribeToCollection('damageVouchers', 'voucherId', INITIAL_DAMAGE_VOUCHERS, setDamageVouchers);
    const unsubStaffMeals = subscribeToCollection('staffMeals', 'id', INITIAL_STAFF_MEALS, setStaffMeals);
    const unsubSystemUsers = subscribeToCollection('systemUsers', 'id', INITIAL_SYSTEM_USERS, setSystemUsers);

    return () => {
      unsubMenuItems();
      unsubOrders();
      unsubReservations();
      unsubInventory();
      unsubSuppliers();
      unsubPO();
      unsubEmployees();
      unsubRecipe();
      unsubEpr();
      unsubCustomers();
      unsubCategories();
      unsubStores();
      unsubStockIn();
      unsubStoreReq();
      unsubStoreTransfer();
      unsubPosReceipts();
      unsubBinCards();
      unsubDamage();
      unsubStaffMeals();
      unsubSystemUsers();
    };
  }, []);

  // Damage Voucher Handlers
  const handleAddDamageVoucher = async (v: DamageVoucher) => {
    await saveItem('damageVouchers', v, 'voucherId');

    // Automatically deduct damaged ingredient quantities from inventory in Firebase!
    const updatedInvList = inventory.map((inv) => {
      const itemDmg = v.items.find((it) => it.itemId === inv.id);
      if (itemDmg) {
        return {
          ...inv,
          stockQty: Math.max(0, inv.stockQty - itemDmg.qty),
        };
      }
      return inv;
    });

    for (const inv of updatedInvList) {
      const itemDmg = v.items.find((it) => it.itemId === inv.id);
      if (itemDmg) {
        await saveItem('inventory', inv, 'id');
      }
    }
  };

  const handleUpdateDamageVoucher = async (v: DamageVoucher) => {
    await saveItem('damageVouchers', v, 'voucherId');
  };

  const handleDeleteDamageVoucher = async (voucherId: string) => {
    await deleteItem('damageVouchers', voucherId);
  };

  // Staff Meal Handlers
  const handleAddStaffMeal = async (s: StaffMealRecord) => {
    await saveItem('staffMeals', s, 'id');
  };

  const handleDeleteStaffMeal = async (id: string) => {
    await deleteItem('staffMeals', id);
  };

  // System User Handlers
  const handleAddSystemUser = async (u: SystemUser) => {
    await saveItem('systemUsers', u, 'id');
  };

  const handleUpdateSystemUser = async (u: SystemUser) => {
    await saveItem('systemUsers', u, 'id');
  };

  const handleDeleteSystemUser = async (id: string) => {
    await deleteItem('systemUsers', id);
  };

  // System Factory Reset Handler
  const handleSystemReset = async () => {
    await resetCollection('menuItems', INITIAL_MENU_ITEMS, 'id');
    await resetCollection('orders', INITIAL_ORDERS, 'id');
    await resetCollection('reservations', INITIAL_RESERVATIONS, 'id');
    await resetCollection('inventory', INITIAL_INVENTORY, 'id');
    await resetCollection('suppliers', INITIAL_SUPPLIERS, 'id');
    await resetCollection('purchaseOrders', INITIAL_PURCHASE_ORDERS, 'id');
    await resetCollection('employees', INITIAL_EMPLOYEES, 'id');
    await resetCollection('recipeCosts', INITIAL_RECIPE_COSTS, 'id');
    await resetCollection('eprRecords', INITIAL_EPR_RECORDS, 'id');
    await resetCollection('customers', INITIAL_CUSTOMERS, 'id');
    await resetCollection('categories', INITIAL_CATEGORIES, 'id');
    await resetCollection('stores', INITIAL_STORES, 'id');
    await resetCollection('stockInVouchers', INITIAL_STOCK_IN_VOUCHERS, 'voucherId');
    await resetCollection('storeRequests', INITIAL_STORE_REQUESTS, 'voucherId');
    await resetCollection('storeTransfers', INITIAL_STORE_TRANSFERS, 'voucherId');
    await resetCollection('posReceipts', INITIAL_POS_RECEIPTS, 'voucherId');
    await resetCollection('binCards', INITIAL_BIN_CARDS, 'id');
    await resetCollection('damageVouchers', INITIAL_DAMAGE_VOUCHERS, 'voucherId');
    await resetCollection('staffMeals', INITIAL_STAFF_MEALS, 'id');
    await resetCollection('systemUsers', INITIAL_SYSTEM_USERS, 'id');
  };


  // Cart & Wishlist State
  const [cartItems, setCartItems] = useState<OrderItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [couponCode, setCouponCode] = useState<string>('');
  const [deliveryType, setDeliveryType] = useState<DeliveryType>('Delivery');
  const [wishlistIds, setWishlistIds] = useState<string[]>(['item-1', 'item-2']);

  // Cart Actions
  const handleAddToCart = (item: MenuItem, customOptions?: string[], notes?: string) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex((c) => c.menuItem.id === item.id);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += 1;
        return updated;
      }
      return [...prev, { menuItem: item, quantity: 1, selectedOptions: customOptions, specialInstructions: notes }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQty = (index: number, newQty: number) => {
    setCartItems((prev) =>
      prev
        .map((item, i) => (i === index ? { ...item, quantity: newQty } : item))
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const toggleWishlist = (itemId: string) => {
    setWishlistIds((prev) =>
      prev.includes(itemId) ? prev.filter((id) => id !== itemId) : [...prev, itemId]
    );
  };

  const handleAddOrder = async (newOrder: Order) => {
    await saveItem('orders', newOrder, 'id');
    setCartItems([]);
  };

  const handleAddReservation = async (res: Reservation) => {
    await saveItem('reservations', res, 'id');
  };

  const handleUpdateOrderStatus = async (id: string, status: any) => {
    const target = orders.find((o) => o.id === id);
    if (target) {
      await saveItem('orders', { ...target, status }, 'id');
    }
  };

  const handleUpdateStock = async (id: string, change: number, action: 'add' | 'subtract', newExpiryDate?: string) => {
    const target = inventory.find((i) => i.id === id);
    if (target) {
      const newQty = action === 'add' ? target.stockQty + change : Math.max(0, target.stockQty - change);
      const updated = {
        ...target,
        stockQty: newQty,
        lastRestocked: action === 'add' ? new Date().toISOString().split('T')[0] : target.lastRestocked,
        expiryDate: newExpiryDate !== undefined ? newExpiryDate : target.expiryDate,
      };
      await saveItem('inventory', updated, 'id');
    }
  };

  const handleAddInventoryItem = async (newItemData: Partial<InventoryItem>) => {
    const newItem: InventoryItem = {
      id: `INV-${Date.now().toString().slice(-4)}`,
      name: newItemData.name || 'Raw Material',
      category: newItemData.category || 'Coffee Beans',
      brand: newItemData.brand || 'Local Specialty',
      sku: newItemData.sku || `SKU-${Math.floor(1000 + Math.random() * 9000)}`,
      stockQty: Number(newItemData.stockQty) || 0,
      unit: newItemData.unit || 'kg',
      reorderLevel: Number(newItemData.reorderLevel) || 10,
      costPerUnit: Number(newItemData.costPerUnit) || 100,
      supplierName: newItemData.supplierName || 'Primary Supplier',
      lastRestocked: new Date().toISOString().split('T')[0],
      hasExpiry: Boolean(newItemData.hasExpiry),
      expiryDate: newItemData.hasExpiry ? newItemData.expiryDate : undefined,
      image: newItemData.image || 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&w=400&q=80',
    };
    await saveItem('inventory', newItem, 'id');
  };

  const handleDeleteInventoryItem = async (id: string) => {
    await deleteItem('inventory', id);
  };

  const handleAddMenuItem = async (item: Partial<MenuItem>) => {
    const newItem: MenuItem = {
      id: `item-${Date.now()}`,
      name: item.name || 'New Coffee Specialty',
      category: item.category || 'Coffee',
      price: item.price || 120,
      currency: 'ETB',
      image: item.image || 'https://images.unsplash.com/photo-1572442388796-11668a67e53d?auto=format&fit=crop&w=800&q=80',
      description: item.description || 'Artisan preparation',
      ingredients: item.ingredients || ['Specialty Beans'],
      calories: item.calories || 150,
      prepTimeMinutes: item.prepTimeMinutes || 5,
      isAvailable: true,
      rating: 5.0,
      reviewsCount: 1,
      barcode: item.barcode || 'CL-NEW-01',
    };
    await saveItem('menuItems', newItem, 'id');
  };

  const handleDeleteMenuItem = async (id: string) => {
    await deleteItem('menuItems', id);
  };

  // ERP Category Handlers
  const handleAddCategory = async (newCat: CategoryRecord) => {
    await saveItem('categories', newCat, 'id');
  };

  const handleDeleteCategory = async (id: string) => {
    await deleteItem('categories', id);
  };

  // ERP Store Handlers
  const handleAddStore = async (newStore: StoreRecord) => {
    await saveItem('stores', newStore, 'id');
  };

  const handleDeleteStore = async (id: string) => {
    await deleteItem('stores', id);
  };

  // ERP Store Request Handlers
  const handleAddStoreRequest = async (req: StoreRequestVoucher) => {
    await saveItem('storeRequests', req, 'voucherId');
  };

  const handleUpdateStoreRequest = async (req: StoreRequestVoucher) => {
    await saveItem('storeRequests', req, 'voucherId');
  };

  const handleDeleteStoreRequest = async (voucherId: string) => {
    await deleteItem('storeRequests', voucherId);
  };

  // ERP Store Transfer Handlers
  const handleAddStoreTransfer = async (tr: StoreTransferVoucher) => {
    await saveItem('storeTransfers', tr, 'voucherId');
  };

  const handleUpdateStoreTransfer = async (tr: StoreTransferVoucher) => {
    await saveItem('storeTransfers', tr, 'voucherId');
  };

  const handleDeleteStoreTransfer = async (voucherId: string) => {
    await deleteItem('storeTransfers', voucherId);
  };

  // ERP POS Receipt Handlers
  const handleSavePOSReceipt = async (rcpt: POSReceiptVoucher) => {
    await saveItem('posReceipts', rcpt, 'voucherId');
  };

  const handleUpdatePOSReceipt = async (rcpt: POSReceiptVoucher) => {
    await saveItem('posReceipts', rcpt, 'voucherId');
  };

  const handleDeletePOSReceipt = async (voucherId: string) => {
    await deleteItem('posReceipts', voucherId);
  };

  // ERP Order Management Handlers
  const handleDeleteOrder = async (orderId: string) => {
    await deleteItem('orders', orderId);
  };

  // Clear Expired Stock Batch Handler
  const handleClearExpiredStock = async (id: string) => {
    const target = inventory.find((i) => i.id === id);
    if (target) {
      await saveItem('inventory', { ...target, stockQty: 0, expiryDate: undefined }, 'id');
    }
  };

  // ERP Customer Handlers
  const handleAddCustomer = async (newCust: Customer) => {
    await saveItem('customers', newCust, 'id');
  };

  // ERP Supplier & PO Handlers
  const handleAddSupplier = async (supplier: Supplier) => {
    await saveItem('suppliers', supplier, 'id');
  };

  const handleCreatePO = async (po: PurchaseOrder) => {
    await saveItem('purchaseOrders', po, 'id');
  };

  // HR Employee Handlers
  const handleAddEmployee = async (emp: Employee) => {
    await saveItem('employees', emp, 'id');
  };

  const handleDeleteEmployee = async (id: string) => {
    await deleteItem('employees', id);
  };

  // Stock In Voucher Intake Handler (Updates stock quantity and dynamic unit cost!)
  const handleAddStockInVoucher = async (voucher: StockInVoucher) => {
    await saveItem('stockInVouchers', voucher, 'voucherId');

    // Update matching inventory items stock quantity AND unit cost in Firebase
    for (const item of inventory) {
      const matchedItem = voucher.items.find((i) => i.inventoryId === item.id);
      if (matchedItem) {
        const updated = {
          ...item,
          stockQty: item.stockQty + matchedItem.qty,
          costPerUnit: matchedItem.unitCost,
          lastRestocked: voucher.date,
          expiryDate: matchedItem.hasExpiry && matchedItem.expiryDate ? matchedItem.expiryDate : item.expiryDate,
        };
        await saveItem('inventory', updated, 'id');
      }
    }
  };

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + item.menuItem.price * item.quantity, 0);
  const discountAmount = couponCode === 'LINA10' ? Math.round(subtotal * 0.1) : 0;
  const wishlistedItems = menuItems.filter((i) => wishlistIds.includes(i.id));

  // Render ERP vs Public Website
  if (isERPView) {
    return (
      <ERPLayout
        currentUserRole={currentUserRole}
        setCurrentUserRole={setCurrentUserRole}
        activeModule={activeERPModule}
        setActiveModule={setActiveERPModule}
        onExitERP={() => setIsERPView(false)}
      >
        {activeERPModule === 'dashboard' && (
          <AdminDashboard
            orders={orders}
            menuItems={menuItems}
            eprRecords={eprRecords}
            onNavigateModule={setActiveERPModule}
          />
        )}
        {activeERPModule === 'pos' && (
          <POSSystem
            menuItems={menuItems}
            inventory={inventory}
            posReceipts={posReceipts}
            onCompletePOSOrder={handleAddOrder}
            onSavePOSReceipt={handleSavePOSReceipt}
            onUpdatePOSReceipt={handleUpdatePOSReceipt}
            onDeletePOSReceipt={handleDeletePOSReceipt}
          />
        )}
        {activeERPModule === 'order_vouchers' && (
          <OrderVouchersERP
            orders={orders}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onDeleteOrder={handleDeleteOrder}
          />
        )}
        {activeERPModule === 'kds' && (
          <KitchenDisplaySystem orders={orders} onUpdateStatus={handleUpdateOrderStatus} />
        )}
        {activeERPModule === 'orders' && (
          <LiveOrdersQueue
            orders={orders}
            onUpdateOrderStatus={handleUpdateOrderStatus}
          />
        )}
        {activeERPModule === 'inventory' && (
          <InventoryERP
            inventory={inventory}
            stores={stores}
            onUpdateStock={handleUpdateStock}
            onAddInventoryItem={handleAddInventoryItem}
            onDeleteInventoryItem={handleDeleteInventoryItem}
          />
        )}
        {activeERPModule === 'bincard' && (
          <BinCardERP
            inventory={inventory}
            binCards={binCards}
            orders={orders}
            stores={stores}
          />
        )}
        {activeERPModule === 'store_balance' && (
          <StoreBalanceExpiryERP
            inventory={inventory}
            onDeleteExpiredItem={handleDeleteInventoryItem}
            onClearExpiredStock={handleClearExpiredStock}
          />
        )}
        {activeERPModule === 'store_requests' && (
          <StoreRequestERP
            inventory={inventory}
            stores={stores}
            requests={storeRequests}
            onAddRequest={handleAddStoreRequest}
            onUpdateRequest={handleUpdateStoreRequest}
            onDeleteRequest={handleDeleteStoreRequest}
          />
        )}
        {activeERPModule === 'store_transfers' && (
          <StoreTransferERP
            inventory={inventory}
            stores={stores}
            transfers={storeTransfers}
            onAddTransfer={handleAddStoreTransfer}
            onUpdateTransfer={handleUpdateStoreTransfer}
            onDeleteTransfer={handleDeleteStoreTransfer}
          />
        )}
        {activeERPModule === 'damage' && (
          <DamageERP
            inventory={inventory}
            menuItems={menuItems}
            stores={stores}
            damageVouchers={damageVouchers}
            onAddDamageVoucher={handleAddDamageVoucher}
            onUpdateDamageVoucher={handleUpdateDamageVoucher}
            onDeleteDamageVoucher={handleDeleteDamageVoucher}
          />
        )}
        {activeERPModule === 'staff_food' && (
          <StaffFoodERP
            menuItems={menuItems}
            staffMeals={staffMeals}
            onAddStaffMeal={handleAddStaffMeal}
            onDeleteStaffMeal={handleDeleteStaffMeal}
          />
        )}
        {activeERPModule === 'product_costing' && (
          <ProductCostingERP
            inventory={inventory}
            menuItems={menuItems}
            onAddMenuItem={handleAddMenuItem}
            onDeleteMenuItem={handleDeleteMenuItem}
          />
        )}
        {activeERPModule === 'stock_in' && (
          <StockInVoucherERP
            inventory={inventory}
            suppliers={suppliers}
            stores={stores}
            stockInVouchers={stockInVouchers}
            onAddStockInVoucher={handleAddStockInVoucher}
          />
        )}
        {activeERPModule === 'categories' && (
          <CategoriesERP
            categories={categories}
            onAddCategory={handleAddCategory}
            onDeleteCategory={handleDeleteCategory}
          />
        )}
        {activeERPModule === 'stores' && (
          <StoresERP
            stores={stores}
            onAddStore={handleAddStore}
            onDeleteStore={handleDeleteStore}
          />
        )}
        {activeERPModule === 'suppliers' && (
          <SupplierERP
            suppliers={suppliers}
            purchaseOrders={purchaseOrders}
            onAddSupplier={handleAddSupplier}
            onCreatePO={handleCreatePO}
          />
        )}
        {activeERPModule === 'customers' && (
          <CustomersERP
            customers={customers}
            orders={orders}
            onAddCustomer={handleAddCustomer}
          />
        )}
        {activeERPModule === 'menu_mgr' && (
          <MenuManagement
            menuItems={menuItems}
            onAddItem={handleAddMenuItem}
            onDeleteItem={handleDeleteMenuItem}
          />
        )}
        {activeERPModule === 'recipes' && <RecipeCosting recipeCosts={recipeCosts} />}
        {activeERPModule === 'hr' && (
          <HRModule
            employees={employees}
            onAddEmployee={handleAddEmployee}
            onDeleteEmployee={handleDeleteEmployee}
          />
        )}
        {activeERPModule === 'epr' && <EPRModule records={eprRecords} />}
        {activeERPModule === 'reports' && (
          <ReportsERP
            orders={orders}
            posReceipts={posReceipts}
            damageVouchers={damageVouchers}
            inventory={inventory}
          />
        )}
        {activeERPModule === 'settings' && (
          <SettingsResetERP
            users={systemUsers}
            onAddUser={handleAddSystemUser}
            onUpdateUser={handleUpdateSystemUser}
            onDeleteUser={handleDeleteSystemUser}
            onSystemReset={handleSystemReset}
            onSignOut={() => setIsERPView(false)}
          />
        )}

        {/* Staff Authentication Modal inside ERP view */}
        <AuthModal
          isOpen={isAuthModalOpen}
          onClose={() => setIsAuthModalOpen(false)}
          targetRole={authTargetRole}
          systemUsers={systemUsers}
          onLoginSuccess={handleLoginSuccess}
        />
      </ERPLayout>
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#FDFBF7]">
      {/* Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartItems.reduce((sum, item) => sum + item.quantity, 0)}
        setIsCartOpen={setIsCartOpen}
        setIsAuthModalOpen={handleOpenAuthModal}
        currentUserRole={currentUserRole}
        setCurrentUserRole={setCurrentUserRole}
        isERPView={isERPView}
        setIsERPView={setIsERPView}
        loggedInUser={loggedInUser}
        onSignOut={handleSignOut}
      />

      {/* Staff Authentication Modal */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        targetRole={authTargetRole}
        systemUsers={systemUsers}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Dynamic View Router */}
      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <HeroSection
              onExploreMenu={() => setActiveTab('menu')}
              onReserveTable={() => setActiveTab('reservations')}
            />
            <TodaysSpecials
              specials={menuItems.filter((i) => i.isSpecial)}
              onAddToCart={handleAddToCart}
              onQuickView={(item) => handleAddToCart(item)}
              toggleWishlist={toggleWishlist}
              wishlistIds={wishlistIds}
            />
          </>
        )}

        {activeTab === 'menu' && (
          <MenuView
            menuItems={menuItems}
            onAddToCart={handleAddToCart}
            wishlistIds={wishlistIds}
            toggleWishlist={toggleWishlist}
          />
        )}

        {activeTab === 'reservations' && (
          <ReservationSection onAddReservation={handleAddReservation} />
        )}

        {activeTab === 'customer' && (
          <CustomerPortal
            customer={customers[0]}
            orders={orders}
            wishlistItems={wishlistedItems}
            onRemoveWishlist={toggleWishlist}
            onAddToCart={handleAddToCart}
          />
        )}

        {activeTab === 'about' && <AboutPage />}
        {activeTab === 'gallery' && <GalleryPage />}
        {activeTab === 'blog' && <BlogPage posts={INITIAL_BLOG_POSTS} />}
        {activeTab === 'careers' && <CareerPage careers={INITIAL_CAREERS} />}
        {activeTab === 'contact' && <ContactPage />}
        {activeTab === 'privacy' && <PrivacyTermsPages type="privacy" />}
        {activeTab === 'terms' && <PrivacyTermsPages type="terms" />}
        {![
          'home',
          'menu',
          'reservations',
          'customer',
          'about',
          'gallery',
          'blog',
          'careers',
          'contact',
          'privacy',
          'terms',
        ].includes(activeTab) && <NotFoundPage onGoHome={() => setActiveTab('home')} />}
      </main>

      {/* Cart Slide-Over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => setIsCheckoutOpen(true)}
        couponCode={couponCode}
        setCouponCode={setCouponCode}
        discountAmount={discountAmount}
        deliveryType={deliveryType}
        setDeliveryType={setDeliveryType}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        deliveryType={deliveryType}
        discountAmount={discountAmount}
        couponCode={couponCode}
        onOrderCompleted={handleAddOrder}
      />

      {/* Footer */}
      <Footer setActiveTab={setActiveTab} setIsERPView={setIsERPView} />
    </div>
  );
}
